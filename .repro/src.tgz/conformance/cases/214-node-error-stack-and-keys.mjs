// How a coded error's stack header is rendered and what its own keys are,
// against node v22.22.2.
//
// node's defaultPrepareStackTrace (lib/internal/errors.js) writes the header
// on the stack's FIRST read: `${name} [${code}]: ${message}` for an error
// carrying [kIsNodeError] (one built by its internal errors), and the
// intrinsic Error.prototype.toString for any other -- never the error's own
// toString. oam rendered every header through `${err}`, so AssertionError
// (whose name carries the code while its stack is rendered) showed the code
// twice, a class overriding toString leaked it into the stack, and a code
// changed before the first read did not show.
import assert from "node:assert";
import fs from "node:fs";

const head = (e) => JSON.stringify(String(e.stack).split("\n")[0]);
const caught = (fn) => {
  try {
    fn();
  } catch (e) {
    return e;
  }
  return null;
};

console.log("== stack header: node's defaultPrepareStackTrace");
console.log("assert.strictEqual", head(caught(() => assert.strictEqual(1, 2))));
console.log("assert.ok", head(caught(() => assert.ok(false))));
console.log("new AssertionError", head(new assert.AssertionError({ message: "m" })));
class OwnToString extends Error {
  toString() {
    return "CUSTOM";
  }
}
console.log("own toString", head(new OwnToString("m")), String(new OwnToString("m")));
{
  const e = caught(() => fs.readFileSync(1.5));
  e.code = "ERR_X";
  console.log("code changed before the first read", head(e));
}
{
  const e = caught(() => fs.readFileSync(1.5));
  void e.stack;
  e.code = "ERR_X";
  console.log("code changed after the first read", head(e));
}
{
  const e = new TypeError("plain");
  e.code = "ERR_PLAIN";
  console.log("a plain error with a code", head(e));
}

console.log("== the header is rendered lazily: a message set before the first read shows");
// oam's helper that shapes an error built elsewhere read the stack at once,
// so a message changed before anyone read it never showed there.
for (const [label, fn] of [
  ["fs.readFileSync(1.5)", () => fs.readFileSync(1.5)],
  ["Buffer.from(1)", () => Buffer.from(1)],
  ["fs.read(1.5, cb)", () => fs.read(1.5, () => {})],
  ["fs.mkdtempSync(1)", () => fs.mkdtempSync(1)],
]) {
  const e = caught(fn);
  e.message = "CHANGED";
  console.log(label, e.code, head(e));
}

console.log("== own keys: one shape per code, whichever module raised it");
// The vendored streams' errors put `message` before `code` for the codes
// whose node message is a function; node_compat's had node's order.
const stream = await import("node:stream");
const keys = (e) => (e ? `${e.code} ${Reflect.ownKeys(e).filter((k) => typeof k === "string").join(",")}` : "no error");
console.log("stream.pipeline()", keys(caught(() => stream.pipeline())));
console.log("Readable.from(1)", keys(caught(() => stream.Readable.from(1))));
console.log("highWaterMark -1", keys(caught(() => new stream.Readable({ highWaterMark: -1 }))));
console.log("readable.take(-1)", keys(caught(() => new stream.Readable({ read() {} }).take(-1))));
console.log("stream.compose()", keys(caught(() => stream.compose())));
console.log("writable.write(1)", keys(caught(() => new stream.Writable({ write(c, e, cb) { cb(); } }).write(1))));
// A code with a string message: message before code, in both factories.
console.log("write after end", keys(await new Promise((resolve) => {
  const w = new stream.Writable({ write(c, e, cb) { cb(); } });
  w.on("error", () => {});
  w.end();
  w.write("x", resolve);
})));
console.log("fs.readFileSync(1.5)", keys(caught(() => fs.readFileSync(1.5))));

console.log("== tls.checkServerIdentity: reason, host and cert sit between code and message");
const tls = await import("node:tls");
{
  const e = tls.checkServerIdentity("a.com", { subject: { CN: "b.com" }, subjectaltname: "DNS:b.com" });
  console.log(e.code, Reflect.ownKeys(e).filter((k) => typeof k === "string").join(","), head(e));
}
