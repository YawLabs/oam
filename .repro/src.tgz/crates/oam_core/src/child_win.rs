//! Windows extra-fd stdio: raw `CreateProcessW` + the MSVCRT `lpReserved2`
//! fd-table inheritance, so a child can receive numbered fds beyond 0/1/2.
//!
//! `std`/`tokio` `Command` only wire stdin/stdout/stderr. Chromium's
//! `--remote-debugging-pipe` reads CDP off fd 3 and writes off fd 4 (via
//! `_get_osfhandle(3/4)`), so driving a browser over the (faster, no-TCP) pipe
//! transport requires giving the child those fds. This is the mechanism libuv
//! implements; the proven topology (anonymous pipes + per-fd direction):
//!   fd 3 = child-read  / parent-write  (parent sends CDP commands)
//!   fd 4 = child-write / parent-read   (child sends CDP responses)
//!
//! A raw child is NOT a `tokio::process::Child`, so it has its own registry and
//! op set: wait via `WaitForSingleObject` on the blocking pool, kill via
//! `TerminateProcess`, pipe I/O via blocking `ReadFile`/`WriteFile` on the
//! blocking pool (a read that a close must stop is cancelled with
//! `CancelIoEx`; see `ReadEnd`). Anonymous pipes are unidirectional, so extra fds carry one
//! direction each (sufficient for CDP); full-duplex extra fds (named pipes)
//! are a future enhancement no current consumer needs.

use std::collections::HashMap;
use std::ffi::OsStr;
use std::os::windows::ffi::OsStrExt;
use std::os::windows::io::{AsRawHandle, BorrowedHandle, FromRawHandle, OwnedHandle};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};

use windows_sys::Win32::Foundation::{
    CloseHandle, DUPLICATE_SAME_ACCESS, DuplicateHandle, GetLastError, HANDLE, HANDLE_FLAG_INHERIT,
    INVALID_HANDLE_VALUE, SetHandleInformation, WAIT_OBJECT_0,
};
use windows_sys::Win32::Security::SECURITY_ATTRIBUTES;
use windows_sys::Win32::Storage::FileSystem::{
    CreateFileW, FILE_GENERIC_READ, FILE_GENERIC_WRITE, FILE_SHARE_READ, FILE_SHARE_WRITE,
    FILE_TYPE, FILE_TYPE_CHAR, FILE_TYPE_PIPE, GetFileType, OPEN_EXISTING, ReadFile, WriteFile,
};
use windows_sys::Win32::System::Console::{
    GetStdHandle, STD_ERROR_HANDLE, STD_INPUT_HANDLE, STD_OUTPUT_HANDLE,
};
use windows_sys::Win32::System::IO::CancelIoEx;
use windows_sys::Win32::System::Pipes::CreatePipe;
use windows_sys::Win32::System::Threading::{
    CREATE_SUSPENDED, CREATE_UNICODE_ENVIRONMENT, CreateProcessW, DeleteProcThreadAttributeList,
    EXTENDED_STARTUPINFO_PRESENT, GetCurrentProcess, GetExitCodeProcess, INFINITE,
    InitializeProcThreadAttributeList, LPPROC_THREAD_ATTRIBUTE_LIST,
    PROC_THREAD_ATTRIBUTE_HANDLE_LIST, PROCESS_INFORMATION, ResumeThread, STARTF_USESHOWWINDOW,
    STARTF_USESTDHANDLES, STARTUPINFOEXW, TerminateProcess, UpdateProcThreadAttribute,
    WaitForSingleObject,
};

use super::OpOutcome;

// ShowWindow commands for STARTUPINFO.wShowWindow (winuser.h). Spelled out
// rather than pulling in windows-sys's whole UI module for two numbers.
const SW_HIDE: u16 = 0;
const SW_SHOWDEFAULT: u16 = 10;

// MSVCRT fd-info flags packed into lpReserved2 (one byte per fd).
const FOPEN: u8 = 0x01;
const FPIPE: u8 = 0x08;
const FDEV: u8 = 0x40;

/// HANDLE is `*mut c_void`, not Send. Only the child's PROCESS handle travels
/// this way now (the pipe ends are `OwnedHandle`s): `raw_wait` waits on a copy
/// on the blocking pool while `raw_kill` may terminate through the registry's.
#[derive(Clone, Copy)]
struct SendHandle(HANDLE);
// SAFETY: HANDLE is a raw `*mut c_void`, hence not auto-`Send`. The process
// handle is only ever passed to WaitForSingleObject, GetExitCodeProcess and
// TerminateProcess, which the kernel serializes on the object and which may be
// called on one handle from several threads; it is closed once, by `raw_wait`,
// after its wait has returned and after taking it out of the registry under
// the lock `raw_kill` also takes, so no copy is used after the close.
unsafe impl Send for SendHandle {}

/// What to do with one child fd index.
#[derive(Clone, Copy, PartialEq, Eq)]
pub enum StdioFd {
    /// No stream: child fd points at NUL.
    Ignore,
    /// Child inherits the parent's std handle for this fd (0/1/2 only).
    Inherit,
    /// Pipe the child READS (parent writes). e.g. stdin, CDP-in (fd 3).
    ChildRead,
    /// Pipe the child WRITES (parent reads). e.g. stdout/stderr, CDP-out (fd 4).
    ChildWrite,
    /// A descriptor the CALLER named -- `stdio: ['ignore','pipe','pipe', logFd]`.
    /// Carried as a raw HANDLE value (isize) so the variant stays `Send`.
    ///
    /// Without this a numbered slot fell through to `Inherit`, whose fd>2 arm
    /// hands the child STD_ERROR_HANDLE -- so the child quietly got stderr where
    /// the caller asked for a file.
    Descriptor(isize),
}

/// Parent-side end of one piped fd. Owned handles: dropping an end is its
/// close, so no path has to remember to close one.
enum FdEnd {
    /// The parent writes, the child reads. Taken out of the registry for the
    /// length of a write and put back after it; `None` once closed.
    Write(Option<OwnedHandle>),
    /// The parent reads, the child writes. Shared rather than taken, so a
    /// close can reach a read that is blocked in `ReadFile` on the pool.
    Read(Arc<ReadEnd>),
}

/// The parent's read end of a child-write pipe.
///
/// A read is ONE blocking `ReadFile` on the blocking pool: it returns the
/// moment the child writes anything (up to 64 KiB, as libuv reads), and with
/// EOF once every write end is closed. That replaced a `PeekNamedPipe` poll
/// that slept 50 ms whenever the pipe was empty, so each message a child
/// sent waited up to 50 ms to be seen: 20 echo round trips over a 4-slot
/// stdio took about 1 s where node takes 4 ms.
///
/// A blocked read must not outlive a close of the end (`destroy()` on the
/// stream): `close` marks the end and cancels the read with `CancelIoEx`,
/// which stops a synchronous `ReadFile` issued by another thread. The handle
/// itself closes when the last holder -- the registry or the read -- drops
/// it, never under a read that is still using it.
struct ReadEnd {
    handle: OwnedHandle,
    /// Set by `close`: a read that starts after it returns EOF at once.
    closing: AtomicBool,
    /// True from just before a read checks `closing` until its `ReadFile`
    /// has returned, so `close` knows whether there is a read to cancel.
    reading: AtomicBool,
}

impl ReadEnd {
    fn new(handle: OwnedHandle) -> Self {
        ReadEnd {
            handle,
            closing: AtomicBool::new(false),
            reading: AtomicBool::new(false),
        }
    }

    /// One blocking read: `Some(bytes)`, or `None` at EOF (the child's write
    /// ends all closed, or this end closed by `close`).
    fn read_blocking(&self) -> Result<Option<Vec<u8>>, String> {
        self.reading.store(true, Ordering::SeqCst);
        let out = if self.closing.load(Ordering::SeqCst) {
            Ok(None)
        } else {
            let mut buf = vec![0u8; 65536];
            let mut n: u32 = 0;
            // SAFETY: the handle is owned by `self`, which the caller's Arc keeps
            // alive for the whole call, so it is open; `buf` is a live 64 KiB
            // buffer and `n` a live out-param; no OVERLAPPED (a synchronous pipe).
            let ok = unsafe {
                ReadFile(
                    self.handle.as_raw_handle(),
                    buf.as_mut_ptr(),
                    65536,
                    &mut n,
                    std::ptr::null_mut(),
                )
            };
            if ok == 0 {
                let err = std::io::Error::last_os_error();
                match err.raw_os_error() {
                    // ERROR_BROKEN_PIPE: every write end closed == clean EOF.
                    Some(109) => Ok(None),
                    // ERROR_OPERATION_ABORTED: `close` cancelled this read.
                    Some(995) if self.closing.load(Ordering::SeqCst) => Ok(None),
                    _ => Err(format!("ReadFile: {err}")),
                }
            } else if n == 0 {
                Ok(None)
            } else {
                buf.truncate(n as usize);
                Ok(Some(buf))
            }
        };
        self.reading.store(false, Ordering::SeqCst);
        out
    }

    /// Stop this end: no read starts after this, and one in flight ends.
    fn close(self: &Arc<Self>) {
        self.closing.store(true, Ordering::SeqCst);
        if !self.reading.load(Ordering::SeqCst) {
            return;
        }
        self.cancel();
        if !self.reading.load(Ordering::SeqCst) {
            return;
        }
        // A read can sit between its `closing` check and the kernel taking its
        // ReadFile, where a cancel finds nothing to cancel and the read then
        // blocks. So keep cancelling until it is out -- off this thread, which
        // is the JS thread -- with a bound, so a read that cannot be cancelled
        // never pins a thread here forever.
        let end = Arc::clone(self);
        std::thread::spawn(move || {
            for _ in 0..2000 {
                if !end.reading.load(Ordering::SeqCst) {
                    return;
                }
                end.cancel();
                std::thread::sleep(std::time::Duration::from_millis(1));
            }
        });
    }

    fn cancel(&self) {
        // SAFETY: the handle is owned by `self` and open; a null OVERLAPPED
        // cancels every I/O outstanding on it from any thread, a synchronous
        // ReadFile included. Nothing of ours is written.
        unsafe { CancelIoEx(self.handle.as_raw_handle(), std::ptr::null()) };
    }
}

pub struct RawChild {
    /// `None` once `raw_wait` has collected the exit and closed it.
    process: Option<SendHandle>,
    pub pid: u32,
    fds: HashMap<u32, FdEnd>,
    kill_signal: Option<String>,
}

pub type RawChildRegistry = Arc<Mutex<HashMap<u64, RawChild>>>;

/// `GetFileType`: what kind of object a handle names -- a pipe (or socket), a
/// character device (a console, `NUL`), a disk file, or FILE_TYPE_UNKNOWN.
/// Shared by the CRT fd-table flags below and stdin's handle classification
/// (stdin.rs), which is libuv's `uv_guess_handle`.
pub(crate) fn file_type(h: HANDLE) -> FILE_TYPE {
    // SAFETY: GetFileType takes the handle by value and only asks the kernel
    // for the type of the object it names; it dereferences none of our
    // memory. So any value is sound to pass -- a live handle, a closed or
    // recycled one, null, INVALID_HANDLE_VALUE -- and one that names nothing
    // comes back FILE_TYPE_UNKNOWN rather than faulting.
    unsafe { GetFileType(h) }
}

fn crt_flag(h: HANDLE) -> u8 {
    match file_type(h) {
        FILE_TYPE_PIPE => FOPEN | FPIPE,
        FILE_TYPE_CHAR => FOPEN | FDEV,
        _ => FOPEN,
    }
}

fn to_wide(s: &str) -> Vec<u16> {
    OsStr::new(s)
        .encode_wide()
        .chain(std::iter::once(0))
        .collect()
}

/// Canonical Windows argv quoting (CommandLineToArgvW-compatible).
fn append_quoted(arg: &str, out: &mut String) {
    if !arg.is_empty() && !arg.contains([' ', '\t', '\n', '\u{0b}', '"']) {
        out.push_str(arg);
        return;
    }
    out.push('"');
    let chars: Vec<char> = arg.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        let mut backslashes = 0;
        while i < chars.len() && chars[i] == '\\' {
            backslashes += 1;
            i += 1;
        }
        if i == chars.len() {
            for _ in 0..backslashes * 2 {
                out.push('\\');
            }
            break;
        } else if chars[i] == '"' {
            for _ in 0..backslashes * 2 + 1 {
                out.push('\\');
            }
            out.push('"');
        } else {
            for _ in 0..backslashes {
                out.push('\\');
            }
            out.push(chars[i]);
        }
        i += 1;
    }
    out.push('"');
}

/// Build the double-null-terminated UTF-16 environment block a child is
/// created with, from `env` ALONE: nothing of this process's environment is
/// added (see `child::spawn_child`), so a hidden `=C:` reaches the child only
/// when `env` names one, as under node.
///
/// Sorted case-insensitively, the order CreateProcessW documents and libuv's
/// make_program_env produces. Names are case-insensitive on Windows, so of
/// two pairs whose names differ only in case the first one given is kept
/// (the JS layer has already reduced such a set to node's pick). An empty
/// block is the lone terminator pair.
fn build_env_block(env: &[(String, String)]) -> Vec<u16> {
    let mut pairs: Vec<(Vec<u16>, &str, &str)> = Vec::with_capacity(env.len());
    for (k, v) in env {
        let folded = env_name_fold(k);
        if pairs.iter().any(|(seen, _, _)| *seen == folded) {
            continue;
        }
        pairs.push((folded, k, v));
    }
    pairs.sort_by(|a, b| a.0.cmp(&b.0));
    let mut block: Vec<u16> = Vec::new();
    for (_, k, v) in pairs {
        block.extend(OsStr::new(k).encode_wide());
        block.push(u16::from(b'='));
        block.extend(OsStr::new(v).encode_wide());
        block.push(0);
    }
    if block.is_empty() {
        block.push(0);
    }
    block.push(0); // final terminator (block is "k=v\0k=v\0\0")
    block
}

/// An environment name as Windows compares it: UTF-16, upper-cased code unit
/// by code unit, as CompareStringOrdinal(.., TRUE) -- libuv's comparison --
/// does.
fn env_name_fold(name: &str) -> Vec<u16> {
    OsStr::new(name)
        .encode_wide()
        .map(|u| {
            let Some(c) = char::from_u32(u32::from(u)) else {
                return u;
            };
            let mut upper = c.to_uppercase();
            match (upper.next(), upper.next()) {
                (Some(single), None) => u16::try_from(u32::from(single)).unwrap_or(u),
                _ => u,
            }
        })
        .collect()
}

fn open_nul() -> HANDLE {
    let sa = SECURITY_ATTRIBUTES {
        nLength: std::mem::size_of::<SECURITY_ATTRIBUTES>() as u32,
        bInheritHandle: 1,
        ..Default::default()
    };
    let name = to_wide("NUL");
    // SAFETY: `name` is a NUL-terminated UTF-16 buffer that outlives the call and
    // `&sa` points to the live SECURITY_ATTRIBUTES above; the remaining arguments
    // are constants or null. The returned HANDLE (or INVALID_HANDLE_VALUE on
    // failure) is checked by the caller.
    unsafe {
        CreateFileW(
            name.as_ptr(),
            FILE_GENERIC_READ | FILE_GENERIC_WRITE,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            &sa,
            OPEN_EXISTING,
            0,
            std::ptr::null_mut(),
        )
    }
}

/// Spawn a child with an arbitrary stdio fd layout. Pipes are created per the
/// `stdio` spec; the child inherits the appropriate ends as numbered fds via
/// the CRT fd-table, and the parent keeps the other ends for I/O.
///
/// A non-`detached` child is created SUSPENDED, placed in the kill-on-close
/// job (job_win.rs), and only then resumed, so it never runs an instruction
/// outside the job. A `detached` child skips the job and gets libuv's
/// DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP.
///
/// `windows_hide` is node's `windowsHide`, applied as libuv applies it:
/// `CREATE_NO_WINDOW` when no slot is inherited (`child::
/// windows_creation_flags`), and `SW_HIDE` -- otherwise `SW_SHOWDEFAULT` --
/// as the window state a GUI child starts in.
#[allow(clippy::too_many_arguments)]
pub fn spawn_extra(
    command: &str,
    args: &[String],
    cwd: Option<&str>,
    env: Option<&[(String, String)]>,
    stdio: &[StdioFd],
    detached: bool,
    windows_hide: bool,
) -> Result<RawChild, String> {
    // Same program search as the std-backed spawns (see child.rs).
    let resolved = match super::child::resolve_windows_program(command, cwd) {
        Ok(resolved) => resolved,
        Err(e) => return Err(super::child::spawn_failure_json(&e)),
    };
    let command = resolved.as_deref().unwrap_or(command);
    // SAFETY: one large block wraps the whole spawn sequence; each Win32 call
    // inside establishes its preconditions locally. `sa`/`si`/`pi` are
    // zero-initialized POD then filled; every HANDLE handed to the child is
    // freshly created or duplicated and owned here; `blob`, `inherit_list`,
    // `attr_buf`, `cmd_w`, and the env block all outlive the CreateProcessW that
    // borrows their pointers; and every out-param is a live local. Each early
    // return first runs `cleanup_fail`, which closes every handle allocated so
    // far, so no handle leaks on an error path. `pi.hProcess` and `pi.hThread`
    // are the fresh handles CreateProcessW returned: the process handle is only
    // BORROWED for the job assignment, while it is still open, and the thread
    // handle is resumed before either is closed or handed to RawChild.
    unsafe {
        let mut sa: SECURITY_ATTRIBUTES = std::mem::zeroed();
        sa.nLength = std::mem::size_of::<SECURITY_ATTRIBUTES>() as u32;
        sa.bInheritHandle = 1;

        // Child-side handles (inherited, indexed by fd) and parent-side ends.
        let mut child_handles: Vec<HANDLE> = Vec::with_capacity(stdio.len());
        let mut parent_fds: HashMap<u32, FdEnd> = HashMap::new();
        // Track handles to close on the spawn path (child ends after spawn; all
        // on failure).
        let mut child_close: Vec<HANDLE> = Vec::new();
        let mut nul_handles: Vec<HANDLE> = Vec::new();

        // The parent's ends are OwnedHandles in `parent_fds`, which close
        // themselves when an early return drops it; only the raw child-side
        // and NUL handles need closing here.
        let cleanup_fail = |child_close: &[HANDLE], nul: &[HANDLE]| {
            for h in child_close {
                CloseHandle(*h);
            }
            for h in nul {
                CloseHandle(*h);
            }
        };

        for (i, spec) in stdio.iter().enumerate() {
            let fd = i as u32;
            match spec {
                StdioFd::Ignore => {
                    let nul = open_nul();
                    nul_handles.push(nul);
                    child_handles.push(nul);
                }
                StdioFd::Inherit => {
                    let h = match fd {
                        0 => GetStdHandle(STD_INPUT_HANDLE),
                        1 => GetStdHandle(STD_OUTPUT_HANDLE),
                        _ => GetStdHandle(STD_ERROR_HANDLE),
                    };
                    if h.is_null() || h == INVALID_HANDLE_VALUE {
                        // No std handle to pass (a parent with none): the
                        // sentinel stays, and is left out of the inherit list.
                        child_handles.push(h);
                        continue;
                    }
                    // Duplicated as INHERITABLE, as libuv duplicates an
                    // inherited fd for its child: this process's own std
                    // handle need not be -- oam clears the flag on its std
                    // handles before it starts a type-checker
                    // (oam_ts::daemon::unshare_std_handles) -- and a handle in
                    // PROC_THREAD_ATTRIBUTE_HANDLE_LIST that is not
                    // inheritable fails CreateProcessW with
                    // ERROR_INVALID_PARAMETER, which surfaced as `spawn
                    // EINVAL` from a script whose type-check had started. The
                    // dup is ours, so it lands in child_close.
                    let mut dup: HANDLE = std::ptr::null_mut();
                    if DuplicateHandle(
                        GetCurrentProcess(),
                        h,
                        GetCurrentProcess(),
                        &mut dup,
                        0,
                        1, // inheritable
                        DUPLICATE_SAME_ACCESS,
                    ) == 0
                    {
                        cleanup_fail(&child_close, &nul_handles);
                        return Err(format!(
                            "DuplicateHandle(fd{fd}) failed: {}",
                            GetLastError()
                        ));
                    }
                    child_close.push(dup);
                    child_handles.push(dup);
                }
                StdioFd::Descriptor(raw) => {
                    // Re-duplicated as INHERITABLE: the caller's handle is not,
                    // and the child's CRT fd table can only receive handles
                    // marked for inheritance. The dup is ours, so it lands in
                    // child_close and the caller's descriptor is untouched.
                    let mut dup: HANDLE = std::ptr::null_mut();
                    if DuplicateHandle(
                        GetCurrentProcess(),
                        *raw as HANDLE,
                        GetCurrentProcess(),
                        &mut dup,
                        0,
                        1, // inheritable
                        DUPLICATE_SAME_ACCESS,
                    ) == 0
                    {
                        cleanup_fail(&child_close, &nul_handles);
                        return Err(format!(
                            "DuplicateHandle(fd{fd}) failed: {}",
                            GetLastError()
                        ));
                    }
                    child_close.push(dup);
                    child_handles.push(dup);
                }
                StdioFd::ChildRead => {
                    // child reads -> child gets READ end; parent WRITES.
                    let mut child_read: HANDLE = std::ptr::null_mut();
                    let mut parent_write: HANDLE = std::ptr::null_mut();
                    if CreatePipe(&mut child_read, &mut parent_write, &sa, 0) == 0 {
                        cleanup_fail(&child_close, &nul_handles);
                        return Err(format!("CreatePipe(fd{fd}) failed: {}", GetLastError()));
                    }
                    SetHandleInformation(parent_write, HANDLE_FLAG_INHERIT, 0);
                    child_close.push(child_read);
                    child_handles.push(child_read);
                    // `parent_write` is the fresh handle CreatePipe returned and
                    // nothing else owns it.
                    parent_fds.insert(
                        fd,
                        FdEnd::Write(Some(OwnedHandle::from_raw_handle(parent_write))),
                    );
                }
                StdioFd::ChildWrite => {
                    // child writes -> child gets WRITE end; parent READS.
                    let mut parent_read: HANDLE = std::ptr::null_mut();
                    let mut child_write: HANDLE = std::ptr::null_mut();
                    if CreatePipe(&mut parent_read, &mut child_write, &sa, 0) == 0 {
                        cleanup_fail(&child_close, &nul_handles);
                        return Err(format!("CreatePipe(fd{fd}) failed: {}", GetLastError()));
                    }
                    SetHandleInformation(parent_read, HANDLE_FLAG_INHERIT, 0);
                    child_close.push(child_write);
                    child_handles.push(child_write);
                    // `parent_read` is the fresh handle CreatePipe returned and
                    // nothing else owns it.
                    parent_fds.insert(
                        fd,
                        FdEnd::Read(Arc::new(ReadEnd::new(OwnedHandle::from_raw_handle(
                            parent_read,
                        )))),
                    );
                }
            }
        }

        // MSVCRT lpReserved2 block: int count; u8 flags[count]; HANDLE[count].
        let count = child_handles.len() as i32;
        let ptr_size = std::mem::size_of::<usize>();
        let mut blob: Vec<u8> = Vec::with_capacity(4 + child_handles.len() * (1 + ptr_size));
        blob.extend_from_slice(&count.to_ne_bytes());
        for h in &child_handles {
            blob.push(crt_flag(*h));
        }
        for h in &child_handles {
            blob.extend_from_slice(&(*h as usize).to_ne_bytes());
        }

        // Explicit inheritance via PROC_THREAD_ATTRIBUTE_HANDLE_LIST. Without a
        // list, CreateProcessW(bInheritHandles=TRUE) hands the child EVERY
        // inheritable handle in the process at that instant -- so a concurrent
        // spawn (another spawn_extra, or a tokio/std child) leaks our pipe ends
        // into an unrelated child (which then never sees EOF -> hang), and our
        // child conversely inherits handles it should not. Naming exactly our
        // handles limits the child to them and makes concurrent spawn_extra
        // calls race-free: each child sees only its own list. (A residual
        // window remains against a concurrent NON-list spawner like tokio/std,
        // inherent to the Win32 API -- std has the same limitation -- and it
        // covers the inheritable duplicates of this process's std handles an
        // `inherit` fd is given, for as long as this spawn holds them.)
        //
        // Handles in the list must be unique and valid; child_handles can hold
        // INVALID sentinels (a std handle this process does not have), so
        // filter and dedup first.
        let mut inherit_list: Vec<HANDLE> = Vec::with_capacity(child_handles.len());
        for h in &child_handles {
            if !h.is_null() && *h != INVALID_HANDLE_VALUE && !inherit_list.contains(h) {
                inherit_list.push(*h);
            }
        }

        // Two-call sizing dance, then one HANDLE_LIST entry. The attribute list
        // stores a POINTER to `inherit_list` (it is not copied), so both
        // `inherit_list` and `attr_buf` must outlive the CreateProcessW below.
        let mut attr_size: usize = 0;
        InitializeProcThreadAttributeList(std::ptr::null_mut(), 1, 0, &mut attr_size);
        let mut attr_buf: Vec<u8> = vec![0u8; attr_size];
        let attr_list = attr_buf.as_mut_ptr() as LPPROC_THREAD_ATTRIBUTE_LIST;
        if InitializeProcThreadAttributeList(attr_list, 1, 0, &mut attr_size) == 0 {
            let err = GetLastError();
            cleanup_fail(&child_close, &nul_handles);
            return Err(format!("InitializeProcThreadAttributeList failed: {err}"));
        }
        if UpdateProcThreadAttribute(
            attr_list,
            0,
            PROC_THREAD_ATTRIBUTE_HANDLE_LIST as usize,
            inherit_list.as_ptr() as *const std::ffi::c_void,
            std::mem::size_of_val(inherit_list.as_slice()),
            std::ptr::null_mut(),
            std::ptr::null_mut(),
        ) == 0
        {
            let err = GetLastError();
            DeleteProcThreadAttributeList(attr_list);
            cleanup_fail(&child_close, &nul_handles);
            return Err(format!("UpdateProcThreadAttribute failed: {err}"));
        }

        let mut si: STARTUPINFOEXW = std::mem::zeroed();
        si.StartupInfo.cb = std::mem::size_of::<STARTUPINFOEXW>() as u32;
        // STARTF_USESHOWWINDOW always, as libuv sets it: SW_HIDE for
        // windowsHide, else SW_SHOWDEFAULT.
        si.StartupInfo.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
        si.StartupInfo.wShowWindow = if windows_hide {
            SW_HIDE
        } else {
            SW_SHOWDEFAULT
        };
        si.StartupInfo.hStdInput = child_handles
            .first()
            .copied()
            .unwrap_or(INVALID_HANDLE_VALUE);
        si.StartupInfo.hStdOutput = child_handles
            .get(1)
            .copied()
            .unwrap_or(INVALID_HANDLE_VALUE);
        si.StartupInfo.hStdError = child_handles
            .get(2)
            .copied()
            .unwrap_or(INVALID_HANDLE_VALUE);
        si.StartupInfo.cbReserved2 = blob.len() as u16;
        si.StartupInfo.lpReserved2 = blob.as_mut_ptr();
        si.lpAttributeList = attr_list;

        // Command line.
        let mut cmdline = String::new();
        append_quoted(command, &mut cmdline);
        for a in args {
            cmdline.push(' ');
            append_quoted(a, &mut cmdline);
        }
        let mut cmd_w = to_wide(&cmdline);

        // Environment block: `env` is the child's whole environment; with
        // none the child inherits this process's.
        // libuv's UV_INHERIT_FD test: an inherited slot or a numbered one.
        let inherits = stdio
            .iter()
            .any(|s| matches!(s, StdioFd::Inherit | StdioFd::Descriptor(_)));
        let base_flags = super::child::windows_creation_flags(detached, windows_hide, inherits);
        let mut env_block;
        let (env_ptr, creation_flags) = match env {
            Some(env) => {
                env_block = build_env_block(env);
                (
                    env_block.as_mut_ptr() as *const std::ffi::c_void,
                    base_flags | CREATE_UNICODE_ENVIRONMENT,
                )
            }
            None => (std::ptr::null(), base_flags),
        };

        let cwd_w = cwd.map(to_wide);
        let cwd_ptr = cwd_w.as_ref().map_or(std::ptr::null(), |w| w.as_ptr());

        let mut pi: PROCESS_INFORMATION = std::mem::zeroed();
        let ok = CreateProcessW(
            std::ptr::null(),
            cmd_w.as_mut_ptr(),
            std::ptr::null(),
            std::ptr::null(),
            1, // bInheritHandles (scoped by the handle list in si.lpAttributeList)
            // SUSPENDED for every child: a non-detached one must be in the job
            // before its first instruction (see below). libuv suspends only
            // detached children and assigns the rest while they already run.
            creation_flags | EXTENDED_STARTUPINFO_PRESENT | CREATE_SUSPENDED,
            env_ptr,
            cwd_ptr,
            &si.StartupInfo,
            &mut pi,
        );
        // The attribute list has done its job for this CreateProcessW; free it
        // on both the success and failure paths before anything else.
        DeleteProcThreadAttributeList(attr_list);
        if ok == 0 {
            let err = GetLastError();
            cleanup_fail(&child_close, &nul_handles);
            // Route through the shared io::Error mapping so ERROR_PATH_NOT_FOUND
            // (3) and friends land on the same code node reports, and errno
            // rides along: node emits it as the `code` argument of the 'close'
            // event for a child that never started (same contract as child.rs).
            // Built as JSON, not formatted: a Windows path is full of
            // backslashes, and an unescaped one made the whole body unparsable,
            // so the JS side lost the code.
            let ioe = std::io::Error::from_raw_os_error(err as i32);
            return Err(super::child::spawn_failure_json_with(
                &ioe,
                &format!("CreateProcessW failed (GetLastError={err}) for {command}"),
            ));
        }

        // Job membership while the child is still suspended, so nothing it
        // does -- including exiting or spawning -- happens outside the job.
        if !detached {
            super::job_win::adopt(BorrowedHandle::borrow_raw(pi.hProcess));
        }
        if ResumeThread(pi.hThread) == u32::MAX {
            let err = GetLastError();
            // A child that can never run must not be left parked: libuv
            // terminates it and fails the spawn, and so does this.
            TerminateProcess(pi.hProcess, 1);
            CloseHandle(pi.hThread);
            CloseHandle(pi.hProcess);
            cleanup_fail(&child_close, &nul_handles);
            let ioe = std::io::Error::from_raw_os_error(err as i32);
            return Err(super::child::spawn_failure_json_with(
                &ioe,
                &format!("ResumeThread failed (GetLastError={err}) for {command}"),
            ));
        }

        // Parent no longer needs the child's pipe ends or the NUL handles.
        for h in &child_close {
            CloseHandle(*h);
        }
        for h in &nul_handles {
            CloseHandle(*h);
        }
        CloseHandle(pi.hThread);

        Ok(RawChild {
            process: Some(SendHandle(pi.hProcess)),
            pid: pi.dwProcessId,
            fds: parent_fds,
            kill_signal: None,
        })
    }
}

/// Read up to 64 KiB from a parent-readable fd end. EOF (0 bytes) -> Done.
pub async fn raw_read(reg: RawChildRegistry, id: u64, fd: u32) -> OpOutcome {
    let end = {
        let guard = reg.lock().unwrap_or_else(|e| e.into_inner());
        match guard.get(&id).and_then(|c| c.fds.get(&fd)) {
            Some(FdEnd::Read(end)) => Arc::clone(end),
            Some(FdEnd::Write(_)) => return OpOutcome::Failed(format!("fd {fd} is not readable")),
            None => return OpOutcome::Done,
        }
    };
    let reader = Arc::clone(&end);
    let result = tokio::task::spawn_blocking(move || reader.read_blocking()).await;
    match result {
        Ok(Ok(Some(bytes))) => OpOutcome::Bytes(bytes),
        // EOF, a failed read or a failed join all end the stream: the end
        // leaves the registry, and its handle closes with the last holder.
        Ok(Ok(None)) => {
            retire_read_end(&reg, id, fd, &end);
            OpOutcome::Done
        }
        Ok(Err(e)) => {
            retire_read_end(&reg, id, fd, &end);
            OpOutcome::Failed(e)
        }
        Err(e) => {
            retire_read_end(&reg, id, fd, &end);
            OpOutcome::Failed(format!("read join: {e}"))
        }
    }
}

/// Take a finished read end out of the registry -- only that end: the slot
/// may hold nothing else, but `Arc::ptr_eq` keeps this honest -- and drop the
/// child's entry once `raw_wait` has collected the exit and no end is left.
fn retire_read_end(reg: &RawChildRegistry, id: u64, fd: u32, end: &Arc<ReadEnd>) {
    let mut guard = reg.lock().unwrap_or_else(|e| e.into_inner());
    let Some(child) = guard.get_mut(&id) else {
        return;
    };
    if matches!(child.fds.get(&fd), Some(FdEnd::Read(e)) if Arc::ptr_eq(e, end)) {
        child.fds.remove(&fd);
    }
    if child.fds.is_empty() && child.process.is_none() {
        guard.remove(&id);
    }
}

/// Write all bytes to a parent-writable fd end.
pub async fn raw_write(reg: RawChildRegistry, id: u64, fd: u32, data: Vec<u8>) -> OpOutcome {
    let handle = {
        let mut guard = reg.lock().unwrap_or_else(|e| e.into_inner());
        match guard.get_mut(&id).and_then(|c| c.fds.get_mut(&fd)) {
            Some(FdEnd::Write(h)) => h.take(),
            Some(FdEnd::Read(_)) => return OpOutcome::Failed(format!("fd {fd} is not writable")),
            None => return OpOutcome::Failed(format!("unknown fd {fd}")),
        }
    };
    let Some(h) = handle else {
        return OpOutcome::Failed(format!("fd {fd} not available"));
    };
    // The owned end goes into the blocking task and comes back only on
    // success; every other path drops it, which is its close.
    let result = tokio::task::spawn_blocking(move || {
        let mut off = 0usize;
        while off < data.len() {
            let mut written: u32 = 0;
            // SAFETY: `h` is the open write handle this task owns; the
            // pointer/length are the head of the still-live `data` slice and
            // `written` is a live out-param.
            let ok = unsafe {
                WriteFile(
                    h.as_raw_handle(),
                    data[off..].as_ptr(),
                    (data.len() - off) as u32,
                    &mut written,
                    std::ptr::null_mut(),
                )
            };
            if ok == 0 {
                return Err(format!("WriteFile: {}", std::io::Error::last_os_error()));
            }
            if written == 0 {
                return Err("WriteFile wrote 0".to_string());
            }
            off += written as usize;
        }
        Ok(h)
    })
    .await;

    match result {
        Ok(Ok(h)) => {
            let mut guard = reg.lock().unwrap_or_else(|e| e.into_inner());
            if let Some(FdEnd::Write(slot)) = guard.get_mut(&id).and_then(|c| c.fds.get_mut(&fd)) {
                *slot = Some(h);
            }
            // else: the end was closed or the entry dropped mid-write; `h`
            // closes as it goes out of scope here.
            OpOutcome::Done
        }
        Ok(Err(e)) => OpOutcome::Failed(e),
        Err(e) => OpOutcome::Failed(format!("write join: {e}")),
    }
}

/// Close one parent-side fd end: end stdin or a CDP pipe, or `destroy()` a
/// readable one. A read blocked on the end is cancelled and reports EOF.
pub fn raw_close_fd(reg: &RawChildRegistry, id: u64, fd: u32) {
    let mut guard = reg.lock().unwrap_or_else(|e| e.into_inner());
    let Some(child) = guard.get_mut(&id) else {
        return;
    };
    // A read end is shared, so capture it before the entry goes to close it
    // (cancel a read blocked in ReadFile); a write end is taken by the entry
    // removal, which is the close.
    let read_end = match child.fds.get(&fd) {
        Some(FdEnd::Read(end)) => Some(Arc::clone(end)),
        Some(FdEnd::Write(_)) | None => None,
    };
    // Removing the entry drops a present write handle here -- AND drops the
    // slot, so a write still in flight (it holds its own handle and re-inserts
    // only while the slot is present) closes its handle when it finishes
    // instead of resurrecting the closed pipe.
    if child.fds.remove(&fd).is_some() {
        if let Some(end) = read_end {
            end.close();
        }
        if child.fds.is_empty() && child.process.is_none() {
            guard.remove(&id);
        }
    }
}

/// Record the kill signal and terminate the process. WaitForSingleObject in
/// `raw_wait` then returns and reports the exit.
pub fn raw_kill(reg: &RawChildRegistry, id: u64, signal: Option<String>) {
    let mut guard = reg.lock().unwrap_or_else(|e| e.into_inner());
    if let Some(child) = guard.get_mut(&id) {
        // raw_wait only COPIES the handle out of the registry (SendHandle is
        // Copy), so `process.is_some()` does not prove liveness: a child that
        // exited on its own still has Some(process). Poll the handle; only
        // record + terminate a process that is actually still running --
        // reporting a kill for a child that already exited would hide its
        // real exit code.
        if let Some(SendHandle(h)) = child.process {
            // WAIT_TIMEOUT (0x102) == still running.
            const WAIT_TIMEOUT: u32 = 0x102;
            // SAFETY: h is a live process handle; zero-timeout poll, no wait.
            let state = unsafe { WaitForSingleObject(h, 0) };
            if state == WAIT_TIMEOUT {
                child.kill_signal = signal;
                // SAFETY: h is a live process handle we own.
                unsafe { TerminateProcess(h, 1) };
            }
        }
    }
}

/// Wait for exit; returns Node-shaped {code, signal}. Closes all remaining
/// handles and drops the registry entry.
pub async fn raw_wait(reg: RawChildRegistry, id: u64) -> OpOutcome {
    let process = {
        let guard = reg.lock().unwrap_or_else(|e| e.into_inner());
        guard.get(&id).and_then(|c| c.process)
    };
    let Some(proc_h) = process else {
        return OpOutcome::Failed("unknown child handle".to_string());
    };

    let raw = proc_h.0 as usize;
    let exit = tokio::task::spawn_blocking(move || {
        let hh = raw as HANDLE;
        // SAFETY: `hh` is the live process handle copied out of the registry;
        // WaitForSingleObject only blocks on it and touches no memory of ours.
        let wait = unsafe { WaitForSingleObject(hh, INFINITE) };
        if wait != WAIT_OBJECT_0 {
            return Err(format!("WaitForSingleObject: {wait}"));
        }
        let mut code: u32 = 0;
        // SAFETY: `hh` is the same live (now-exited) process handle; `code` is a
        // live out-param the call writes.
        unsafe { GetExitCodeProcess(hh, &mut code) };
        Ok(code)
    })
    .await;

    // Close the process handle and the write ends. The READ ends stay: the
    // child is gone, but what it wrote before exiting may still sit in a pipe,
    // and a grandchild that inherited a write end can still be writing. Each
    // is read to its EOF, as node reads a child's stdio to the end before
    // 'close', and `retire_read_end` drops the entry with the last of them.
    // (Dropping the entry here, as this used to, turned the next read of a
    // pipe with data still in it into an early EOF.)
    let (kill_signal, proc_handle) = {
        let mut guard = reg.lock().unwrap_or_else(|e| e.into_inner());
        match guard.get_mut(&id) {
            Some(c) => {
                let out = (c.kill_signal.take(), c.process.take());
                c.fds.retain(|_, end| matches!(end, FdEnd::Read(_)));
                if c.fds.is_empty() {
                    guard.remove(&id);
                }
                out
            }
            None => (None, None),
        }
    };
    if let Some(SendHandle(h)) = proc_handle {
        // SAFETY: the process handle was removed from the registry above, so
        // this fn is its sole owner; close it once.
        unsafe { CloseHandle(h) };
    }

    match exit {
        Ok(Ok(code)) => {
            // A TerminateProcess(.,1) kill yields exit code 1; report Node-style
            // code:null + signal when we initiated the kill.
            let json = if let Some(sig) = kill_signal {
                serde_json::json!({ "code": null, "signal": sig })
            } else {
                serde_json::json!({ "code": code as i32, "signal": null })
            };
            OpOutcome::Json(json.to_string())
        }
        Ok(Err(e)) => OpOutcome::Failed(e),
        Err(e) => OpOutcome::Failed(format!("wait join: {e}")),
    }
}

#[cfg(test)]
mod env_block_tests {
    use super::build_env_block;

    fn pairs(list: &[(&str, &str)]) -> Vec<(String, String)> {
        list.iter()
            .map(|(k, v)| (k.to_string(), v.to_string()))
            .collect()
    }

    /// The block decoded back into its "k=v" entries, checking the shape
    /// CreateProcessW requires on the way: every entry NUL-terminated, then
    /// one more NUL.
    fn entries(block: &[u16]) -> Vec<String> {
        assert!(block.len() >= 2, "a block is at least the terminator pair");
        assert_eq!(&block[block.len() - 2..], &[0, 0], "double-NUL end");
        let body = &block[..block.len() - 1];
        if body == [0] {
            return Vec::new();
        }
        body.split(|&u| u == 0)
            .filter(|s| !s.is_empty())
            .map(String::from_utf16_lossy)
            .collect()
    }

    #[test]
    fn holds_exactly_the_given_pairs() {
        // A variable this process certainly has (the test runner sets PATH,
        // and Windows always has SystemRoot) must not appear unless given.
        let block = build_env_block(&pairs(&[("ONLY_ME", "1")]));
        assert_eq!(entries(&block), vec!["ONLY_ME=1"]);
    }

    #[test]
    fn an_empty_env_is_the_terminator_pair() {
        assert_eq!(build_env_block(&[]), vec![0, 0]);
    }

    #[test]
    fn a_hidden_drive_cwd_is_carried_only_when_given() {
        let block = build_env_block(&pairs(&[("A", "1")]));
        assert!(entries(&block).iter().all(|e| !e.starts_with('=')));
        let block = build_env_block(&pairs(&[("=C:", "C:\\work"), ("A", "1")]));
        assert_eq!(entries(&block), vec!["=C:=C:\\work", "A=1"]);
    }

    #[test]
    fn sorted_case_insensitively() {
        // Byte order would put "PATHEXT" and "Zeta" ahead of "Path" and
        // "alpha"; Windows wants the names compared as upper case.
        let block = build_env_block(&pairs(&[
            ("Zeta", "z"),
            ("PATHEXT", ".EXE"),
            ("alpha", "a"),
            ("Path", "C:\\bin"),
            ("_U", "u"),
        ]));
        assert_eq!(
            entries(&block),
            vec!["alpha=a", "Path=C:\\bin", "PATHEXT=.EXE", "Zeta=z", "_U=u"]
        );
    }

    #[test]
    fn of_names_differing_in_case_the_first_given_wins() {
        let block = build_env_block(&pairs(&[
            ("Foo", "first"),
            ("FOO", "second"),
            ("foo", "third"),
        ]));
        assert_eq!(entries(&block), vec!["Foo=first"]);
    }

    #[test]
    fn values_keep_equals_signs_and_non_ascii_text() {
        let block = build_env_block(&pairs(&[("K", "a=b=c"), ("NAME", "Zoë ✓")]));
        assert_eq!(entries(&block), vec!["K=a=b=c", "NAME=Zoë ✓"]);
    }
}

#[cfg(test)]
mod tests {
    use super::{FdEnd, RawChild, RawChildRegistry, StdioFd, raw_close_fd, raw_kill, spawn_extra};
    use std::collections::HashMap;
    use std::os::windows::io::{FromRawHandle, OwnedHandle};
    use std::sync::{Arc, Mutex};
    use std::time::{Duration, Instant};
    use windows_sys::Win32::Foundation::{
        CloseHandle, ERROR_BROKEN_PIPE, GetLastError, HANDLE, HANDLE_FLAG_INHERIT,
        SetHandleInformation,
    };
    use windows_sys::Win32::Security::SECURITY_ATTRIBUTES;
    use windows_sys::Win32::System::Pipes::{CreatePipe, PeekNamedPipe};

    /// A registry holding one child whose fd `fd` is a parent-WRITE pipe end,
    /// with the child's READ end returned so a test can watch the pipe break.
    /// `process: None` so `raw_close_fd` removes the whole entry once its fds
    /// are gone (the shape a spawned child has after `raw_wait`).
    fn write_end_registry(fd: u32) -> (RawChildRegistry, HANDLE) {
        // SAFETY: `SECURITY_ATTRIBUTES` is plain-old-data; zeroed then filled.
        let mut sa: SECURITY_ATTRIBUTES = unsafe { std::mem::zeroed() };
        sa.nLength = std::mem::size_of::<SECURITY_ATTRIBUTES>() as u32;
        sa.bInheritHandle = 1;
        let mut read_end: HANDLE = std::ptr::null_mut();
        let mut write_end: HANDLE = std::ptr::null_mut();
        // SAFETY: both out-params are live locals; the SECURITY_ATTRIBUTES is
        // fully initialized above.
        let ok = unsafe { CreatePipe(&mut read_end, &mut write_end, &sa, 0) };
        // SAFETY: the error code of the CreatePipe call just above, same thread.
        let pipe_err = unsafe { GetLastError() };
        assert_ne!(ok, 0, "CreatePipe failed: {pipe_err}");
        let mut fds = HashMap::new();
        // SAFETY: `write_end` is a fresh pipe handle this test owns and hands
        // to the OwnedHandle exactly once.
        fds.insert(
            fd,
            FdEnd::Write(Some(unsafe {
                OwnedHandle::from_raw_handle(write_end as _)
            })),
        );
        let child = RawChild {
            process: None,
            pid: 0,
            fds,
            kill_signal: None,
        };
        let reg: RawChildRegistry = Arc::new(Mutex::new(HashMap::new()));
        reg.lock()
            .unwrap_or_else(|e| e.into_inner())
            .insert(1u64, child);
        (reg, read_end)
    }

    /// `raw_close_fd` on an idle write end removes the fd entry (and, with no
    /// process left, the whole child) and drops the handle, which breaks the
    /// pipe: the child's read end sees ERROR_BROKEN_PIPE.
    #[test]
    fn raw_close_fd_of_an_idle_write_end_closes_the_pipe() {
        let (reg, read_end) = write_end_registry(3);
        raw_close_fd(&reg, 1, 3);
        assert!(
            reg.lock().unwrap_or_else(|e| e.into_inner()).is_empty(),
            "the entry goes with its last fd"
        );
        let mut avail: u32 = 0;
        // SAFETY: `read_end` is a live pipe handle; the null args are the
        // documented "no buffer, no bytes, no overlapped" form.
        let ok = unsafe {
            PeekNamedPipe(
                read_end,
                std::ptr::null_mut(),
                0,
                std::ptr::null_mut(),
                &mut avail,
                std::ptr::null_mut(),
            )
        };
        // SAFETY: the last call's error code; read immediately after it, on the
        // same thread, with no intervening Win32 call to overwrite it.
        let err = unsafe { GetLastError() };
        // SAFETY: `read_end` is still owned by this test and closed once.
        unsafe { CloseHandle(read_end) };
        assert!(
            ok == 0 && err == ERROR_BROKEN_PIPE,
            "the write handle must be closed (pipe broken), got ok={ok} err={err}"
        );
    }

    /// The resurrection bug: a `raw_write` in flight has TAKEN the handle out
    /// of the slot, so the slot is `Write(None)`. The old close
    /// (`drop(h.take())`) then dropped `None`, so it left the entry present --
    /// and when the write finished it RE-INSERTED its handle, resurrecting a
    /// pipe the caller had closed (`destroy()`). Modelling the in-flight state
    /// directly (rather than racing a real write) keeps the test deterministic:
    /// the slot is exactly what a pending write leaves, and the close must
    /// remove the entry so the write's re-insert no-ops.
    #[test]
    fn raw_close_fd_during_a_write_does_not_resurrect_the_pipe() {
        let (reg, read_end) = write_end_registry(3);
        // Move the handle out of the slot, as `raw_write` does before it blocks
        // in `WriteFile`; the slot is now `Write(None)`.
        {
            let mut guard = reg.lock().unwrap_or_else(|e| e.into_inner());
            let child = guard.get_mut(&1).expect("child");
            let Some(FdEnd::Write(slot)) = child.fds.get_mut(&3) else {
                panic!("fd 3 is a write end");
            };
            let taken = slot.take();
            assert!(taken.is_some(), "the write handle was in the slot");
        }
        raw_close_fd(&reg, 1, 3);
        assert!(
            reg.lock().unwrap_or_else(|e| e.into_inner()).is_empty(),
            "a close during a write must remove the entry, not leave Write(None) \
             for the write to re-insert"
        );
        // SAFETY: `read_end` is owned by this test, closed once.
        unsafe { CloseHandle(read_end) };
    }

    /// Regression for the spawn handle-inheritance race: a child must inherit
    /// ONLY the handles named in its stdio list, never an unrelated inheritable
    /// handle that merely happens to be open in the parent at spawn time.
    ///
    /// Before the PROC_THREAD_ATTRIBUTE_HANDLE_LIST fix,
    /// CreateProcessW(bInheritHandles=TRUE) handed the child EVERY inheritable
    /// handle in the process -- so the canary write end below would stay open in
    /// the child, and the parent (having closed its own copy) would never see
    /// the pipe break. With the fix, the child never receives it, so the parent
    /// becomes the sole owner and the read end reports ERROR_BROKEN_PIPE at once.
    #[test]
    fn spawn_extra_does_not_leak_unrelated_inheritable_handles() {
        // SAFETY: the test drives raw Win32 pipe/handle APIs (CreatePipe,
        // SetHandleInformation, PeekNamedPipe, CloseHandle) on handles it creates
        // and owns for the test's duration; every argument is a live local.
        unsafe {
            // Canary pipe: the read end stays the parent's (non-inheritable);
            // the write end is INHERITABLE but is deliberately NOT in any child
            // stdio list, so a correct spawn must not hand it to the child.
            let mut sa: SECURITY_ATTRIBUTES = std::mem::zeroed();
            sa.nLength = std::mem::size_of::<SECURITY_ATTRIBUTES>() as u32;
            sa.bInheritHandle = 1;
            let mut canary_read: HANDLE = std::ptr::null_mut();
            let mut canary_write: HANDLE = std::ptr::null_mut();
            assert_ne!(
                CreatePipe(&mut canary_read, &mut canary_write, &sa, 0),
                0,
                "CreatePipe(canary) failed: {}",
                GetLastError()
            );
            SetHandleInformation(canary_read, HANDLE_FLAG_INHERIT, 0);

            // A child that stays alive by blocking on stdin (the parent never
            // closes the write end), so if it DID inherit the canary it keeps it
            // open for the whole poll below. Only fds 0/1/2 are listed.
            let child = spawn_extra(
                "cmd",
                &["/c".to_string(), "more > nul".to_string()],
                None,
                None,
                &[StdioFd::ChildRead, StdioFd::Ignore, StdioFd::Ignore],
                false,
                false,
            )
            .expect("spawn_extra");

            // Drop the parent's own canary write end. The only write end that can
            // remain now is a leaked child copy; a correct spawn leaves none.
            CloseHandle(canary_write);

            let reg: RawChildRegistry = Arc::new(Mutex::new(HashMap::new()));
            reg.lock()
                .unwrap_or_else(|e| e.into_inner())
                .insert(1u64, child);

            // A correct spawn breaks the pipe (no write ends) within ms; a leak
            // keeps it open for the child's life (blocked on stdin -> forever),
            // so the deadline fails the test cleanly instead of hanging.
            let deadline = Instant::now() + Duration::from_secs(3);
            let mut broke = false;
            while Instant::now() < deadline {
                let mut avail: u32 = 0;
                let ok = PeekNamedPipe(
                    canary_read,
                    std::ptr::null_mut(),
                    0,
                    std::ptr::null_mut(),
                    &mut avail,
                    std::ptr::null_mut(),
                );
                if ok == 0 && GetLastError() == ERROR_BROKEN_PIPE {
                    broke = true;
                    break;
                }
                std::thread::sleep(Duration::from_millis(20));
            }

            raw_kill(&reg, 1, None);
            CloseHandle(canary_read);

            assert!(
                broke,
                "child inherited the unrelated canary handle -- inheritance is \
                 not being scoped to the handle list"
            );
        }
    }
}
