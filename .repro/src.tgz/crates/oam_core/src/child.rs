use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use tokio::sync::Notify;

use super::OpOutcome;

pub struct ChildProcess {
    /// The live child. Taken out of the registry entry by `child_wait` for the
    /// duration of the await, but the entry itself stays so a concurrent
    /// `child_kill` can still reach the kill-notifier below.
    ///
    /// stdin/stdout/stderr are stored as separate fields so that `child_wait`
    /// taking `child` (which has all three set to None) does not race with
    /// concurrent read/write ops. Without this separation a Windows Tokio
    /// scheduler that runs `spawnWait` before `spawnWrite` / `spawnReadStdout`
    /// causes those ops to see `child` as None and silently fail.
    pub child: Option<tokio::process::Child>,
    pub stdin: Option<tokio::process::ChildStdin>,
    pub stdout: Option<tokio::process::ChildStdout>,
    pub stderr: Option<tokio::process::ChildStderr>,
    /// Set while a read holds the stdout pipe out of the registry, so a
    /// concurrent second read sees the stream as busy rather than at EOF.
    pub stdout_busy: bool,
    /// Set while a read holds the stderr pipe out of the registry, so a
    /// concurrent second read sees the stream as busy rather than at EOF.
    pub stderr_busy: bool,
    pub pid: u32,
    /// Wakes the parked `child_wait` future, which owns the `Child` and is the
    /// only place that can signal it. Lets kill survive `child` being taken.
    pub kill: Arc<Notify>,
    /// Signal name the caller requested for the kill (Node reports it on exit).
    pub kill_signal: Option<String>,
}

impl ChildProcess {
    pub fn new(mut child: tokio::process::Child, pid: u32) -> Self {
        let stdin = child.stdin.take();
        let stdout = child.stdout.take();
        let stderr = child.stderr.take();
        ChildProcess {
            child: Some(child),
            stdin,
            stdout,
            stderr,
            stdout_busy: false,
            stderr_busy: false,
            pid,
            kill: Arc::new(Notify::new()),
            kill_signal: None,
        }
    }
}

pub type ChildRegistry = Arc<Mutex<HashMap<u64, ChildProcess>>>;

/// Per-fd disposition for a child's stdin/stdout/stderr, mirroring node's
/// `stdio` option.
///
/// `Inherit` is a real OS-level handle hand-off, not a pump: the child writes
/// straight to the parent's fd with no copy through this process, which is both
/// node's semantics and the only way a grandchild's stdio survives an
/// intermediate launcher (npm `bin` shims do exactly this).
///
/// `File` is the same idea for a slot the caller named by NUMBER -- the
/// daemonize-into-a-logfile shape, `stdio: ['ignore', logFd, logFd]`. Those
/// used to collapse to `Inherit`, so the output went to the parent's console
/// instead of the file the caller asked for; the engine now resolves the fd
/// against oam's descriptor registry and hands the child a dup.
///
/// NOT `Copy`: the `File` variant owns a descriptor.
#[derive(Debug, Default)]
pub enum StdioMode {
    /// `/dev/null` (NUL on Windows). Reads see EOF immediately; writes vanish.
    Ignore,
    /// The child gets the parent's own fd for this slot.
    Inherit,
    /// An anonymous pipe this process owns both ends of. Node's default.
    #[default]
    Pipe,
    /// A descriptor resolved from a numeric stdio slot. Already a dup, so
    /// handing it to the child does not disturb the caller's own fd.
    File(std::fs::File),
}

impl StdioMode {
    /// Decode the disposition wire form: 0=ignore, 1=inherit, anything else
    /// =pipe. A numbered slot never arrives here -- the engine resolves it to
    /// `File` before building the spec, because only it can reach the registry.
    pub fn from_code(code: u8) -> Self {
        match code {
            0 => StdioMode::Ignore,
            1 => StdioMode::Inherit,
            _ => StdioMode::Pipe,
        }
    }

    fn into_stdio(self) -> std::process::Stdio {
        match self {
            StdioMode::Ignore => std::process::Stdio::null(),
            StdioMode::Inherit => std::process::Stdio::inherit(),
            StdioMode::Pipe => std::process::Stdio::piped(),
            StdioMode::File(file) => std::process::Stdio::from(file),
        }
    }

    fn is_pipe(&self) -> bool {
        matches!(self, StdioMode::Pipe)
    }
}

/// stdin/stdout/stderr dispositions, in fd order.
pub type StdioSpec = [StdioMode; 3];

/// Node's default when `stdio` is absent: all three piped.
pub fn stdio_pipe_all() -> StdioSpec {
    [StdioMode::Pipe, StdioMode::Pipe, StdioMode::Pipe]
}

/// Spawn a child and return it with its pid. SYNCHRONOUS: node's uv_spawn is
/// synchronous, so `child.pid` must be readable the instant `spawn()` returns
/// (execa, tree-kill and pidusage all read it immediately). There are no
/// awaits in this body -- `tokio::process::Command::spawn` is itself a sync
/// call -- but it MUST run inside a tokio runtime context, because on Unix it
/// registers the child with the signal-driver reactor. Callers on the V8
/// thread must hold a `Handle::enter()` guard; see `CoreRuntime::enter`.
///
/// `env`, when given, is the child's WHOLE environment: nothing of this
/// process's own is added, as node hands libuv its envPairs and libuv hands
/// them to execve / CreateProcessW. The JS layer builds the pairs (process.env
/// when the script passed none, and libuv's Windows additions). `None` leaves
/// the child this process's environment, for callers that are not node APIs.
///
/// `detached` is node's option: on Windows it adds libuv's
/// `DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP` and keeps the child OUT of
/// the kill-on-close job (job_win.rs) every other child is placed in. It is
/// not yet honored on POSIX, where node would also `setsid()` the child.
///
/// `windows_hide` is node's `windowsHide`, which decides `CREATE_NO_WINDOW`
/// as libuv does (see `windows_creation_flags`). std's `Command` has no
/// stable way to set `wShowWindow`, so libuv's `SW_HIDE` for a GUI child is
/// not applied here; docs/node-divergences.md records it. Ignored on POSIX,
/// as under node.
#[allow(clippy::too_many_arguments)]
pub fn spawn_child(
    command: String,
    args: Vec<String>,
    cwd: Option<String>,
    env: Option<Vec<(String, String)>>,
    shell: bool,
    stdio: StdioSpec,
    detached: bool,
    windows_hide: bool,
) -> Result<(tokio::process::Child, u32), String> {
    let (prog, final_args) = if shell {
        #[cfg(windows)]
        {
            // cmd.exe parses its own quoting; Rust's default arg escaping
            // (MSVCRT rules) mangles a command that embeds quotes, so the
            // canonical `exec('"C:\path with spaces\app.exe" arg')` fails.
            // Node passes `/d /s /c "<command>"` with verbatim arguments --
            // /d skips AutoRun, /s + the wrapping quotes make cmd strip
            // exactly the outer pair. The raw_arg application is below.
            let mut full = command;
            for a in &args {
                full.push(' ');
                full.push_str(a);
            }
            (
                "cmd.exe".to_string(),
                vec![
                    "/d".to_string(),
                    "/s".to_string(),
                    "/c".to_string(),
                    format!("\"{full}\""),
                ],
            )
        }
        #[cfg(not(windows))]
        {
            let mut full = command;
            for a in &args {
                full.push(' ');
                full.push_str(a);
            }
            ("/bin/sh".to_string(), vec!["-c".to_string(), full])
        }
    } else {
        (command, args)
    };

    #[cfg(windows)]
    let prog = if shell {
        prog
    } else {
        match resolve_windows_program(&prog, cwd.as_deref()) {
            Ok(Some(resolved)) => resolved,
            Ok(None) => prog,
            Err(e) => return Err(spawn_failure_json(&e)),
        }
    };

    let mut cmd = tokio::process::Command::new(&prog);
    #[cfg(windows)]
    {
        if shell {
            // Verbatim: hand cmd.exe the string as written (node's
            // windowsVerbatimArguments). tokio's Command has raw_arg
            // natively; the sync path below needs the std CommandExt trait.
            for a in &final_args {
                cmd.raw_arg(a);
            }
        } else {
            cmd.args(&final_args);
        }
    }
    #[cfg(not(windows))]
    cmd.args(&final_args);
    // Read before the spec is consumed below.
    #[cfg(windows)]
    let inherits = stdio_inherits(&stdio);
    // Destructured, not indexed: a slot can now OWN a descriptor, so the spec
    // is consumed rather than copied.
    let [slot0, slot1, slot2] = stdio;
    cmd.stdin(slot0.into_stdio());
    cmd.stdout(slot1.into_stdio());
    cmd.stderr(slot2.into_stdio());

    if let Some(cwd) = cwd {
        cmd.current_dir(cwd);
    }
    if let Some(env) = env {
        // The child's whole environment (see spawn_child).
        cmd.env_clear();
        for (k, v) in env {
            cmd.env(k, v);
        }
    }

    #[cfg(windows)]
    {
        cmd.creation_flags(windows_creation_flags(detached, windows_hide, inherits));
    }
    #[cfg(not(windows))]
    let _ = (detached, windows_hide);

    let child = cmd.spawn().map_err(|e| spawn_failure_json(&e))?;
    // Right after spawn, not suspended: tokio's Command cannot resume a
    // suspended child. job_win.rs explains why that window is libuv's own.
    #[cfg(windows)]
    if !detached {
        super::job_win::adopt_tokio_child(&child);
    }
    let pid = child.id().unwrap_or(0);
    Ok((child, pid))
}

/// The JSON body a failed async spawn hands the JS layer: the node code, the
/// errno (null when there is none), and the OS message.
///
/// errno rides along: node emits it as the `code` argument of the 'close'
/// event for a child that never started, so the JS layer cannot reproduce
/// node's failure shape without it.
pub(crate) fn spawn_failure_json(e: &std::io::Error) -> String {
    spawn_failure_json_with(e, &e.to_string())
}

/// `spawn_failure_json` with a message of the caller's own.
pub(crate) fn spawn_failure_json_with(e: &std::io::Error, message: &str) -> String {
    let code = super::node_error_code(e);
    serde_json::json!({
        "code": code,
        "errno": super::node_errno(code, e),
        "message": message,
    })
    .to_string()
}

/// What spawning `prog` must run on Windows: libuv's program search
/// (`search_path` / `path_search_walk_ext` in src/win/process.c) for a name
/// with a path in it.
///
/// node resolves the program itself, before CreateProcessW, and libuv's search
/// is narrower than std's: it tries the name as given only when its last
/// component has an extension, then the name with `.com` appended, then with
/// `.exe` -- skipping anything whose attributes mark a directory, without
/// following a link -- and fails as ERROR_FILE_NOT_FOUND when nothing is
/// left. A relative name is taken from `cwd` when one is given. std instead
/// hands CreateProcessW whatever it was given, so a directory came back as
/// ERROR_ACCESS_DENIED (EPERM, which spawn() throws) where node reports ENOENT,
/// and an extensionless shell shim or a missing UNC share came back as EFTYPE
/// or UNKNOWN.
///
/// - `Ok(None)`: run `prog` as given; std reaches the same file.
/// - `Ok(Some(path))`: run `path`; std would reach a different file or none.
/// - `Err`: nothing libuv would run.
///
/// A bare name is left to std's PATH search: libuv also searches the working
/// directory and the CHILD's PATH first, a separate difference this does not
/// take on.
#[cfg(windows)]
pub(crate) fn resolve_windows_program(
    prog: &str,
    cwd: Option<&str>,
) -> std::io::Result<Option<String>> {
    use std::os::windows::fs::MetadataExt;
    use std::path::{Path, PathBuf};
    use windows_sys::Win32::Storage::FileSystem::FILE_ATTRIBUTE_DIRECTORY;

    if !(prog.contains(['/', '\\']) || prog == "." || prog == "..") {
        return Ok(None);
    }
    let path = Path::new(prog);
    let from_cwd = cwd.is_some() && path.is_relative();
    let full = match cwd {
        Some(cwd) if path.is_relative() => Path::new(cwd).join(path),
        _ => path.to_path_buf(),
    };
    let last = prog.rsplit(['/', '\\']).next().unwrap_or(prog);
    let has_ext = last.rfind('.').is_some_and(|dot| dot + 1 < last.len());
    let runnable = |p: &Path| {
        std::fs::symlink_metadata(p)
            .is_ok_and(|m| m.file_attributes() & FILE_ATTRIBUTE_DIRECTORY == 0)
    };
    let with = |ext: &str| {
        let mut name = full.clone().into_os_string();
        name.push(ext);
        PathBuf::from(name)
    };
    let as_given = |p: PathBuf, std_reaches_it: bool| {
        if std_reaches_it && !from_cwd {
            Ok(None)
        } else {
            Ok(Some(p.to_string_lossy().into_owned()))
        }
    };
    if has_ext && runnable(&full) {
        return as_given(full, true);
    }
    let com = with(".com");
    if runnable(&com) {
        return as_given(com, false);
    }
    let exe = with(".exe");
    if runnable(&exe) {
        // std appends `.exe` to a name without an extension on its own.
        return as_given(exe, !has_ext);
    }
    Err(std::io::Error::from_raw_os_error(
        windows_sys::Win32::Foundation::ERROR_FILE_NOT_FOUND as i32,
    ))
}

#[cfg(all(test, windows))]
mod program_search_tests {
    use super::resolve_windows_program as resolve;

    #[test]
    fn a_program_path_follows_libuvs_search() {
        let root = std::env::temp_dir().join(format!("oam-program-search-{}", std::process::id()));
        std::fs::create_dir_all(root.join("tool")).unwrap();
        std::fs::create_dir_all(root.join("dir.exe")).unwrap();
        std::fs::write(root.join("shim"), b"#!/bin/sh\n").unwrap();
        std::fs::write(root.join("shim.cmd"), b"@exit 0\r\n").unwrap();
        std::fs::write(root.join("real.exe"), b"MZ").unwrap();
        std::fs::write(root.join("script.txt"), b"hi").unwrap();
        let r = |name: &str| root.join(name).to_str().unwrap().to_string();
        let not_found =
            |result: std::io::Result<Option<String>>| result.unwrap_err().raw_os_error() == Some(2);

        // A directory, with or without an extension, is never the program.
        assert!(not_found(resolve(&r("tool"), None)));
        assert!(not_found(resolve(&r("dir.exe"), None)));
        assert!(not_found(resolve(".", None)));
        // No extension: the name itself is not tried, only .com and .exe.
        assert!(not_found(resolve(&r("shim"), None)));
        assert!(not_found(resolve(&r("missing"), None)));
        // With an extension the name is tried as given, whatever it holds.
        assert_eq!(resolve(&r("script.txt"), None).unwrap(), None);
        assert_eq!(resolve(&r("real.exe"), None).unwrap(), None);
        // std appends .exe itself, so `real` needs no rewrite...
        assert_eq!(resolve(&r("real"), None).unwrap(), None);
        // ...but a relative name is resolved from `cwd`, where std would not.
        let root_s = root.to_str().unwrap();
        assert_eq!(
            resolve(".\\real.exe", Some(root_s)).unwrap(),
            Some(root.join(".\\real.exe").to_string_lossy().into_owned())
        );
        // A bare name is left to the PATH search.
        assert_eq!(resolve("cmd", None).unwrap(), None);
        // libuv tries .com before .exe, and std never tries .com.
        std::fs::write(root.join("tool.com"), b"MZ").unwrap();
        assert_eq!(
            resolve(&r("tool"), None).unwrap(),
            Some(format!("{}.com", r("tool")))
        );

        std::fs::remove_dir_all(&root).unwrap();
    }
}

/// The errno for a spawnSync failure oam detects itself (a timeout, an
/// overflowing buffer), which has no OS error to take it from.
fn synthetic_spawn_errno(code: &str) -> Option<i32> {
    #[cfg(windows)]
    {
        // The windows table is keyed on the code alone.
        super::node_errno(code, &std::io::Error::other(code))
    }
    #[cfg(unix)]
    {
        match code {
            "ETIMEDOUT" => Some(-libc::ETIMEDOUT),
            "ENOBUFS" => Some(-libc::ENOBUFS),
            _ => None,
        }
    }
}

/// Windows creation flags for a `child_process` spawn, as libuv's
/// `uv_spawn` (src/win/process.c) computes them from node's options.
///
/// `CREATE_NO_WINDOW` is set for `windowsHide: true` when no stdio slot is
/// inherited (`inherits` -- libuv's `UV_INHERIT_FD`: an `'inherit'` slot or
/// a numbered descriptor). It is NOT set by default: a console child then
/// shares this process's console, where `CREATE_NO_WINDOW` makes Windows
/// start a fresh hidden conhost.exe for every child -- about 35 ms a spawn,
/// which node pays only when the caller asks for `windowsHide`.
///
/// The one place oam still adds it unasked is a process with NO console of
/// its own (started detached, or by a GUI program): there node's child gets a
/// new console with a VISIBLE window (measured: node v22.22.2 run detached,
/// its `windowsHide: false` grandchild reports a visible console window).
/// That child needs a new console either way, so the flag costs nothing and
/// only keeps the window from popping up; docs/node-divergences.md has it.
///
/// `detached` adds libuv's `DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP` --
/// no console of the parent's and no share of its Ctrl+C. CreateProcessW
/// ignores `CREATE_NO_WINDOW` alongside `DETACHED_PROCESS`, so the
/// no-console rule is skipped there.
#[cfg(windows)]
pub(crate) fn windows_creation_flags(detached: bool, windows_hide: bool, inherits: bool) -> u32 {
    creation_flags_for(detached, windows_hide, inherits, has_console)
}

/// `windows_creation_flags` with the console probe passed in, so the table
/// can be tested whatever console the test runner has. The probe runs only
/// when its answer matters.
#[cfg(windows)]
fn creation_flags_for(
    detached: bool,
    windows_hide: bool,
    inherits: bool,
    has_console: impl FnOnce() -> bool,
) -> u32 {
    use windows_sys::Win32::System::Threading::{
        CREATE_NEW_PROCESS_GROUP, CREATE_NO_WINDOW, DETACHED_PROCESS,
    };
    let mut flags = 0;
    if (windows_hide && !inherits) || (!detached && !has_console()) {
        flags |= CREATE_NO_WINDOW;
    }
    if detached {
        flags |= DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP;
    }
    flags
}

#[cfg(all(test, windows))]
mod creation_flags_tests {
    use super::creation_flags_for;
    use windows_sys::Win32::System::Threading::{
        CREATE_NEW_PROCESS_GROUP, CREATE_NO_WINDOW, DETACHED_PROCESS,
    };
    const DETACHED: u32 = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP;

    #[test]
    fn follows_libuv_with_a_console() {
        let with = || true;
        // node's default: no flag, so the child shares this console.
        assert_eq!(creation_flags_for(false, false, false, with), 0);
        // windowsHide with every slot piped or ignored.
        assert_eq!(
            creation_flags_for(false, true, false, with),
            CREATE_NO_WINDOW
        );
        // An inherited slot vetoes it, as UV_INHERIT_FD does in libuv.
        assert_eq!(creation_flags_for(false, true, true, with), 0);
        assert_eq!(creation_flags_for(true, false, false, with), DETACHED);
        assert_eq!(
            creation_flags_for(true, true, false, with),
            DETACHED | CREATE_NO_WINDOW
        );
    }

    #[test]
    fn a_console_less_parent_never_gives_a_child_a_window() {
        let without = || false;
        assert_eq!(
            creation_flags_for(false, false, false, without),
            CREATE_NO_WINDOW
        );
        assert_eq!(
            creation_flags_for(false, true, true, without),
            CREATE_NO_WINDOW
        );
        // DETACHED_PROCESS already means no console at all.
        assert_eq!(creation_flags_for(true, false, false, without), DETACHED);
    }
}

/// Whether this process is attached to a console. `GetConsoleWindow` is not
/// the test: a process started with `CREATE_NO_WINDOW` has a console with no
/// window, which its children share without any window appearing.
/// `GetConsoleCP` fails (0) only when there is no console at all.
#[cfg(windows)]
fn has_console() -> bool {
    // SAFETY: GetConsoleCP takes no arguments and touches no memory of ours;
    // it reads the code page of the console this process is attached to, or
    // fails with 0 when there is none.
    unsafe { windows_sys::Win32::System::Console::GetConsoleCP() != 0 }
}

/// libuv's `UV_INHERIT_FD` test over a std spawn's three slots: an inherited
/// slot or a numbered descriptor. It decides whether `windowsHide` may add
/// `CREATE_NO_WINDOW` (see `windows_creation_flags`).
#[cfg(windows)]
fn stdio_inherits(stdio: &StdioSpec) -> bool {
    stdio
        .iter()
        .any(|s| matches!(s, StdioMode::Inherit | StdioMode::File(_)))
}

#[allow(clippy::too_many_arguments)]
pub fn spawn_sync(
    command: &str,
    args: &[String],
    cwd: Option<&str>,
    env: Option<&[(String, String)]>,
    input: Option<&[u8]>,
    shell: bool,
    timeout_ms: u64,
    max_buffer: usize,
    stdio: StdioSpec,
    detached: bool,
    windows_hide: bool,
) -> SpawnSyncResult {
    let (prog, final_args) = if shell {
        #[cfg(windows)]
        {
            // Same cmd.exe verbatim-quoting contract as spawn_child above.
            let mut full = command.to_string();
            for a in args {
                full.push(' ');
                full.push_str(a);
            }
            (
                "cmd.exe".to_string(),
                vec![
                    "/d".to_string(),
                    "/s".to_string(),
                    "/c".to_string(),
                    format!("\"{full}\""),
                ],
            )
        }
        #[cfg(not(windows))]
        {
            let mut full = command.to_string();
            for a in args {
                full.push(' ');
                full.push_str(a);
            }
            ("/bin/sh".to_string(), vec!["-c".to_string(), full])
        }
    } else {
        (command.to_string(), args.to_vec())
    };

    #[cfg(windows)]
    let (prog, unresolved) = if shell {
        (prog, None)
    } else {
        match resolve_windows_program(&prog, cwd) {
            Ok(Some(resolved)) => (resolved, None),
            Ok(None) => (prog, None),
            Err(e) => (prog, Some(e)),
        }
    };
    let mut cmd = std::process::Command::new(&prog);
    #[cfg(windows)]
    {
        if shell {
            use std::os::windows::process::CommandExt;
            for a in &final_args {
                cmd.raw_arg(a);
            }
        } else {
            cmd.args(&final_args);
        }
    }
    #[cfg(not(windows))]
    cmd.args(&final_args);
    // `input` is pumped ONLY into a slot that is already pipe-shaped.
    //
    // Node's docs say `input` "will override stdio[0]", but v22 does not
    // implement that sentence: it attaches the buffer to the slot-0 descriptor
    // and leaves the descriptor's TYPE alone, and the sync spawn only feeds
    // slots typed 'pipe'. So an explicit 'ignore'/'inherit' wins and the bytes
    // are never delivered. Measured, same script both runtimes:
    //   stdio omitted / 'pipe'        -> child reads "HELLO"
    //   stdio ['ignore','pipe','pipe'] -> child reads "" on node
    // Parity is with the implementation, not with the sentence -- the
    // conformance suite diffs against real node, and matching the doc here
    // would be a divergence that only looks like correctness.
    //
    // A pipe-shaped slot stays a real PIPE even with no input to write: the
    // `drop(child.stdin.take())` below closes the write end immediately, so the
    // child still sees EOF -- but over a pipe, as node gives it. Substituting
    // the null device here would have been observably different, not merely
    // "EOF by another route": the child's fd 0 becomes a character device, so
    // `fstatSync(0).isCharacterDevice()` flips and 'pipe' stops being
    // distinguishable from 'ignore' to a child that inspects its own stdin.
    #[cfg(windows)]
    let inherits = stdio_inherits(&stdio);
    let [slot0, slot1, slot2] = stdio;
    cmd.stdin(if slot0.is_pipe() {
        std::process::Stdio::piped()
    } else {
        slot0.into_stdio()
    });
    cmd.stdout(slot1.into_stdio());
    cmd.stderr(slot2.into_stdio());
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        // windowsHide as spawn_child applies it (and with the same SW_HIDE gap).
        cmd.creation_flags(windows_creation_flags(detached, windows_hide, inherits));
    }
    #[cfg(not(windows))]
    let _ = (detached, windows_hide);

    if let Some(cwd) = cwd {
        cmd.current_dir(cwd);
    }
    if let Some(env) = env {
        // The child's whole environment (see spawn_child).
        cmd.env_clear();
        for (k, v) in env {
            cmd.env(k, v);
        }
    }

    #[cfg(windows)]
    let spawned = match unresolved {
        Some(e) => Err(e),
        None => cmd.spawn(),
    };
    #[cfg(not(windows))]
    let spawned = cmd.spawn();
    let mut child = match spawned {
        Ok(c) => c,
        Err(e) => {
            let code = super::node_error_code(&e);
            return SpawnSyncResult {
                stdout: Vec::new(),
                stderr: Vec::new(),
                status: None,
                signal: None,
                pid: 0,
                error: Some(SpawnSyncError {
                    code: code.to_string(),
                    errno: super::node_errno(code, &e),
                    message: e.to_string(),
                }),
            };
        }
    };

    // Node's spawnSync goes through uv_spawn too, so a child it is blocked on
    // still dies if this process is killed mid-wait. std's Command cannot
    // resume a suspended child either; same post-spawn assignment as above.
    #[cfg(windows)]
    if !detached {
        use std::os::windows::io::AsHandle;
        super::job_win::adopt(child.as_handle());
    }

    let pid = child.id();

    if let Some(input) = input
        && let Some(mut stdin) = child.stdin.take()
    {
        use std::io::Write;
        let _ = stdin.write_all(input);
    }
    drop(child.stdin.take());

    let output = if timeout_ms > 0 {
        // The child stays REACHABLE here rather than being moved into a worker
        // that owns it. `wait_with_output()` consumes the Child, so the old
        // shape had nothing left to kill when the deadline passed: spawnSync
        // returned ETIMEDOUT while the child ran on holding its port, its lock
        // and -- now that `stdio: 'inherit'` is honored -- the parent's console.
        // The worker was also left parked on a wait that might never return.
        //
        // Pipes are drained on their own threads so a child that fills one
        // cannot deadlock against our wait, which is the reason
        // `wait_with_output` exists in the first place.
        use std::io::Read;
        let mut out_pipe = child.stdout.take();
        let mut err_pipe = child.stderr.take();
        let out_thread = std::thread::spawn(move || {
            let mut buf = Vec::new();
            if let Some(p) = out_pipe.as_mut() {
                let _ = p.read_to_end(&mut buf);
            }
            buf
        });
        let err_thread = std::thread::spawn(move || {
            let mut buf = Vec::new();
            if let Some(p) = err_pipe.as_mut() {
                let _ = p.read_to_end(&mut buf);
            }
            buf
        });

        let deadline = std::time::Instant::now() + std::time::Duration::from_millis(timeout_ms);
        let mut timed_out = false;
        let mut wait_err = None;
        let status = loop {
            match child.try_wait() {
                Ok(Some(status)) => break Some(status),
                Ok(None) => {
                    if std::time::Instant::now() >= deadline {
                        let _ = child.kill();
                        // Reap it, so the timeout path leaves no zombie.
                        let _ = child.wait();
                        timed_out = true;
                        break None;
                    }
                    std::thread::sleep(std::time::Duration::from_millis(5));
                }
                Err(e) => {
                    wait_err = Some(e);
                    break None;
                }
            }
        };
        // The pipes close when the child dies, so these joins cannot outlive it.
        let mut stdout = out_thread.join().unwrap_or_default();
        let mut stderr = err_thread.join().unwrap_or_default();

        if timed_out {
            // node hands back whatever the child managed to emit before the
            // deadline, not an empty pair.
            stdout.truncate(max_buffer);
            stderr.truncate(max_buffer);
            return SpawnSyncResult {
                stdout,
                stderr,
                status: None,
                signal: Some("SIGTERM".to_string()),
                pid,
                error: Some(SpawnSyncError {
                    code: "ETIMEDOUT".to_string(),
                    errno: synthetic_spawn_errno("ETIMEDOUT"),
                    message: format!("spawnSync timed out after {timeout_ms}ms"),
                }),
            };
        }
        match (status, wait_err) {
            (Some(status), _) => Ok(std::process::Output {
                status,
                stdout,
                stderr,
            }),
            (None, Some(e)) => Err(e),
            (None, None) => Err(std::io::Error::other("spawnSync: child never exited")),
        }
    } else {
        child.wait_with_output()
    };

    match output {
        Ok(output) => {
            let mut stdout = output.stdout;
            let mut stderr = output.stderr;
            // Blowing maxBuffer is an ERROR, not a quiet trim. Truncating and
            // reporting status 0 handed callers a short result that looked
            // complete -- a half JSON document that parses as valid, a log tail
            // that reads as the whole log -- while every node-shaped caller
            // (`if (result.error) throw`, or execSync's throw) saw nothing to
            // branch on. node terminates the child and reports ENOBUFS with a
            // null status; the output it kept is read-granularity dependent, so
            // the retained length is deliberately not part of the contract.
            let overflowed = stdout.len() > max_buffer || stderr.len() > max_buffer;
            stdout.truncate(max_buffer);
            stderr.truncate(max_buffer);
            if overflowed {
                return SpawnSyncResult {
                    stdout,
                    stderr,
                    status: None,
                    signal: Some("SIGTERM".to_string()),
                    pid,
                    error: Some(SpawnSyncError {
                        code: "ENOBUFS".to_string(),
                        errno: synthetic_spawn_errno("ENOBUFS"),
                        message: format!("spawnSync {command} ENOBUFS"),
                    }),
                };
            }
            let status = output.status.code();
            SpawnSyncResult {
                stdout,
                stderr,
                status,
                signal: None,
                pid,
                error: None,
            }
        }
        Err(e) => SpawnSyncResult {
            stdout: Vec::new(),
            stderr: Vec::new(),
            status: None,
            signal: None,
            pid,
            error: Some(SpawnSyncError {
                code: super::node_error_code(&e).to_string(),
                errno: super::node_errno(super::node_error_code(&e), &e),
                message: e.to_string(),
            }),
        },
    }
}

pub struct SpawnSyncResult {
    pub stdout: Vec<u8>,
    pub stderr: Vec<u8>,
    pub status: Option<i32>,
    pub signal: Option<String>,
    pub pid: u32,
    pub error: Option<SpawnSyncError>,
}

pub struct SpawnSyncError {
    pub code: String,
    /// The libuv errno node puts on `result.error.errno`.
    pub errno: Option<i32>,
    pub message: String,
}

pub async fn child_read_stdout(children: ChildRegistry, handle: u64) -> OpOutcome {
    // Check-and-set atomically under one lock. A concurrent second read sees
    // busy=true and WAITS for the in-flight read to release the pipe rather
    // than failing, so the pump's 'close' path cannot stall on a rejected
    // read promise. A None pipe with busy=false is a real EOF (stream closed
    // / never piped). The guard is dropped before the yield, so no lock is
    // held across the await; the loop always terminates because the in-flight
    // read clears busy on every exit path (bounded by data/EOF/child death).
    let stdout = loop {
        let taken = {
            let mut guard = children.lock().unwrap_or_else(|e| e.into_inner());
            match guard.get_mut(&handle) {
                Some(cp) if cp.stdout_busy => None,
                Some(cp) => match cp.stdout.take() {
                    Some(pipe) => {
                        cp.stdout_busy = true;
                        Some(Some(pipe))
                    }
                    None => Some(None),
                },
                None => Some(None),
            }
        };
        match taken {
            Some(pipe) => break pipe,
            None => tokio::task::yield_now().await,
        }
    };
    match stdout {
        Some(mut stdout) => {
            use tokio::io::AsyncReadExt;
            let mut buf = vec![0u8; 65536];
            match stdout.read(&mut buf).await {
                Ok(0) => {
                    // Real EOF: the pipe is dropped, not re-inserted. Clear busy.
                    let mut guard = children.lock().unwrap_or_else(|e| e.into_inner());
                    if let Some(cp) = guard.get_mut(&handle) {
                        cp.stdout_busy = false;
                    }
                    OpOutcome::Done
                }
                Ok(n) => {
                    buf.truncate(n);
                    let mut guard = children.lock().unwrap_or_else(|e| e.into_inner());
                    if let Some(cp) = guard.get_mut(&handle) {
                        cp.stdout = Some(stdout);
                        cp.stdout_busy = false;
                    }
                    OpOutcome::Bytes(buf)
                }
                Err(e) => {
                    // Read error: the pipe is dropped, not re-inserted. Clear busy.
                    let mut guard = children.lock().unwrap_or_else(|e| e.into_inner());
                    if let Some(cp) = guard.get_mut(&handle) {
                        cp.stdout_busy = false;
                    }
                    OpOutcome::Failed(format!("read stdout: {e}"))
                }
            }
        }
        None => OpOutcome::Done,
    }
}

pub async fn child_read_stderr(children: ChildRegistry, handle: u64) -> OpOutcome {
    // Check-and-set atomically under one lock. A concurrent second read sees
    // busy=true and WAITS for the in-flight read to release the pipe rather
    // than failing, so the pump's 'close' path cannot stall on a rejected
    // read promise. A None pipe with busy=false is a real EOF (stream closed
    // / never piped). The guard is dropped before the yield, so no lock is
    // held across the await; the loop always terminates because the in-flight
    // read clears busy on every exit path (bounded by data/EOF/child death).
    let stderr = loop {
        let taken = {
            let mut guard = children.lock().unwrap_or_else(|e| e.into_inner());
            match guard.get_mut(&handle) {
                Some(cp) if cp.stderr_busy => None,
                Some(cp) => match cp.stderr.take() {
                    Some(pipe) => {
                        cp.stderr_busy = true;
                        Some(Some(pipe))
                    }
                    None => Some(None),
                },
                None => Some(None),
            }
        };
        match taken {
            Some(pipe) => break pipe,
            None => tokio::task::yield_now().await,
        }
    };
    match stderr {
        Some(mut stderr) => {
            use tokio::io::AsyncReadExt;
            let mut buf = vec![0u8; 65536];
            match stderr.read(&mut buf).await {
                Ok(0) => {
                    // Real EOF: the pipe is dropped, not re-inserted. Clear busy.
                    let mut guard = children.lock().unwrap_or_else(|e| e.into_inner());
                    if let Some(cp) = guard.get_mut(&handle) {
                        cp.stderr_busy = false;
                    }
                    OpOutcome::Done
                }
                Ok(n) => {
                    buf.truncate(n);
                    let mut guard = children.lock().unwrap_or_else(|e| e.into_inner());
                    if let Some(cp) = guard.get_mut(&handle) {
                        cp.stderr = Some(stderr);
                        cp.stderr_busy = false;
                    }
                    OpOutcome::Bytes(buf)
                }
                Err(e) => {
                    // Read error: the pipe is dropped, not re-inserted. Clear busy.
                    let mut guard = children.lock().unwrap_or_else(|e| e.into_inner());
                    if let Some(cp) = guard.get_mut(&handle) {
                        cp.stderr_busy = false;
                    }
                    OpOutcome::Failed(format!("read stderr: {e}"))
                }
            }
        }
        None => OpOutcome::Done,
    }
}

pub fn child_close_stdin(children: &ChildRegistry, handle: u64) {
    let mut guard = children.lock().unwrap_or_else(|e| e.into_inner());
    if let Some(cp) = guard.get_mut(&handle) {
        drop(cp.stdin.take());
    }
}

pub async fn child_write_stdin(children: ChildRegistry, handle: u64, data: Vec<u8>) -> OpOutcome {
    let stdin = {
        let mut guard = children.lock().unwrap_or_else(|e| e.into_inner());
        guard.get_mut(&handle).and_then(|cp| cp.stdin.take())
    };
    match stdin {
        Some(mut stdin) => {
            use tokio::io::AsyncWriteExt;
            match stdin.write_all(&data).await {
                Ok(()) => {
                    let mut guard = children.lock().unwrap_or_else(|e| e.into_inner());
                    if let Some(cp) = guard.get_mut(&handle) {
                        cp.stdin = Some(stdin);
                    }
                    OpOutcome::Done
                }
                Err(e) => OpOutcome::Failed(format!("write stdin: {e}")),
            }
        }
        None => OpOutcome::Failed("stdin not available".to_string()),
    }
}

/// Signal a child to terminate. Wakes the parked `child_wait` future (the only
/// owner of the `Child`), which performs the actual kill. Survives `child_wait`
/// having already taken the `Child` out of the registry entry.
pub fn child_kill(children: &ChildRegistry, handle: u64, signal: Option<String>) {
    let mut guard = children.lock().unwrap_or_else(|e| e.into_inner());
    if let Some(cp) = guard.get_mut(&handle) {
        cp.kill_signal = signal;
        // notify_one stores a permit if the wait future has not parked yet, so
        // a kill issued before child_wait starts still lands.
        cp.kill.notify_one();
    }
}

pub async fn child_wait(children: ChildRegistry, handle: u64) -> OpOutcome {
    // Take the Child for the await but leave the registry entry in place so a
    // concurrent child_kill can still reach the kill-notifier. `pid` rides along
    // for the Unix kill path, which delivers the real POSIX signal by pid.
    let taken = {
        let mut guard = children.lock().unwrap_or_else(|e| e.into_inner());
        match guard.get_mut(&handle) {
            Some(cp) => cp.child.take().map(|c| (c, cp.kill.clone(), cp.pid)),
            None => None,
        }
    };
    let Some((mut child, kill, pid)) = taken else {
        return OpOutcome::Failed("unknown child handle".to_string());
    };

    let killed;
    let status = tokio::select! {
        s = child.wait() => { killed = false; s }
        _ = kill.notified() => {
            killed = true;
            // Read the signal child_kill recorded (stored under the lock BEFORE
            // notify_one, so it is visible here) and deliver it for real.
            let requested = {
                let guard = children.lock().unwrap_or_else(|e| e.into_inner());
                guard.get(&handle).and_then(|cp| cp.kill_signal.clone())
            };
            deliver_kill(&mut child, pid, requested.as_deref());
            child.wait().await
        }
    };

    // Drop the registry entry now that the wait is done, capturing the requested
    // kill signal (used by the Windows exit report).
    let requested_signal = {
        let mut guard = children.lock().unwrap_or_else(|e| e.into_inner());
        let sig = guard.get(&handle).and_then(|cp| cp.kill_signal.clone());
        guard.remove(&handle);
        sig
    };

    match status {
        Ok(status) => {
            let (code, signal) = exit_report(&status, killed, requested_signal);
            let json = serde_json::json!({ "code": code, "signal": signal });
            OpOutcome::Json(json.to_string())
        }
        Err(e) => OpOutcome::Failed(format!("wait: {e}")),
    }
}

/// Deliver a kill to `child`. On Unix this sends the caller's REQUESTED POSIX
/// signal (default SIGTERM) via `kill(2)` on the pid, so a child can trap
/// SIGTERM / SIGINT and shut down gracefully -- matching Node. `child.wait()`
/// still reaps the exit afterward: tokio's SIGCHLD reaper observes the death
/// regardless of which signal (or sender) caused it. On Windows there are no
/// POSIX signals, so `start_kill()` (TerminateProcess) is the only mechanism;
/// the requested signal name is surfaced by `exit_report` instead.
#[cfg(unix)]
fn deliver_kill(child: &mut tokio::process::Child, pid: u32, signal: Option<&str>) {
    // Only signal while the child is still alive. If it already exited and the
    // SIGCHLD driver reaped it, the kernel can recycle the pid immediately, so
    // a kill then could hit an unrelated process. On a try_wait error we fall
    // through and signal anyway (conservative).
    if let Ok(Some(_)) = child.try_wait() {
        return;
    }
    // Unknown signal names fall back to SIGTERM, pending JS-side validation.
    let signum = signal
        .map(crate::child_unix::signal_number)
        .unwrap_or(Some(libc::SIGTERM))
        .unwrap_or(libc::SIGTERM);
    crate::child_unix::deliver_signal(pid, signum);
}

#[cfg(windows)]
fn deliver_kill(child: &mut tokio::process::Child, _pid: u32, _signal: Option<&str>) {
    // TerminateProcess -- the only kill Windows offers. exit_report maps the
    // requested signal name onto the exit event.
    let _ = child.start_kill();
}

/// Build the Node-shaped `(code, signal)` exit report from the child's ACTUAL
/// exit status.
///
/// Unix: a signal-terminated child reports `code:null` + the real terminating
/// signal, so a child that caught our SIGTERM and `exit(0)`ed reports
/// `{code:0, signal:null}`, while one killed by the default action reports
/// `{code:null, signal:SIGTERM}`. `killed` / `requested_signal` are unused --
/// `WIFSIGNALED` is the source of truth.
///
/// Windows: the status carries no POSIX signal, so when WE initiated the kill
/// report `code:null` + the requested name (Node's Windows convention);
/// otherwise the exit code.
#[cfg(unix)]
fn exit_report(
    status: &std::process::ExitStatus,
    _killed: bool,
    _requested_signal: Option<String>,
) -> (Option<i32>, Option<String>) {
    use std::os::unix::process::ExitStatusExt;
    if let Some(signum) = status.signal() {
        (None, Some(crate::child_unix::signal_name(signum)))
    } else {
        (status.code(), None)
    }
}

#[cfg(windows)]
fn exit_report(
    status: &std::process::ExitStatus,
    killed: bool,
    requested_signal: Option<String>,
) -> (Option<i32>, Option<String>) {
    if killed {
        (
            None,
            Some(requested_signal.unwrap_or_else(|| "SIGTERM".to_string())),
        )
    } else {
        (status.code(), None)
    }
}
