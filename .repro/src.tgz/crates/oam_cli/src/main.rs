//! The `oam` CLI.
//!
//! M1 slice 1 surface: `oam run <file.{js,mjs,cjs,ts,mts,cts}>`. TypeScript
//! is transpiled (types stripped, enums lowered) before execution — strictly
//! more than Node's strip-only support, and typed where Bun is types-blind.
//! All failures render from ODIF diagnostics: `--json` emits the JSONL
//! source of truth, the pretty printer is a renderer over the same data.

mod self_update;

use clap::{Parser, Subcommand};
use oam_diagnostics::own_files::{self, Audience};
use oam_diagnostics::{Diagnostic, Origin, Severity};
use oam_loader::SourceKind;
use std::io::{Read as _, Seek as _, SeekFrom};
use std::path::{Path, PathBuf};
use std::process::ExitCode;

#[derive(Parser)]
#[command(
    name = "oam",
    version,
    about = "oam — the reliable TypeScript runtime for the AI era"
)]
struct Cli {
    /// No subcommand drops into the typed REPL.
    #[command(subcommand)]
    command: Option<Command>,
    /// Emit machine-readable ODIF JSONL on stderr instead of pretty errors.
    #[arg(long, global = true)]
    json: bool,
}

#[derive(Clone, Copy, PartialEq, Eq, clap::ValueEnum)]
enum CheckMode {
    /// Check concurrently with execution; report after the program ends,
    /// waiting up to OAM_CHECK_WAIT_MS for the checker.
    Warn,
    /// Check BEFORE execution; type errors prevent the run (CI gate).
    Block,
    /// No type checking (default), as node runs TypeScript.
    Off,
}

#[derive(Subcommand)]
enum Command {
    /// Run a JavaScript or TypeScript file. TypeScript runs with its types
    /// stripped and unchecked, as node runs it; --check=warn or
    /// --check=block (or `oam check`) adds the type check.
    Run {
        file: PathBuf,
        /// Type-check policy for TypeScript entries. Off by default: warn
        /// mode reports after the program ends, so a short run's exit
        /// waited for the checker -- seconds for a file with no tsconfig,
        /// whose check starts a fresh tsgo every time.
        #[arg(long, value_enum, default_value = "off")]
        check: CheckMode,
        /// Alias for --check=off.
        #[arg(long)]
        no_check: bool,
        /// Attach the V8 Inspector (Chrome DevTools Protocol). Optional
        /// value is `[host:]port` (default 127.0.0.1:9229), given with `=`.
        ///
        /// require_equals matches node (`node --inspect=9229`) and is load
        /// bearing: without it clap greedily takes the next argument as the
        /// value, so `oam run --inspect app.ts` consumed the FILE and failed
        /// with "the following required arguments were not provided: <FILE>".
        /// That is the first line of the published docs page.
        #[arg(long, num_args = 0..=1, require_equals = true, default_missing_value = "127.0.0.1:9229", value_name = "[host:]port")]
        inspect: Option<String>,
        /// Like --inspect, but wait for a debugger to attach and break on the
        /// first line. Optional value is `[host:]port`.
        #[arg(long, num_args = 0..=1, require_equals = true, default_missing_value = "127.0.0.1:9229", value_name = "[host:]port")]
        inspect_brk: Option<String>,
        /// Record all non-deterministic I/O to FILE (JSON Lines). Mutually
        /// exclusive with --replay.
        #[arg(long, value_name = "FILE", conflicts_with = "replay")]
        record: Option<PathBuf>,
        /// Replay non-deterministic I/O from a FILE previously captured with
        /// --record. Timers fire instantly; Math.random/Date.now return
        /// recorded values. Mutually exclusive with --record.
        #[arg(long, value_name = "FILE", conflicts_with = "record")]
        replay: Option<PathBuf>,
        /// Arguments passed to the script (process.argv) after `--`.
        #[arg(last = true)]
        script_args: Vec<String>,
    },
    /// Run tests (*.test.* / *.spec.* / *_test.* files; import 'oam:test').
    /// Each file runs in a fresh isolate. Type checking stays with `oam
    /// check` — the runner never blocks on types.
    Test {
        /// Files or directories to search (default: current directory).
        paths: Vec<PathBuf>,
        /// Run only tests whose full name matches (regex, else substring).
        #[arg(short = 't', long)]
        test_name_pattern: Option<String>,
    },
    /// Interactive typed REPL (also the default with no subcommand).
    Repl,
    /// Type-check a file or project with tsgo (TypeScript 7 native).
    Check {
        /// A .ts file or a directory; the nearest tsconfig.json upward wins.
        #[arg(default_value = ".")]
        path: PathBuf,
        /// Skip the type-check daemon; run a one-shot check.
        #[arg(long)]
        no_daemon: bool,
    },
    /// Inspect or stop the per-project type-check daemon.
    Daemon {
        #[command(subcommand)]
        action: DaemonAction,
    },
    /// Serve oam's introspection to coding agents over MCP (stdio transport).
    /// Register with e.g.: claude mcp add oam -- oam mcp
    Mcp,
    /// Start a server from a JS/TS entry file. Equivalent to `oam run`
    /// with `PORT` and `HOST` env vars set from `--port` / `--host`.
    Serve {
        file: PathBuf,
        /// Port to listen on (sets the PORT env var; default 3000).
        #[arg(short, long, default_value = "3000")]
        port: u16,
        /// Bind address (sets the HOST env var; default 0.0.0.0).
        #[arg(long, default_value = "0.0.0.0")]
        host: String,
        /// Number of worker isolates for request dispatch. 0 = single-process
        /// (handler file runs directly). >0 = pool mode (handler file must
        /// export a default `(req, res) => ...` function).
        #[arg(short, long, default_value = "0")]
        workers: u16,
        /// Attach the V8 Inspector (Chrome DevTools Protocol). Optional
        /// value is `[host:]port` (default 127.0.0.1:9229).
        #[arg(long, num_args = 0..=1, require_equals = true, default_missing_value = "127.0.0.1:9229", value_name = "[host:]port")]
        inspect: Option<String>,
        /// Like --inspect, but wait for a debugger to attach and break on the
        /// first line. Optional value is `[host:]port`.
        #[arg(long, num_args = 0..=1, require_equals = true, default_missing_value = "127.0.0.1:9229", value_name = "[host:]port")]
        inspect_brk: Option<String>,
    },
    /// Install packages from the lockfile (npm ci equivalent).
    Install {
        /// Refuse to modify the lockfile (default and only mode for MVP).
        #[arg(long, default_value = "true")]
        frozen_lockfile: bool,
        /// Pre-compile TypeScript files in installed packages to .js at install
        /// time. Cached under node_modules/.oam/precompile/ for faster first run.
        #[arg(long, default_value = "false")]
        precompile: bool,
    },
    /// Manage the trust list for lifecycle scripts.
    ///
    /// oam install skips all lifecycle scripts (preinstall, install, postinstall)
    /// by default. Trusting a package makes `oam install` RUN that package's
    /// scripts, through the platform shell, with your privileges -- it is not a
    /// way to quiet the OAM-PKG0007 warning. Trust a package only if you would
    /// run its install script by hand. OAM_IGNORE_SCRIPTS=1 skips every script
    /// regardless of the trust list.
    Trust {
        #[command(subcommand)]
        action: TrustAction,
    },
    /// Compile a pre-bundled JS file into a standalone executable.
    /// The user bundles externally (esbuild/rollup); this embeds the result.
    Compile {
        /// Pre-bundled JS/CJS entry file.
        entry: PathBuf,
        /// Output binary path.
        #[arg(short, long)]
        output: PathBuf,
        /// Carrier binary to embed into, instead of the running oam. Point it
        /// at an oam release binary for another OS/arch to cross-compile --
        /// the JS payload is platform-independent, only the carrier is not.
        /// Without this, compile always produces a binary for the platform it
        /// runs on, so shipping N targets needed N machines. V8 bytecode is
        /// bound to the compiling binary, so a foreign carrier gets a JS-only
        /// payload and builds its own bytecode cache lazily on first run.
        #[arg(long, value_name = "PATH")]
        carrier: Option<PathBuf>,
        /// Reserved for future use (minify the embedded source).
        #[arg(long)]
        minify: bool,
    },
    /// Inspect or delete the V8 bytecode cache (`oam cache --help`).
    Cache {
        #[command(subcommand)]
        action: CacheAction,
    },
    /// Update oam in place to the latest release. The release's signed
    /// RELEASE-MANIFEST is verified against the release keys compiled into
    /// this binary (tags before v0.18.0: a pinned SHA256SUMS digest), then the
    /// binary is checked against it and replaces the running one. Any failure
    /// leaves the installed oam as it was; no flag skips a check.
    /// OAM_INSTALL_DIR updates `<dir>/oam` instead; OAM_SELF_UPDATE_URL (or,
    /// when unset, OAM_INSTALL_BASE) fetches the release's files from another
    /// base (with --version), and they must still carry a valid signature.
    SelfUpdate {
        /// Install a specific tag (e.g. v0.18.0) instead of the latest. An
        /// older tag is allowed only when named here.
        #[arg(long, value_name = "TAG")]
        version: Option<String>,
        /// Verify the release and print what would be installed, without
        /// downloading the binary or changing anything.
        #[arg(long)]
        dry_run: bool,
    },
    /// Internal: type-check daemon server process. Not for direct use.
    #[command(name = "__oamd-ts", hide = true)]
    DaemonServe { tsconfig: PathBuf },
}

#[derive(Subcommand)]
enum CacheAction {
    /// Print the bytecode cache directory, its entry count and total size.
    Info,
    /// Delete the bytecode cache. Safe at any time: the next run recompiles
    /// and repopulates it.
    Clean,
}

#[derive(Subcommand)]
enum DaemonAction {
    /// Report whether the project's daemon is running (JSON).
    Status {
        #[arg(default_value = ".")]
        path: PathBuf,
    },
    /// Stop the project's daemon.
    Stop {
        #[arg(default_value = ".")]
        path: PathBuf,
    },
}

#[derive(Subcommand)]
enum TrustAction {
    /// Allow a package's lifecycle scripts to RUN during `oam install`.
    ///
    /// This executes arbitrary code from the package through the platform shell
    /// at install time. It is not a warning-suppression switch.
    Add {
        /// npm package name (e.g. "esbuild" or "@scope/pkg").
        package: String,
        /// Write to the global trust list (~/.config/oam/trust.json) instead of
        /// the project-local .oam/trust.json.
        #[arg(long)]
        global: bool,
    },
    /// Remove a package from the trust list.
    Remove {
        /// npm package name.
        package: String,
        /// Remove from the global list instead of the project-local list.
        #[arg(long)]
        global: bool,
    },
    /// Show trusted packages.
    List {
        /// Show only the global list.
        #[arg(long, conflicts_with = "local")]
        global: bool,
        /// Show only the project-local list (default).
        #[arg(long)]
        local: bool,
    },
}

fn main() -> ExitCode {
    // Crash reporter FIRST: a structured stderr banner + a crash file under the
    // oam cache dir on any Rust panic or V8 OOM (internal diagnostics, not
    // public telemetry). Installed before anything can panic.
    oam_engine::install_panic_hook();
    // OAM_PRIORITY / OAM_ECOQOS, before any thread exists: a nice value is
    // per-thread on Linux and inherited by the threads a thread creates, and
    // the V8 pool, the tokio runtime and every child process should all run
    // at the lowered priority.
    oam_engine::priority::apply_env();
    // Before anything opens a file: the descriptors we hold RIGHT NOW are, by
    // definition, the ones a parent handed us. Taken this early because on unix
    // a file oam opens for itself would otherwise be indistinguishable from an
    // inherited one -- see oam_core::snapshot_inherited_fds.
    oam_engine::snapshot_inherited_fds();
    // Nothing we were born holding may reach a child by inheritance, as
    // node's PlatformInit makes sure with uv_disable_stdio_inheritance: on
    // Windows the std handles and the CRT fds a parent passed, on unix
    // FD_CLOEXEC on fds 3 and up (never 0-2). Otherwise a detached child with
    // stdio 'ignore' holds a parent's stdout pipe open after we exit, and any
    // child holds an extra-fd pipe the parent gave us. Only the inheritance
    // flag changes: our own writes and adopted fds are unaffected, and a
    // child given one of these (stdio 'inherit', stdio [..., n]) gets a
    // fresh duplicate. Reads the snapshot just taken. Before
    // extract_embedded, so a compiled binary gets it too.
    oam_engine::disable_stdio_inheritance();
    // And the file mode creation mask a parent handed us, before a program
    // can set its own: what oam writes for itself keeps the modes this one
    // gives (oam_diagnostics::own_files).
    oam_engine::snapshot_inherited_umask();
    register_worker_host();
    // Internal self-test hook (undocumented, env-gated): exercises the crash
    // path deterministically in CI without needing a JS-reachable panic.
    if std::env::var("OAM_CRASH_SELFTEST").as_deref() == Ok("panic") {
        panic!("oam crash-reporter self-test");
    }
    if let Some((source, bytecode)) = extract_embedded() {
        return run_embedded(&source, bytecode, std::env::args().collect());
    }

    // Node-style top-level flags, intercepted before clap (they are not
    // subcommands): `oam [-flags] -e <code>` / `--eval`, `-p` / `--print`,
    // and `oam --pending-deprecation <script>` (bare-script, node argv
    // shape). Suite children spawn process.execPath with these shapes --
    // the compat surface that unblocks spawnPromisified-shaped tests.
    {
        let argv: Vec<String> = std::env::args().collect();
        let raw: Vec<String> = argv.clone();
        let mut i = 1;
        // NODE_OPTIONS, read into flags of its own and merged UNDER argv's
        // once argv is parsed (`NodeFlags::merged`): an explicit
        // command-line flag wins, and process.execArgv reflects argv alone,
        // as node's does. Node gates the variable behind an allowlist and so
        // does this: it is a strict allowlist of process-level toggles, it
        // never touches `raw`/`i` (so no environment token can reach clap and
        // brick a subcommand), and it deliberately excludes everything that
        // executes code or names a file -- `-e`/`--eval`/`-p`/`--input-type`/
        // `--env-file`. The permission flags are on it, as they are on node's:
        // a child process started under `--permission` gets them in
        // NODE_OPTIONS, as node's does. An unrecognized token is ignored
        // rather than fatal, because NODE_OPTIONS is usually set globally in
        // a shell profile and may legitimately carry flags oam has no
        // opinion on.
        let mut env_flags = NodeFlags::default();
        let from_env = apply_node_options_env(&mut env_flags);
        // What argv gives, alone, until the merge below.
        let mut flags = NodeFlags::default();
        // Node accepts eval flags in any order and in several spellings:
        // `-e code`, `--eval code`, `--eval=code`, `-p code`, `-pe code`
        // (bundled: print + eval), and `-p -e code`. print and eval compose;
        // a later source wins. Leading node-level flags may precede them.
        let mut print = false;
        let mut eval_source: Option<String> = None;
        let mut saw_eval_flag = false;
        let mut bad_flag: Option<&str> = None;
        let mut warned_abort_on_uncaught = false;
        while i < raw.len() {
            let arg = raw[i].as_str();
            if arg == "--pending-deprecation" {
                flags.pending_deprecation = true;
                i += 1;
            } else if let Some(v) = arg.strip_prefix("--input-type=") {
                flags.input_type = Some(v.to_string());
                i += 1;
            } else if arg == "--input-type" {
                match raw.get(i + 1) {
                    Some(v) => {
                        flags.input_type = Some(v.clone());
                        i += 2;
                    }
                    None => {
                        eprintln!("oam: --input-type requires an argument");
                        return ExitCode::from(9);
                    }
                }
            } else if let Some(v) = arg.strip_prefix("--env-file=") {
                flags.env_files.push((v.to_string(), true));
                i += 1;
            } else if let Some(v) = arg.strip_prefix("--env-file-if-exists=") {
                flags.env_files.push((v.to_string(), false));
                i += 1;
            } else if matches!(arg, "--env-file" | "--env-file-if-exists") {
                let required = arg == "--env-file";
                match raw.get(i + 1) {
                    Some(v) => {
                        flags.env_files.push((v.clone(), required));
                        i += 2;
                    }
                    None => {
                        eprintln!("oam: {arg} requires an argument");
                        return ExitCode::from(9);
                    }
                }
            } else if arg == "--" {
                // End of node options: everything after is the script and
                // its arguments. Consume it (it is a separator, never part
                // of execArgv) and stop option parsing.
                i += 1;
                break;
            } else if arg == "--permission" {
                flags.permission = true;
                i += 1;
            } else if let Some(list) = arg.strip_prefix("--allow-fs-read=") {
                // Each occurrence of a list flag adds to the earlier ones, as
                // node's do (#363): they were replaced, dropping a grant.
                flags.allow_fs_read.push(list.to_string());
                i += 1;
            } else if let Some(list) = arg.strip_prefix("--allow-fs-write=") {
                flags.allow_fs_write.push(list.to_string());
                i += 1;
            } else if let Some(list) = arg.strip_prefix("--allow-net=") {
                flags.allow_net.push(list.to_string());
                i += 1;
            } else if arg == "--allow-net" {
                // Bare form grants everything, stored as the same "*" the list
                // form uses so `grant()` below needs no extra case.
                if let Some(msg) = space_form_hint("--allow-net", raw.get(i + 1)) {
                    eprintln!("{msg}");
                    return ExitCode::from(9);
                }
                flags.allow_net.push("*".to_string());
                i += 1;
            } else if let Some(list) = arg.strip_prefix("--allow-env=") {
                flags.allow_env.push(list.to_string());
                i += 1;
            } else if arg == "--allow-env" {
                if let Some(msg) = space_form_hint("--allow-env", raw.get(i + 1)) {
                    eprintln!("{msg}");
                    return ExitCode::from(9);
                }
                flags.allow_env.push("*".to_string());
                i += 1;
            } else if arg == "--allow-child-process" {
                flags.allow_child_process = true;
                i += 1;
            } else if arg == "--allow-worker" {
                flags.allow_worker = true;
                i += 1;
            } else if arg == "--allow-addons" {
                // Built without the `napi` cargo feature: no `.node` addon can
                // ever load, so granting the permission would be a silent
                // no-op that reads as "addons are on". Fail loudly instead --
                // a wrong-build diagnosis at startup beats a confusing
                // OAM-NATIVE0002 throw from deep inside require().
                #[cfg(not(feature = "napi"))]
                {
                    eprintln!(
                        "oam: --allow-addons is not supported by this build: it was compiled \
                         without the `napi` cargo feature, so native .node addons cannot be \
                         loaded at all."
                    );
                    return ExitCode::from(9);
                }
                #[cfg(feature = "napi")]
                {
                    flags.allow_addons = true;
                    i += 1;
                }
            } else if arg == "--expose-gc" {
                flags.expose_gc = true;
                i += 1;
            } else if arg == "--expose-internals" {
                flags.expose_internals = true;
                i += 1;
            } else if arg == "--experimental-vm-modules" {
                flags.experimental_vm_modules = true;
                i += 1;
            } else if arg == "--allow-natives-syntax" {
                flags.allow_natives_syntax = true;
                i += 1;
            } else if arg == "--js-float16array" {
                flags.js_float16array = true;
                i += 1;
            } else if arg == "--zero-fill-buffers" {
                flags.zero_fill_buffers = true;
                i += 1;
            } else if arg == "--tls-min-v1.0" {
                flags.tls_min_v1_0 = true;
                i += 1;
            } else if arg == "--tls-min-v1.1" {
                flags.tls_min_v1_1 = true;
                i += 1;
            } else if arg == "--tls-min-v1.2" {
                flags.tls_min_v1_2 = true;
                i += 1;
            } else if arg == "--tls-min-v1.3" {
                flags.tls_min_v1_3 = true;
                i += 1;
            } else if arg == "--tls-max-v1.2" {
                flags.tls_max_v1_2 = true;
                i += 1;
            } else if arg == "--tls-max-v1.3" {
                flags.tls_max_v1_3 = true;
                i += 1;
            } else if let Some(v) = arg.strip_prefix("--max-http-header-size=") {
                if v.is_empty() {
                    eprintln!("oam: --max-http-header-size= requires an argument");
                    return ExitCode::from(9);
                }
                flags.max_http_header_size = Some(v.to_string());
                flags.max_http_header_size_spaced = false;
                i += 1;
            } else if arg == "--max-http-header-size" {
                match raw.get(i + 1) {
                    Some(v) => {
                        flags.max_http_header_size = Some(v.clone());
                        flags.max_http_header_size_spaced = true;
                        i += 2;
                    }
                    None => {
                        eprintln!("oam: --max-http-header-size requires an argument");
                        return ExitCode::from(9);
                    }
                }
            } else if let Some(v) = arg.strip_prefix("--v8-pool-size=") {
                if v.is_empty() {
                    eprintln!("oam: --v8-pool-size= requires an argument");
                    return ExitCode::from(9);
                }
                flags.v8_pool_size = Some(v.to_string());
                flags.v8_pool_size_spaced = false;
                i += 1;
            } else if arg == "--v8-pool-size" {
                match raw.get(i + 1) {
                    Some(v) => {
                        flags.v8_pool_size = Some(v.clone());
                        flags.v8_pool_size_spaced = true;
                        i += 2;
                    }
                    None => {
                        eprintln!("oam: --v8-pool-size requires an argument");
                        return ExitCode::from(9);
                    }
                }
            } else if arg == "--insecure-http-parser" {
                flags.insecure_http_parser = true;
                i += 1;
            } else if arg == "--trace-require-module" || arg.starts_with("--trace-require-module=")
            {
                // node's two values; anything else, or no value, is node's
                // exit 9 (the value is not optional, unlike most trace flags).
                let (value, spaced) = match arg.strip_prefix("--trace-require-module=") {
                    Some(v) => (Some(v.to_string()), false),
                    None => (raw.get(i + 1).cloned(), true),
                };
                let Some(value) = value else {
                    eprintln!("oam: --trace-require-module requires an argument");
                    return ExitCode::from(9);
                };
                if !is_trace_require_module_value(&value) {
                    eprintln!("oam: invalid value for --trace-require-module");
                    return ExitCode::from(9);
                }
                flags.trace_require_module = Some(value);
                flags.trace_require_module_spaced = spaced;
                i += if spaced { 2 } else { 1 };
            } else if let Some(v) = arg.strip_prefix("--title=") {
                flags.title = Some(v.to_string());
                i += 1;
            } else if arg == "--no-warnings" {
                flags.no_warnings = true;
                i += 1;
            } else if arg == "--no-deprecation" {
                flags.no_deprecation = true;
                i += 1;
            } else if arg == "--trace-warnings" {
                flags.trace_warnings = true;
                i += 1;
            } else if arg == "--trace-deprecation" {
                flags.trace_deprecation = true;
                i += 1;
            } else if arg == "--trace-uncaught" {
                flags.trace_uncaught = true;
                i += 1;
            } else if let Some(v) = arg.strip_prefix("--disable-warning=") {
                flags.disabled_warnings.push(v.to_string());
                i += 1;
            } else if arg == "--disable-warning" {
                match raw.get(i + 1) {
                    Some(v) => {
                        flags.disabled_warnings.push(v.clone());
                        i += 2;
                    }
                    None => {
                        eprintln!("oam: --disable-warning requires an argument");
                        return ExitCode::from(9);
                    }
                }
            } else if let Some(v) = arg.strip_prefix("--redirect-warnings=") {
                flags.redirect_warnings = Some(v.to_string());
                i += 1;
            } else if arg == "--redirect-warnings" {
                match raw.get(i + 1) {
                    Some(v) => {
                        flags.redirect_warnings = Some(v.clone());
                        i += 2;
                    }
                    None => {
                        eprintln!("oam: --redirect-warnings requires an argument");
                        return ExitCode::from(9);
                    }
                }
            } else if arg == "--abort-on-uncaught-exception" {
                // Recognized so a node-shaped launcher does not die at clap
                // with exit 2, NOT implemented -- and the difference is worth
                // one line of stderr.
                //
                // The whole value of this flag is that V8 aborts AT the throw
                // site, with the throwing frame still on the stack, so a
                // debugger breaks there or the OS writes a core dump. oam has
                // no primitive to build that on: process.abort() is
                // processExit(134) in js/node_compat.js -- not a raised
                // SIGABRT, and not Windows' 0x80000003 exception breakpoint --
                // and anything reachable from the uncaught-exception path
                // already runs after the stack unwound. Forwarding the token
                // to V8 is worse than doing nothing: oam catches on the Rust
                // side, so V8 sees CAUGHT_BY_EXTERNAL, which is inside its
                // abort condition -- it would abort on exceptions JS goes on
                // to catch -- and rusty_v8 150 binds no
                // SetAbortOnUncaughtExceptionCallback to narrow that.
                //
                // Hence: accepted, inert, and said out loud. Silent acceptance
                // would be its own small lie -- somebody passing this flag is
                // asking for a crash dump, and would otherwise get a clean
                // exit code, no dump, and nothing explaining the gap.
                // NODE_OPTIONS already tolerates the token (it falls through
                // the allowlist in `apply_node_options_env`); this is the
                // spelling a user types deliberately, so it gets the notice.
                if !warned_abort_on_uncaught {
                    warned_abort_on_uncaught = true;
                    eprintln!(
                        "oam: --abort-on-uncaught-exception is accepted for launcher \
                         compatibility but is not implemented: oam reports the uncaught \
                         exception and exits, it does not abort at the throw site, so no \
                         core dump or debugger break is produced."
                    );
                }
                i += 1;
            } else if let Some(v) = arg.strip_prefix("--eval=") {
                saw_eval_flag = true;
                eval_source = Some(v.to_string());
                i += 1;
            } else if let Some(v) = arg.strip_prefix("--print=") {
                saw_eval_flag = true;
                print = true;
                eval_source = Some(v.to_string());
                i += 1;
            } else if matches!(arg, "-e" | "--eval" | "-p" | "--print" | "-pe" | "-ep") {
                saw_eval_flag = true;
                if arg != "-e" && arg != "--eval" {
                    print = true;
                }
                // -p alone may still be followed by -e; a source consumes.
                if matches!(arg, "-e" | "--eval" | "-pe" | "-ep") || raw.len() > i + 1 {
                    match raw.get(i + 1) {
                        Some(next)
                            if !matches!(
                                next.as_str(),
                                "-e" | "--eval" | "-p" | "--print" | "-pe" | "-ep"
                            ) =>
                        {
                            eval_source = Some(next.clone());
                            i += 2;
                        }
                        Some(_) => i += 1, // another eval flag follows
                        None => {
                            bad_flag = Some(if print { "-p" } else { "-e" });
                            i += 1;
                        }
                    }
                } else {
                    i += 1;
                }
            } else {
                break;
            }
        }
        // Everything from here on runs with both sources: NODE_OPTIONS under
        // argv, argv kept aside for execArgv.
        let flags = env_flags.merged(flags);
        // V8 flags must be set before V8::initialize, i.e. before any
        // JsRuntime is constructed.
        // The loader decides whether `internal/...` resolves, and it reads
        // this rather than taking a plumbed argument: resolution happens in
        // several places (require, dynamic import, the ESM path) and a
        // process-wide toggle keeps them from disagreeing.
        // The HTTP parser flags are process-wide: every server that sets no
        // option of its own, `http.maxHeaderSize`, and the response-head
        // limit of the fetch transport read them.
        flags.apply_http_parser_flags();
        if flags.expose_internals {
            // SAFETY: single-threaded startup, before any runtime exists.
            unsafe { std::env::set_var("OAM_EXPOSE_INTERNALS", "1") };
        }
        // Same reason: the `vm` module is built inside the snapshot, long
        // before argv is parsed, so the gate has to be readable at call time.
        if flags.experimental_vm_modules {
            // SAFETY: single-threaded startup, before any runtime exists.
            unsafe { std::env::set_var("OAM_EXPERIMENTAL_VM_MODULES", "1") };
        }
        // The V8 platform's worker pool is sized when V8 initializes, so the
        // flag is recorded before anything below can initialize it.
        if let Some(v) = &flags.v8_pool_size {
            oam_engine::set_v8_pool_size(v);
        }
        // Collect every node flag that is really a V8 flag: they all have to
        // go in ONE call, because V8::initialize runs on the first one and
        // later calls are ignored.
        {
            let mut v8_flags: Vec<&str> = Vec::new();
            if flags.expose_gc {
                v8_flags.push("--expose-gc");
            }
            if flags.allow_natives_syntax {
                v8_flags.push("--allow-natives-syntax");
            }
            if flags.js_float16array {
                v8_flags.push("--js-float16array");
            }
            if !v8_flags.is_empty() {
                oam_engine::init_platform_with_flags(&v8_flags);
            }
        }
        // node (src/node_options.cc, EnvironmentOptions::CheckOptions): the
        // one pair of --tls-* flags it refuses, a floor of 1.3 over a ceiling
        // of 1.2 -- from argv or NODE_OPTIONS alike, whatever else was given
        // -- exit 9 before anything runs, node's line after argv[0] as it was
        // given (`node: ...` from a shell, the path when spawned by one;
        // src/node.cc prints args.at(0); measured on v22.22.2).
        if flags.tls_min_v1_3 && flags.tls_max_v1_2 {
            let exe = argv.first().map(String::as_str).unwrap_or("oam");
            eprintln!("{exe}: either --tls-min-v1.3 or --tls-max-v1.2 can be used, not both");
            return ExitCode::from(9);
        }
        if let Some(source) = eval_source {
            return run_eval(&source, print, &raw[i..], &flags);
        }
        if saw_eval_flag {
            // Node: `-e` with no code exits 9; bare `-p` reads stdin, which
            // oam does not implement -- report rather than silently hang.
            let f = bad_flag.unwrap_or("-e");
            eprintln!(
                "oam: {f} requires an argument (reading the program from stdin is not supported)"
            );
            return ExitCode::from(9);
        }
        let saw_node_flag = i > 1;
        if i < raw.len() {
            let flag = raw[i].as_str();
            // Bare-script node shape, only when a node flag preceded it AND
            // the argument is an existing file. Node's `node script.js` shape
            // is accepted too: every tool that re-invokes the runtime through
            // process.execPath uses it (test runners, build scripts, and the
            // vendored suite's `"${process.execPath}" "${__filename}" child`).
            // A real SUBCOMMAND always wins, so `oam test` still runs the
            // test runner even if a file named `test` sits in the cwd.
            if !flag.starts_with('-') && !SUBCOMMANDS.contains(&flag) && script_is_file(flag) {
                let file = PathBuf::from(flag);
                drain_loader_warnings_on_hard_exit(false);
                let outcome = run_file_with_flags(
                    &file,
                    &raw[i + 1..],
                    None,
                    oam_engine::ReplayMode::Off,
                    &flags,
                );
                report_loader_warnings(false);
                return match outcome {
                    Ok(code) => ExitCode::from(code),
                    Err((diagnostics, code)) => {
                        for d in &diagnostics {
                            render(d, false);
                        }
                        ExitCode::from(code)
                    }
                };
            }
        }
        // Node flags followed by an oam SUBCOMMAND (`oam --no-warnings run
        // x.js`) -- the shape child_process.fork emits as
        // [...execArgv, "run", file]. Hand clap the argv with the node
        // flags stripped, and stash them for the run to install; without
        // this, ANY fork({execArgv}) dies with a clap "unexpected argument".
        // Stash whenever anything set flags -- including NODE_OPTIONS alone,
        // where argv carries no flag at all and the run paths would
        // otherwise start with defaults.
        if saw_node_flag || from_env {
            NODE_FLAGS.set(flags.clone()).ok();
        }
        if saw_node_flag {
            let filtered: Vec<String> = std::iter::once(argv[0].clone())
                .chain(raw[i..].iter().cloned())
                .collect();
            let cli = Cli::parse_from(filtered);
            return dispatch(cli);
        }
    }

    dispatch(Cli::parse())
}

/// Node process-level flags parsed before the subcommand, stashed for the
/// run paths to install (set at most once, before dispatch).
static NODE_FLAGS: std::sync::OnceLock<NodeFlags> = std::sync::OnceLock::new();

/// The options this process runs with (argv's and NODE_OPTIONS's, with
/// NODE_PENDING_DEPRECATION folded in), set by the first `install`: what a
/// worker_threads Worker that is given neither `env` nor `execArgv` runs with.
static PARENT_OPTIONS: std::sync::OnceLock<NodeFlags> = std::sync::OnceLock::new();

/// A non-enumerable, read-only global the JS side reads a flag from.
fn define_flag_global(name: &str, value: String) -> String {
    format!(
        "Object.defineProperty(globalThis, '{name}', \
           {{ value: {value}, writable: false, enumerable: false, configurable: false }});"
    )
}

/// The flags prelude of a new worker_threads Worker (#370), decided as node's
/// Worker constructor decides its options (src/node_worker.cc): one given
/// neither `env` nor `execArgv` (`inherit`) shares its creator's options --
/// `creator`'s, the creating worker's as it resolved them, or this process's
/// when the main thread creates it; otherwise it starts from the defaults,
/// applies NODE_PENDING_DEPRECATION and NODE_OPTIONS from the environment it
/// starts with, then `exec_argv` (its own, or its creator's process.execArgv
/// when it was given none). A worker never takes its creator's
/// per-environment flags otherwise. NODE_NO_WARNINGS is read from the
/// worker's own environment either way, as node's JS reads it from the
/// worker's process.env. The process-wide flags (`--title`,
/// `--zero-fill-buffers`) are every thread's. Returns the prelude and the
/// options the worker resolved to, for the workers it creates in turn.
fn worker_flags_js(
    creator: Option<&oam_engine::WorkerFlagsOptions>,
    inherit: bool,
    exec_argv: &[String],
    env: &dyn Fn(&str) -> Option<String>,
) -> (String, oam_engine::WorkerFlagsOptions) {
    let process = PARENT_OPTIONS.get().cloned().unwrap_or_default();
    let options = if inherit {
        creator
            .and_then(|creator| creator.downcast_ref::<NodeFlags>())
            .unwrap_or(&process)
            .clone()
    } else {
        let mut options = NodeFlags {
            pending_deprecation: env("NODE_PENDING_DEPRECATION").as_deref() == Some("1"),
            ..NodeFlags::default()
        };
        if let Some(raw) = env("NODE_OPTIONS") {
            apply_node_options(&mut options, &raw);
        }
        apply_node_option_tokens(&mut options, exec_argv);
        options
    };
    let mut js = options.environment_js(env("NODE_NO_WARNINGS").as_deref() == Some("1"));
    js.push_str(&process.process_js());
    (js, std::sync::Arc::new(options))
}

fn dispatch(cli: Cli) -> ExitCode {
    let Some(command) = &cli.command else {
        return repl_command();
    };
    match command {
        Command::Repl => repl_command(),
        Command::Run {
            file,
            check,
            no_check,
            inspect,
            inspect_brk,
            record,
            replay,
            script_args,
        } => {
            let inspect = match resolve_inspect(inspect.as_deref(), inspect_brk.as_deref()) {
                Ok(value) => value,
                Err(message) => {
                    eprintln!("oam run: {message}");
                    return ExitCode::FAILURE;
                }
            };
            let replay_mode = if let Some(path) = record {
                oam_engine::ReplayMode::Record(path.clone())
            } else if let Some(path) = replay {
                oam_engine::ReplayMode::Replay(path.clone())
            } else {
                oam_engine::ReplayMode::Off
            };
            run_command(
                file,
                *check,
                *no_check,
                cli.json,
                script_args,
                inspect,
                replay_mode,
            )
        }
        Command::Test {
            paths,
            test_name_pattern,
        } => test_command(paths, test_name_pattern.as_deref(), cli.json),
        Command::Check { path, no_daemon } => check_path(path, cli.json, *no_daemon),
        Command::Daemon { action } => match action {
            DaemonAction::Status { path } => {
                let status = oam_ts::daemon::status(path);
                println!(
                    "{}",
                    serde_json::to_string(&status).expect("status serializes")
                );
                ExitCode::SUCCESS
            }
            DaemonAction::Stop { path } => {
                let stopped = oam_ts::daemon::stop(path);
                println!("{{\"stopped\":{stopped}}}");
                ExitCode::SUCCESS
            }
        },
        Command::Mcp => match oam_mcp::serve_stdio() {
            Ok(()) => ExitCode::SUCCESS,
            Err(e) => {
                eprintln!("oam mcp: stdio transport failed: {e}");
                ExitCode::FAILURE
            }
        },
        Command::Serve {
            file,
            port,
            host,
            workers,
            inspect,
            inspect_brk,
        } => {
            // SAFETY: single-threaded at this point (before JsRuntime::new), so
            // the process-wide env mutation races no other thread's getenv.
            unsafe {
                std::env::set_var("PORT", port.to_string());
                std::env::set_var("HOST", host);
            }
            let inspect = match resolve_inspect(inspect.as_deref(), inspect_brk.as_deref()) {
                Ok(value) => value,
                Err(message) => {
                    eprintln!("oam serve: {message}");
                    return ExitCode::FAILURE;
                }
            };
            if *workers > 0 {
                serve_with_workers(file, *workers, cli.json, inspect)
            } else {
                // No type check, as `oam run`'s default: a server's
                // shutdown should not wait on a checker either.
                run_command(
                    file,
                    CheckMode::Off,
                    false,
                    cli.json,
                    &[],
                    inspect,
                    oam_engine::ReplayMode::Off,
                )
            }
        }
        Command::Install {
            frozen_lockfile,
            precompile,
        } => install_command(*frozen_lockfile, *precompile, cli.json),
        Command::Trust { action } => trust_command(action),
        Command::Compile {
            entry,
            output,
            carrier,
            minify: _,
        } => compile_command(entry, output, carrier.as_deref()),
        Command::Cache { action } => cache_command(action, cli.json),
        Command::SelfUpdate { version, dry_run } => {
            self_update::command(version.as_deref(), *dry_run)
        }
        Command::DaemonServe { tsconfig } => match oam_ts::daemon::serve(tsconfig) {
            Ok(()) => ExitCode::SUCCESS,
            Err(e) => {
                eprintln!("oam type-check daemon failed: {e}");
                ExitCode::FAILURE
            }
        },
    }
}

/// Daemon first (instant repeat checks), one-shot on ANY daemon trouble:
/// the daemon may never make checking less reliable than no daemon.
// result_large_err: cold path, deliberate — same stance as oam_loader/oam_ts.
#[allow(clippy::result_large_err)]
fn run_check(path: &Path) -> Result<Vec<Diagnostic>, Diagnostic> {
    run_check_with(path, &oam_ts::TsgoHandle::new())
}

/// [`run_check`] whose one-shot tsgo (the fallback path) is registered on
/// `handle`, so a caller that stops waiting can kill it instead of leaving
/// a type-check running after `oam run` has exited. The daemon path needs
/// no handle: its tsgo belongs to the detached daemon, which finishes the
/// check and caches it for the next run.
#[allow(clippy::result_large_err)]
fn run_check_with(path: &Path, handle: &oam_ts::TsgoHandle) -> Result<Vec<Diagnostic>, Diagnostic> {
    match oam_ts::daemon::check_via_daemon(path) {
        Ok(diagnostics) => Ok(diagnostics),
        Err(reason) => {
            // The daemon's failure is swallowed by contract; OAM_DEBUG
            // surfaces it (a daemon that cannot start otherwise costs every
            // check its spawn wait with no observable reason).
            if std::env::var_os("OAM_DEBUG").is_some_and(|v| !v.is_empty() && v != "0") {
                eprintln!("oam check: daemon unavailable ({reason}); running one-shot");
            }
            oam_ts::check_cancellable(path, handle)
        }
    }
}

/// How long warn-mode `oam run` waits for the checker after the program
/// exits: `OAM_CHECK_WAIT_MS`, default 10s (CI on a loaded box can lengthen
/// it instead of skipping tests).
fn check_wait() -> std::time::Duration {
    std::env::var("OAM_CHECK_WAIT_MS")
        .ok()
        .and_then(|v| v.parse::<u64>().ok())
        .map(std::time::Duration::from_millis)
        .unwrap_or(std::time::Duration::from_secs(10))
}

fn error_count(diagnostics: &[Diagnostic]) -> usize {
    diagnostics
        .iter()
        .filter(|d| d.severity == Severity::Error)
        .count()
}

/// `oam run` with the typed loop: strip-and-run starts immediately; the
/// checker runs concurrently (warn), gates (block), or stays off.
/// Resolve the `--inspect` / `--inspect-brk` flags into an optional
/// (address, break-on-start) pair. `--inspect-brk` wins if both are given.
/// The value is `PORT` or `HOST:PORT`; a bare port binds 127.0.0.1.
fn resolve_inspect(
    inspect: Option<&str>,
    inspect_brk: Option<&str>,
) -> Result<Option<(std::net::SocketAddr, bool)>, String> {
    let (value, brk) = match (inspect_brk, inspect) {
        (Some(v), _) => (v, true),
        (None, Some(v)) => (v, false),
        (None, None) => return Ok(None),
    };
    let with_host = if value.parse::<u16>().is_ok() {
        format!("127.0.0.1:{value}")
    } else {
        value.to_string()
    };
    let addr = with_host
        .parse::<std::net::SocketAddr>()
        .map_err(|_| format!("invalid --inspect address '{with_host}' (expected [host:]port)"))?;
    Ok(Some((addr, brk)))
}

fn run_command(
    file: &Path,
    check: CheckMode,
    no_check: bool,
    json: bool,
    script_args: &[String],
    inspect: Option<(std::net::SocketAddr, bool)>,
    replay_mode: oam_engine::ReplayMode,
) -> ExitCode {
    drain_loader_warnings_on_hard_exit(json);
    let mode = if no_check { CheckMode::Off } else { check };
    // Only TypeScript entries are checkable; .js and .tsx flow through
    // their normal paths untouched.
    let checkable = oam_loader::classify(file) == SourceKind::TypeScript;

    if mode == CheckMode::Block && checkable {
        match run_check(file) {
            Err(failure) => {
                render(&failure, json);
                return ExitCode::FAILURE;
            }
            Ok(diagnostics) => {
                let errors = error_count(&diagnostics);
                for d in &diagnostics {
                    render(d, json);
                }
                if errors > 0 {
                    if !json {
                        eprintln!(
                            "oam run: {errors} type error(s) — not executing (--check=block)"
                        );
                    }
                    return ExitCode::FAILURE;
                }
            }
        }
    }

    // Warn mode: the check races execution on a thread; we collect it after
    // the program finishes. Execution NEVER waits for the checker to start.
    // The handle lets the deadline path below kill a one-shot tsgo the
    // checker thread still owns, so no orphan outlives this process.
    let pending = (mode == CheckMode::Warn && checkable).then(|| {
        let path = file.to_path_buf();
        let handle = oam_ts::TsgoHandle::new();
        let (tx, rx) = std::sync::mpsc::channel();
        let checker_handle = handle.clone();
        std::thread::spawn(move || {
            let _ = tx.send(run_check_with(&path, &checker_handle));
        });
        (rx, handle)
    });

    let outcome = run_file(file, script_args, inspect, replay_mode);
    report_loader_warnings(json);
    let exit = match outcome {
        Ok(code) => ExitCode::from(code),
        Err((diagnostics, code)) => {
            for d in &diagnostics {
                render(d, json);
            }
            // The fatal path's exit code honors 'exit'-handler mutations of
            // process.exitCode (Node parity); never 0 -- a fatal stays fatal
            // unless a handler explicitly reset it, which run_file reports.
            ExitCode::from(code)
        }
    };

    if let Some((rx, handle)) = pending {
        match rx.recv_timeout(check_wait()) {
            Ok(Ok(diagnostics)) => {
                let errors = error_count(&diagnostics);
                for d in &diagnostics {
                    render(d, json);
                }
                if errors > 0 && !json {
                    eprintln!(
                        "oam run: {errors} type error(s) (execution was not blocked; use --check=block to gate)"
                    );
                }
            }
            Ok(Err(failure)) => {
                // Checker unavailable (e.g. no tsgo): report once — never
                // fail a successful run over it. JSON mode emits the ODIF
                // (stable OAM-TS0000, the documented skip signal for tooling
                // and the e2e suite); human mode gets one quiet line. Fully
                // silent json output here masked a missing tsgo on the GCP
                // builder as "typecheck ran clean".
                if json {
                    render(&failure, json);
                } else {
                    eprintln!("oam run: type check skipped: {}", failure.message);
                }
            }
            Err(_) => {
                // Checker still running when the wait deadline hit. Same
                // contract as the unavailable case above: the json stream
                // must say the check did not happen -- a silently empty
                // stream reads as "typecheck ran clean" (this exact silence
                // flaked the e2e suite under full-parallel load).
                //
                // Three honest shapes. A one-shot tsgo the checker thread
                // still owns (no tsconfig, or the daemon fell back) is
                // killed here, so it is CANCELLED, not "still running", and
                // nothing warms for the next run. Only a project with a
                // tsconfig has a daemon that finishes the work and caches
                // it. (The e2e skip commit 8d7b515 attributed its flake to
                // "daemon warmth" for a tsconfig-less fixture, which takes
                // the one-shot path -- there was never a daemon to warm.)
                let killed = handle.cancel();
                let has_tsconfig = oam_ts::find_tsconfig(file).is_some();
                let message = if killed {
                    format!(
                        "type check cancelled: it did not finish within {}ms of the program exiting \
                         (no daemon served this run); re-run `oam check {}` for results \
                         (OAM_CHECK_WAIT_MS lengthens the wait)",
                        check_wait().as_millis(),
                        file.display()
                    )
                } else if has_tsconfig {
                    "type check did not finish before the program exited (daemon warming); \
                     results are instant on the next run"
                        .to_string()
                } else {
                    format!(
                        "type check did not finish before the program exited; single-file checks \
                         have no daemon, so re-run `oam check {}` for results \
                         (OAM_CHECK_WAIT_MS lengthens the wait)",
                        file.display()
                    )
                };
                if json {
                    render(
                        &Diagnostic::new(
                            "OAM-TS0005",
                            Severity::Warning,
                            Origin::Typecheck,
                            message,
                        ),
                        json,
                    );
                } else {
                    eprintln!("oam run: {message}");
                }
            }
        }
    }
    exit
}

fn check_path(path: &Path, json: bool, no_daemon: bool) -> ExitCode {
    let result = if no_daemon {
        oam_ts::check(path)
    } else {
        run_check(path)
    };
    report_loader_warnings(json);
    match result {
        Err(failure) => {
            render(&failure, json);
            ExitCode::FAILURE
        }
        Ok(diagnostics) => {
            for d in &diagnostics {
                render(d, json);
            }
            let errors = diagnostics
                .iter()
                .filter(|d| d.severity == Severity::Error)
                .count();
            if !json {
                // Human summary only; --json stays pure JSONL.
                if errors == 0 {
                    eprintln!(
                        "oam check: clean ({} non-error diagnostic(s))",
                        diagnostics.len()
                    );
                } else {
                    eprintln!("oam check: {errors} error(s)");
                }
            }
            if errors == 0 {
                ExitCode::SUCCESS
            } else {
                ExitCode::FAILURE
            }
        }
    }
}

/// Brace/paren/bracket balance ignoring string/template contents — the
/// REPL's multi-line continuation heuristic.
fn input_balanced(source: &str) -> bool {
    let mut depth: i64 = 0;
    let mut quote: Option<char> = None;
    let mut escaped = false;
    for ch in source.chars() {
        if let Some(q) = quote {
            if escaped {
                escaped = false;
            } else if ch == '\\' {
                escaped = true;
            } else if ch == q {
                quote = None;
            }
            continue;
        }
        match ch {
            '\'' | '"' | '`' => quote = Some(ch),
            '{' | '(' | '[' => depth += 1,
            '}' | ')' | ']' => depth -= 1,
            _ => {}
        }
    }
    depth <= 0 && quote.is_none()
}

/// The typed REPL: every line runs through the oxc TypeScript strip, so
/// annotations just work. A reader thread feeds lines over a channel
/// while the main thread ticks the event loop between inputs — timers
/// and async ops stay LIVE at the prompt.
fn repl_command() -> ExitCode {
    use std::io::{BufRead, Write};

    println!(
        "oam v{} — typed REPL (TypeScript welcome; .exit or Ctrl+C to quit)",
        env!("CARGO_PKG_VERSION")
    );
    drain_loader_warnings_on_hard_exit(false);
    // Same construction-time rule as `test_command`: `oam --permission` used to
    // drop into an all-granted REPL, so every line you pasted at the prompt ran
    // outside the sandbox you asked for.
    let flags = NODE_FLAGS.get().cloned().unwrap_or_default();
    let mut rt = oam_engine::JsRuntime::new_with_permissions(flags.permissions());
    // The REPL doesn't call execute_module/execute_cjs (which run
    // reset_run_slots and create a CoreRuntime). Init it here so
    // tick() and repl_eval() have a Tokio runtime to drive ops on.
    rt.ensure_core_runtime();
    // The process-level flags (--no-warnings and the rest), as a script run
    // gets them: the REPL used to start with none.
    flags.install(&mut rt);
    let exe = std::env::current_exe()
        .map(|p| p.to_string_lossy().into_owned())
        .unwrap_or_else(|_| "oam".to_string());
    rt.set_process_argv(vec![exe]);

    let (tx, rx) = std::sync::mpsc::channel::<Option<String>>();
    std::thread::spawn(move || {
        let stdin = std::io::stdin();
        for line in stdin.lock().lines() {
            match line {
                Ok(line) => {
                    if tx.send(Some(line)).is_err() {
                        return;
                    }
                }
                Err(_) => break,
            }
        }
        let _ = tx.send(None); // EOF
    });

    let prompt = |continuation: bool| {
        print!("{}", if continuation { "... " } else { "> " });
        let _ = std::io::stdout().flush();
    };

    let mut buffer = String::new();
    prompt(false);
    loop {
        match rx.recv_timeout(std::time::Duration::from_millis(40)) {
            Ok(None) => break,
            Ok(Some(line)) => {
                if buffer.is_empty() {
                    let trimmed = line.trim();
                    match trimmed {
                        ".exit" => break,
                        ".help" => {
                            println!(
                                ".exit  quit | .help  this | `_` holds the last value | top-level await works"
                            );
                            prompt(false);
                            continue;
                        }
                        "" => {
                            prompt(false);
                            continue;
                        }
                        _ => {}
                    }
                }
                buffer.push_str(&line);
                buffer.push('\n');
                if !input_balanced(&buffer) {
                    prompt(true);
                    continue;
                }
                let source = std::mem::take(&mut buffer);
                // Typed input: strip annotations first; oxc handles plain
                // JS identically, and its parse errors are the user's.
                let prepared =
                    match oam_loader::transpile_typescript_rich(Path::new("repl.ts"), &source) {
                        Ok(output) => output,
                        Err(e) => {
                            for d in &e.diagnostics {
                                eprintln!("{}", d.message);
                            }
                            prompt(false);
                            continue;
                        }
                    };
                match rt.repl_eval(
                    &prepared.code,
                    prepared.top_level_await,
                    &prepared.top_level_bindings,
                ) {
                    Ok(rendered) => println!("{rendered}"),
                    Err(message) => eprintln!("{message}"),
                }
                // Loader warnings queued by this line's resolution surface at
                // the prompt they belong to, not silently at REPL exit.
                report_loader_warnings(false);
                prompt(false);
            }
            Err(std::sync::mpsc::RecvTimeoutError::Timeout) => {
                // Idle: keep timers/ops alive at the prompt.
                let _ = rt.tick(std::time::Duration::from_millis(25));
            }
            Err(std::sync::mpsc::RecvTimeoutError::Disconnected) => break,
        }
    }
    report_loader_warnings(false);
    ExitCode::SUCCESS
}

/// Is this file named like a test? (*.test.* / *.spec.* / *_test.*)
fn is_test_file(path: &Path) -> bool {
    let Some(name) = path.file_name().and_then(|n| n.to_str()) else {
        return false;
    };
    let Some(ext) = path.extension().and_then(|e| e.to_str()) else {
        return false;
    };
    if !matches!(ext, "ts" | "mts" | "cts" | "js" | "mjs" | "cjs") {
        return false;
    }
    let stem = &name[..name.len() - ext.len() - 1];
    stem.ends_with(".test") || stem.ends_with(".spec") || stem.ends_with("_test")
}

/// Discover test files under `paths` (explicit files pass regardless of
/// naming; directories recurse, skipping dependency/build trees).
fn discover_test_files(paths: &[PathBuf]) -> Vec<PathBuf> {
    const SKIP_DIRS: [&str; 6] = ["node_modules", ".git", "target", "dist", "coverage", ".oam"];
    fn walk(dir: &Path, out: &mut Vec<PathBuf>) {
        let Ok(entries) = std::fs::read_dir(dir) else {
            return;
        };
        let mut entries: Vec<_> = entries.flatten().collect();
        entries.sort_by_key(|e| e.file_name());
        for entry in entries {
            let path = entry.path();
            if path.is_dir() {
                let name = entry.file_name();
                let name = name.to_string_lossy();
                if SKIP_DIRS.iter().any(|s| name == *s) || name.starts_with(".oam") {
                    continue;
                }
                walk(&path, out);
            } else if is_test_file(&path) {
                out.push(path);
            }
        }
    }
    let mut out = Vec::new();
    let roots: Vec<PathBuf> = if paths.is_empty() {
        vec![PathBuf::from(".")]
    } else {
        paths.to_vec()
    };
    for root in roots {
        if root.is_file() {
            out.push(root);
        } else {
            walk(&root, &mut out);
        }
    }
    out
}

/// `oam test`: every file in a FRESH isolate (registered state cannot leak
/// across files), results rendered pretty or as ODIF JSONL from the same
/// data. Exit 0 only when every discovered test passed.
fn test_command(paths: &[PathBuf], filter: Option<&str>, json: bool) -> ExitCode {
    drain_loader_warnings_on_hard_exit(json);
    let files = discover_test_files(paths);
    if files.is_empty() {
        eprintln!(
            "oam test: no test files found (looked for *.test.* / *.spec.* / *_test.* with js/mjs/cjs/ts/mts/cts extensions)"
        );
        return ExitCode::FAILURE;
    }

    let started = std::time::Instant::now();
    let (mut pass, mut fail, mut skip, mut todo) = (0u64, 0u64, 0u64, 0u64);
    let mut file_failures = 0u64;

    for file in &files {
        if !json {
            eprintln!("{}", file.display());
        }
        // Permissions are a CONSTRUCTION-time property -- `flags.install()`
        // below cannot retrofit them, because the ops read the Arc<Permissions>
        // out of an isolate slot populated by `new_inner`. This used to call the
        // all-granted constructor with the install() call after it, so
        // `oam --permission test suspect.test.js` ran the file completely
        // unsandboxed while looking sandboxed -- worse than not offering the
        // flag, because it invites you to run untrusted tests behind it.
        let flags = NODE_FLAGS.get().cloned().unwrap_or_default();
        let mut rt = oam_engine::JsRuntime::new_with_permissions(flags.permissions());
        let exe = std::env::current_exe()
            .map(|p| p.to_string_lossy().into_owned())
            .unwrap_or_else(|_| "oam".to_string());
        let script = std::path::absolute(file)
            .unwrap_or_else(|_| file.clone())
            .to_string_lossy()
            .into_owned();
        rt.set_process_argv(vec![exe, script]);
        // The test runner emits no 'beforeExit' at the module-eval drain --
        // Node --test emits only after the tests have run.
        rt.suppress_before_exit();
        // The rest of the node flags are install-time; each file gets a fresh
        // isolate, so install per runtime.
        flags.install(&mut rt);
        if flags.apply_env_files(&mut rt).is_err() {
            return ExitCode::from(9);
        }

        let evaluated = if rt.entry_module_kind(file) == oam_loader::ModuleKind::Cjs {
            rt.execute_cjs(file, &CliHost)
        } else {
            rt.execute_module(file, &CliHost)
        };
        if let Err(diagnostics) = evaluated {
            file_failures += 1;
            for d in &diagnostics {
                render(d, json);
            }
            continue;
        }

        let results = match rt.run_registered_tests(filter) {
            Ok(json_text) => json_text,
            Err(diagnostics) => {
                file_failures += 1;
                for d in &diagnostics {
                    render(d, json);
                }
                continue;
            }
        };
        let parsed: serde_json::Value = match serde_json::from_str(&results) {
            Ok(value) => value,
            Err(e) => {
                file_failures += 1;
                eprintln!("oam test: unreadable results from {}: {e}", file.display());
                continue;
            }
        };

        let tests = parsed["tests"].as_array().cloned().unwrap_or_default();
        if tests.is_empty() && parsed["noTestModule"].as_bool() == Some(true) && !json {
            eprintln!("  (no tests registered — does the file import 'oam:test'?)");
        }
        for t in &tests {
            let name = t["name"].as_str().unwrap_or("(unnamed)");
            let status = t["status"].as_str().unwrap_or("fail");
            let duration = t["durationMs"].as_u64().unwrap_or(0);
            match status {
                "pass" => {
                    pass += 1;
                    if !json {
                        eprintln!("  ok   {name} ({duration}ms)");
                    }
                }
                "skip" => {
                    skip += 1;
                    if !json {
                        eprintln!("  skip {name}");
                    }
                }
                "todo" => {
                    todo += 1;
                    if !json {
                        eprintln!("  todo {name}");
                    }
                }
                _ => {
                    fail += 1;
                    let message = t["error"]["message"].as_str().unwrap_or("failed");
                    if json {
                        let d = Diagnostic::new(
                            "OAM-TEST0001",
                            Severity::Error,
                            Origin::Test,
                            format!("FAIL {name}: {message}"),
                        )
                        .with_span(oam_diagnostics::Span {
                            file: file.to_string_lossy().into_owned(),
                            start: oam_diagnostics::Position { line: 1, col: 1 },
                            end: oam_diagnostics::Position { line: 1, col: 1 },
                        });
                        render(&d, true);
                    } else {
                        eprintln!("  FAIL {name} ({duration}ms)");
                        eprintln!("       {message}");
                        if let Some(stack) = t["error"]["stack"].as_str() {
                            for line in stack.lines().take(4) {
                                eprintln!("       {}", line.trim());
                            }
                        }
                    }
                }
            }
        }
    }

    // Warnings the loader queued while any file resolved or transpiled
    // (OAM-MOD0008/0009) surface before the summary, like run/check drain.
    report_loader_warnings(json);

    let elapsed = started.elapsed().as_millis();
    let failed_total = fail + file_failures;
    if json {
        // Machine summary as an ODIF info/error diagnostic, same stream.
        let d = Diagnostic::new(
            "OAM-TEST0000",
            if failed_total == 0 {
                Severity::Info
            } else {
                Severity::Error
            },
            Origin::Test,
            format!(
                "{} file(s): {pass} passed, {fail} failed, {skip} skipped, {todo} todo, {file_failures} file error(s) in {elapsed}ms",
                files.len()
            ),
        );
        render(&d, true);
    } else {
        eprintln!();
        eprintln!(
            "{} file(s): {pass} passed, {fail} failed, {skip} skipped, {todo} todo{} ({elapsed}ms)",
            files.len(),
            if file_failures > 0 {
                format!(", {file_failures} file error(s)")
            } else {
                String::new()
            }
        );
    }
    if failed_total == 0 {
        ExitCode::SUCCESS
    } else {
        ExitCode::FAILURE
    }
}

/// Render one diagnostic. JSON mode is the machine-facing source of truth;
/// the pretty form is a projection of the same Diagnostic, never a fork.
fn render(d: &Diagnostic, json: bool) {
    if json {
        eprintln!("{}", d.to_jsonl());
    } else if d.code == "OAM-RT0005" {
        // An uncaught user exception is reported in Node's format (source
        // frame + stack + own properties). Wrapping it in `error[CODE]:`
        // would bury the stack and break the `^Error:` line tools grep for.
        eprint!("{}", d.message);
    } else {
        let label = match d.severity {
            Severity::Error => "error",
            Severity::Warning => "warning",
            Severity::Info => "info",
        };
        let loc = d
            .spans
            .first()
            .map(|s| format!(" ({}:{}:{})", s.file, s.start.line, s.start.col))
            .unwrap_or_default();
        eprintln!("{label}[{}]: {}{}", d.code, d.message, loc);
    }
}

/// Drain the loader's deferred warnings (a tsconfig that does not parse, a
/// package `extends` it cannot resolve yet) through `render`, so they reach
/// stderr as ODIF like every other diagnostic -- never as prose that breaks
/// the --json JSONL contract. Called once per command, after the work that
/// could have queued them.
fn report_loader_warnings(json: bool) {
    for d in oam_loader::take_warnings() {
        render(&d, json);
    }
}

/// Ensure queued loader warnings survive a HARD exit. `process.exit()` tears
/// the process down from inside the op -- the normal end-of-command drain
/// never runs -- so every command that constructs a JsRuntime registers the
/// drain with the same exit-cleanup mechanism `run_eval` uses for its temp
/// file. The sink drain is take-based, so the normal epilogue and this hook
/// can never double-print.
fn drain_loader_warnings_on_hard_exit(json: bool) {
    oam_engine::register_exit_hook(move || report_loader_warnings(json));
}

/// `oam install`: frozen-lockfile package install from package-lock.json v3.
fn install_command(frozen_lockfile: bool, precompile: bool, json: bool) -> ExitCode {
    // Walk upward from cwd to find the directory containing package-lock.json.
    let cwd = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    let project_dir = find_project_dir(&cwd, "package-lock.json").unwrap_or(cwd);

    let result = oam_loader::install::install(&project_dir, frozen_lockfile, precompile);
    // Deferred loader warnings queued during the install (a package tsconfig
    // the --precompile pass consulted) drain before the summary, like
    // run/check drain theirs.
    report_loader_warnings(json);
    match result {
        Ok(outcome) => {
            let (installed, elapsed, errors) = match outcome {
                oam_loader::install::InstallOutcome::Complete(summary) => {
                    (summary.packages_installed, summary.elapsed, Vec::new())
                }
                oam_loader::install::InstallOutcome::Partial {
                    installed,
                    elapsed,
                    errors,
                } => (installed, elapsed, errors),
            };
            // Render any diagnostics FIRST so the user sees per-package
            // failures / bin-shim warnings before the success summary line --
            // otherwise the summary at the bottom is the last thing on
            // screen and a reader skimming the tail can miss errors that
            // scrolled off above the "installed N package(s)" line.
            for d in &errors {
                render(d, json);
            }
            if json {
                let d = Diagnostic::new(
                    "OAM-PKG0000",
                    Severity::Info,
                    Origin::Install,
                    format!(
                        "installed {} package(s) in {:.1}s",
                        installed,
                        elapsed.as_secs_f64()
                    ),
                );
                render(&d, true);
            } else {
                eprintln!(
                    "oam install: {} package(s) in {:.1}s",
                    installed,
                    elapsed.as_secs_f64()
                );
            }
            // Only Severity::Error diagnostics fail the install -- a
            // bin-shim PKG0005 (Severity::Warning) is informational and
            // matches npm behavior of warning + exit 0. install.rs emits
            // PKG0005 with Severity::Warning explicitly.
            let has_fatal = errors.iter().any(|d| d.severity == Severity::Error);
            if has_fatal {
                ExitCode::FAILURE
            } else {
                ExitCode::SUCCESS
            }
        }
        Err(diagnostics) => {
            for d in &diagnostics {
                render(d, json);
            }
            ExitCode::FAILURE
        }
    }
}

/// `oam trust`: manage the per-project and global lifecycle-script trust list.
fn trust_command(action: &TrustAction) -> ExitCode {
    use oam_loader::trust::TrustConfig;
    let cwd = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    let project_dir = find_project_dir(&cwd, "package.json")
        .or_else(|| find_project_dir(&cwd, "package-lock.json"))
        .unwrap_or(cwd);

    match action {
        TrustAction::Add { package, global } => {
            let mut config = if *global {
                TrustConfig::load_global()
            } else {
                TrustConfig::load_local(&project_dir)
            };
            if config.add(package) {
                let result = if *global {
                    config.save_global()
                } else {
                    config.save_local(&project_dir)
                };
                match result {
                    Ok(()) => {
                        if *global {
                            eprintln!("oam trust: added '{package}' to global trust list");
                        } else {
                            eprintln!("oam trust: added '{package}' to .oam/trust.json");
                        }
                    }
                    Err(e) => {
                        eprintln!("oam trust: failed to save: {e}");
                        return ExitCode::FAILURE;
                    }
                }
            } else {
                eprintln!("oam trust: '{package}' is already trusted");
            }
            ExitCode::SUCCESS
        }
        TrustAction::Remove { package, global } => {
            let mut config = if *global {
                TrustConfig::load_global()
            } else {
                TrustConfig::load_local(&project_dir)
            };
            if config.remove(package) {
                let result = if *global {
                    config.save_global()
                } else {
                    config.save_local(&project_dir)
                };
                match result {
                    Ok(()) => eprintln!("oam trust: removed '{package}'"),
                    Err(e) => {
                        eprintln!("oam trust: failed to save: {e}");
                        return ExitCode::FAILURE;
                    }
                }
            } else {
                eprintln!("oam trust: '{package}' was not in the trust list");
            }
            ExitCode::SUCCESS
        }
        TrustAction::List { global, local: _ } => {
            if *global {
                let config = TrustConfig::load_global();
                let path = TrustConfig::global_path()
                    .map(|p| p.display().to_string())
                    .unwrap_or_else(|| "~/.config/oam/trust.json".to_string());
                eprintln!("Global trust list ({path}):");
                for pkg in config.entries() {
                    println!("  {pkg}");
                }
                if config.entries().is_empty() {
                    eprintln!("  (empty)");
                }
            } else {
                // Default: show local (also used when --local is explicit).
                let config = TrustConfig::load_local(&project_dir);
                eprintln!(
                    "Project trust list ({}):",
                    project_dir.join(".oam").join("trust.json").display()
                );
                for pkg in config.entries() {
                    println!("  {pkg}");
                }
                if config.entries().is_empty() {
                    eprintln!("  (empty)");
                }
            }
            ExitCode::SUCCESS
        }
    }
}

/// Walk upward from `start` looking for a directory that contains `target`.
/// Split NODE_OPTIONS the way Node does: on whitespace, honoring single and
/// double quotes (no escape processing inside quotes).
fn split_node_options(raw: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut cur = String::new();
    let mut quote: Option<char> = None;
    let mut has = false;
    for ch in raw.chars() {
        match quote {
            Some(q) if ch == q => quote = None,
            Some(_) => cur.push(ch),
            None if ch == '\'' || ch == '"' => {
                quote = Some(ch);
                has = true;
            }
            None if ch.is_whitespace() => {
                if has || !cur.is_empty() {
                    out.push(std::mem::take(&mut cur));
                    has = false;
                }
            }
            None => cur.push(ch),
        }
    }
    if has || !cur.is_empty() {
        out.push(cur);
    }
    out
}

/// Fold the allowlisted NODE_OPTIONS tokens into `flags`. See the call site
/// for why the allowlist is strict.
fn apply_node_options_env(flags: &mut NodeFlags) -> bool {
    let Ok(raw) = std::env::var("NODE_OPTIONS") else {
        return false;
    };
    apply_node_options(flags, &raw)
}

/// [`apply_node_options_env`] on a given NODE_OPTIONS value.
fn apply_node_options(flags: &mut NodeFlags, raw: &str) -> bool {
    apply_node_option_tokens(flags, &split_node_options(raw))
}

/// Fold the allowlisted option tokens into `flags` -- NODE_OPTIONS's, once
/// split, or a worker's `execArgv`. Anything else is ignored.
fn apply_node_option_tokens(flags: &mut NodeFlags, tokens: &[String]) -> bool {
    let before = flags.clone();
    let mut it = tokens.iter().peekable();
    while let Some(tok) = it.next() {
        let tok = tok.as_str();
        if tok == "--pending-deprecation" {
            flags.pending_deprecation = true;
        } else if let Some(v) = tok.strip_prefix("--max-http-header-size=") {
            // node exits 9 on an empty value; this allowlist ignores a bad
            // token instead (see the call site), and an empty value must not
            // read as 0, which would refuse every request.
            if !v.is_empty() {
                flags.max_http_header_size = Some(v.to_string());
            }
        } else if tok == "--max-http-header-size"
            && let Some(v) = it.next()
        {
            flags.max_http_header_size = Some(v.clone());
        } else if let Some(v) = tok.strip_prefix("--v8-pool-size=") {
            // Empty is node's exit 9; here a bad token is ignored instead.
            if !v.is_empty() {
                flags.v8_pool_size = Some(v.to_string());
            }
        } else if tok == "--v8-pool-size"
            && let Some(v) = it.next()
        {
            flags.v8_pool_size = Some(v.clone());
        } else if tok == "--insecure-http-parser" {
            flags.insecure_http_parser = true;
        } else if let Some(v) = tok.strip_prefix("--trace-require-module=") {
            // A value node refuses (exit 9) is ignored here instead.
            if is_trace_require_module_value(v) {
                flags.trace_require_module = Some(v.to_string());
            }
        } else if tok == "--trace-require-module"
            && let Some(v) = it.next()
        {
            if is_trace_require_module_value(v) {
                flags.trace_require_module = Some(v.clone());
            }
        } else if tok == "--no-warnings" {
            flags.no_warnings = true;
        } else if tok == "--no-deprecation" {
            flags.no_deprecation = true;
        } else if tok == "--trace-warnings" {
            flags.trace_warnings = true;
        } else if tok == "--trace-deprecation" {
            flags.trace_deprecation = true;
        } else if tok == "--trace-uncaught" {
            flags.trace_uncaught = true;
        } else if tok == "--expose-gc" {
            flags.expose_gc = true;
        } else if tok == "--tls-min-v1.0" {
            flags.tls_min_v1_0 = true;
        } else if tok == "--tls-min-v1.1" {
            flags.tls_min_v1_1 = true;
        } else if tok == "--tls-min-v1.2" {
            flags.tls_min_v1_2 = true;
        } else if tok == "--tls-min-v1.3" {
            flags.tls_min_v1_3 = true;
        } else if tok == "--tls-max-v1.2" {
            flags.tls_max_v1_2 = true;
        } else if tok == "--tls-max-v1.3" {
            flags.tls_max_v1_3 = true;
        } else if let Some(v) = tok.strip_prefix("--disable-warning=") {
            flags.disabled_warnings.push(v.to_string());
        } else if tok == "--disable-warning"
            && let Some(v) = it.next()
        {
            flags.disabled_warnings.push(v.clone());
        } else if tok == "--permission" {
            // The permission model's flags, which node accepts here and
            // copies here for a child process (child_process.js,
            // copyPermissionModelFlagsToEnv), so a child started under
            // `--permission` runs under it too. Spelled as process.execArgv
            // spells them; a repeated list flag adds to the earlier values, as
            // on the command line.
            flags.permission = true;
        } else if let Some(list) = tok.strip_prefix("--allow-fs-read=") {
            flags.allow_fs_read.push(list.to_string());
        } else if let Some(list) = tok.strip_prefix("--allow-fs-write=") {
            flags.allow_fs_write.push(list.to_string());
        } else if let Some(list) = tok.strip_prefix("--allow-net=") {
            flags.allow_net.push(list.to_string());
        } else if tok == "--allow-net" {
            flags.allow_net.push("*".to_string());
        } else if let Some(list) = tok.strip_prefix("--allow-env=") {
            flags.allow_env.push(list.to_string());
        } else if tok == "--allow-env" {
            flags.allow_env.push("*".to_string());
        } else if tok == "--allow-child-process" {
            flags.allow_child_process = true;
        } else if tok == "--allow-worker" {
            flags.allow_worker = true;
        } else if tok == "--allow-addons" {
            // A build without the `napi` feature loads no addon at all, so
            // there is nothing to grant (argv refuses the flag outright).
            flags.allow_addons = cfg!(feature = "napi");
        } else if let Some(v) = tok.strip_prefix("--redirect-warnings=") {
            flags.redirect_warnings = Some(v.to_string());
        } else if tok == "--redirect-warnings"
            && let Some(v) = it.next()
        {
            flags.redirect_warnings = Some(v.clone());
        }
        // Anything else: ignored on purpose (see the call site).
    }
    before != *flags
}

/// The values node's `--trace-require-module` takes.
fn is_trace_require_module_value(value: &str) -> bool {
    matches!(value, "all" | "no-node-modules")
}

fn find_project_dir(start: &Path, target: &str) -> Option<PathBuf> {
    let mut dir = Some(start.to_path_buf());
    while let Some(current) = dir {
        if current.join(target).is_file() {
            return Some(current);
        }
        dir = current.parent().map(Path::to_path_buf);
    }
    None
}

/// The CLI's module host: filesystem loading + oxc transpilation, with the
/// resolution rules from oam_loader. Everything `oam run` executes goes
/// through this — entry file included — as an ES module (ESM-first per plan).
struct CliHost;

/// Workers are spawned inside the engine, which cannot name this type -- so
/// hand it a constructor (see oam_engine::set_worker_host_factory).
fn register_worker_host() {
    oam_engine::set_worker_host_factory(|| Box::new(CliHost));
    oam_engine::set_worker_flags_builder(worker_flags_js);
}

impl oam_engine::ModuleHost for CliHost {
    fn resolve(&self, specifier: &str, referrer: &Path) -> Result<PathBuf, Vec<Diagnostic>> {
        oam_loader::resolve_import(specifier, referrer).map_err(|d| vec![d])
    }

    fn load(&self, path: &Path) -> Result<String, Vec<Diagnostic>> {
        let kind = oam_loader::classify(path);

        // Anything we'd silently mis-execute gets a clear diagnostic instead:
        // .json would parse as JS and die on 'Unexpected token'. CJS files
        // never reach this host — the engine routes them through interop
        // before load — so a .cjs/.cts here is an engine routing bug.
        // The accepted set is DERIVED from the loader's own classifier —
        // `is_transpiled_source` (.ts/.mts/.cts/.tsx/.jsx, minus the
        // CJS-routed .cts caught first) plus the plain-JS ESM extensions —
        // so this host cannot drift from what the loader transpiles.
        let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("");
        match ext {
            "cjs" | "cts" => {
                return Err(vec![Diagnostic::new(
                    "OAM-MOD0003",
                    Severity::Error,
                    Origin::Resolve,
                    format!(
                        "internal: CommonJS file reached the ESM loader (oam bug — please report): {}",
                        path.display()
                    ),
                )]);
            }
            "json" => {
                // Unreachable for imports (the engine routes .json through
                // the JSON-module branch before host.load); only a .json
                // ENTRY file lands here, which is not a program.
                return Err(vec![Diagnostic::new(
                    "OAM-MOD0003",
                    Severity::Error,
                    Origin::Resolve,
                    format!(
                        "a .json file is not a program — import it from a script instead: {}",
                        path.display()
                    ),
                )]);
            }
            _ if matches!(ext, "js" | "mjs") || oam_loader::is_transpiled_source(path) => {}
            other => {
                return Err(vec![Diagnostic::new(
                    "OAM-MOD0003",
                    Severity::Error,
                    Origin::Resolve,
                    format!(
                        "unsupported module type '.{other}' (expected .js/.mjs/.ts/.mts/.tsx/.jsx): {}",
                        path.display()
                    ),
                )]);
            }
        }

        // Read the namespaced path node reads (`oam_loader::fs_os_path`), so
        // an entry named `app.mjs.` fails rather than reading `app.mjs`.
        let source = std::fs::read_to_string(oam_loader::fs_os_path(path)).map_err(|e| {
            vec![Diagnostic::new(
                "OAM-RT0002",
                Severity::Error,
                Origin::Runtime,
                format!("could not read {}: {e}", path.display()),
            )]
        })?;

        match kind {
            // .tsx/.jsx take the same oxc pipeline as .ts -- the JSX
            // transform emits the automatic runtime
            // (`import { jsx as _jsx } from "react/jsx-runtime"`), which
            // resolves through normal npm resolution + CJS interop.
            SourceKind::TypeScript | SourceKind::Jsx => {
                // Cache order: install-time precompile cache (node_modules
                // only, `oam install --precompile`, keyed by source hash) ->
                // content-addressed transpile cache (ALL transpiled sources,
                // project files included) -> oxc, storing the fresh output
                // so the next run skips the pipeline entirely.
                let (js, source_map) = if let Some(hit) =
                    oam_loader::precompile::try_precompile_cache(path, &source)
                {
                    hit
                } else if let Some(hit) = oam_loader::transpile_cache::try_get(path, &source) {
                    hit
                } else {
                    let out = oam_loader::transpile_typescript_mapped(path, &source)
                        .map_err(|e| e.diagnostics)?;
                    oam_loader::transpile_cache::store(
                        path,
                        &source,
                        &out.code,
                        out.source_map.as_deref(),
                    );
                    (out.code, out.source_map)
                };
                // Register the map (cache hits included -- warm runs must
                // keep stack-trace fidelity) under the SAME string the
                // engine hands V8 as this module's ScriptOrigin
                // (path.to_string_lossy in load_module_graph), so runtime
                // position remap finds it.
                if let Some(map) = source_map {
                    oam_loader::sourcemap::record(&path.to_string_lossy(), map);
                }
                Ok(js)
            }
            _ => Ok(source),
        }
    }
}

/// Worker-pool mode: write a dispatcher + worker shim to temp, run the
/// dispatcher. The dispatcher creates the http server in the main isolate,
/// spawns N worker isolates, and round-robins requests via postMessage.
/// Bodies cross the channel as base64 (M3; approach C fd-transfer is the
/// perf endgame).
fn serve_with_workers(
    handler: &Path,
    workers: u16,
    json: bool,
    inspect: Option<(std::net::SocketAddr, bool)>,
) -> ExitCode {
    let handler_abs = std::path::absolute(handler)
        .unwrap_or_else(|_| handler.to_path_buf())
        .to_string_lossy()
        .into_owned()
        .replace('\\', "/");

    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_nanos();
    let dir = std::env::temp_dir().join(format!("oam-serve-{}-{nanos}", std::process::id()));
    own_files::create_dir_all(&dir, Audience::Scratch).expect("temp dir");

    let worker_path = dir.join("_pool_worker.cjs");
    own_files::write(&worker_path, POOL_WORKER_CJS, Audience::Scratch).expect("write worker shim");

    let worker_path_str = worker_path
        .to_string_lossy()
        .into_owned()
        .replace('\\', "/");

    let dispatcher_src = POOL_DISPATCHER_CJS
        .replace("__OAM_WORKERS__", &workers.to_string())
        .replace("__OAM_HANDLER__", &handler_abs)
        .replace("__OAM_WORKER_SCRIPT__", &worker_path_str);

    let dispatcher_path = dir.join("_pool_dispatcher.cjs");
    own_files::write(&dispatcher_path, &dispatcher_src, Audience::Scratch)
        .expect("write dispatcher");

    let result = run_file(&dispatcher_path, &[], inspect, oam_engine::ReplayMode::Off);
    let _ = std::fs::remove_dir_all(&dir);
    match result {
        Ok(code) => ExitCode::from(code),
        Err((diagnostics, code)) => {
            for d in &diagnostics {
                render(d, json);
            }
            ExitCode::from(code)
        }
    }
}

const POOL_DISPATCHER_CJS: &str = r#"
const http = require("http");
const { Worker } = require("worker_threads");

const WORKER_COUNT = __OAM_WORKERS__;
const HANDLER = "__OAM_HANDLER__";
const WORKER_SCRIPT = "__OAM_WORKER_SCRIPT__";

const workers = [];
for (let i = 0; i < WORKER_COUNT; i++) {
  const w = new Worker(WORKER_SCRIPT, {
    workerData: { handler: HANDLER, workerId: i },
  });
  w.on("error", (err) => {
    console.error("worker " + i + " error:", err.message);
  });
  workers.push(w);
}

const pending = new Map();
let nextId = 1;
let nextWorker = 0;

for (const w of workers) {
  w.on("message", (msg) => {
    const res = pending.get(msg.id);
    if (!res) return;
    pending.delete(msg.id);
    res.writeHead(msg.status, msg.headers || {});
    res.end(msg.body ? Buffer.from(msg.body, "base64") : undefined);
  });
}

const server = http.createServer((req, res) => {
  const id = nextId++;
  pending.set(id, res);
  const chunks = [];
  req.on("data", (chunk) => chunks.push(chunk));
  req.on("end", () => {
    const body = Buffer.concat(chunks);
    const worker = workers[nextWorker % WORKER_COUNT];
    nextWorker++;
    worker.postMessage({
      id: id,
      method: req.method,
      url: req.url,
      headers: req.headers,
      body: body.length > 0 ? body.toString("base64") : null,
    });
  });
});

const port = parseInt(process.env.PORT) || 3000;
const host = process.env.HOST || "0.0.0.0";
server.listen(port, host, () => {
  const addr = server.address();
  console.log(
    "oam serve: " + addr.address + ":" + addr.port + " (" + WORKER_COUNT + " workers)"
  );
});
"#;

const POOL_WORKER_CJS: &str = r#"
const { parentPort, workerData } = require("worker_threads");
const { Readable } = require("stream");

const mod = require(workerData.handler);
const handler = typeof mod === "function" ? mod : mod.default;
if (typeof handler !== "function") {
  throw new Error(
    "oam serve --workers: handler file must export a (req, res) => ... function, " +
    "got " + typeof handler
  );
}

parentPort.on("message", (msg) => {
  const req = new Readable({ read() {} });
  req.method = msg.method;
  req.url = msg.url;
  req.headers = msg.headers;
  req.httpVersion = "1.1";
  req.socket = { remoteAddress: "127.0.0.1", encrypted: false };
  if (msg.body) req.push(Buffer.from(msg.body, "base64"));
  req.push(null);

  let statusCode = 200;
  const resHeaders = {};
  const bodyChunks = [];
  let ended = false;

  const res = {
    statusCode: 200,
    headersSent: false,
    setHeader(name, value) {
      resHeaders[String(name).toLowerCase()] = String(value);
    },
    getHeader(name) {
      return resHeaders[String(name).toLowerCase()];
    },
    removeHeader(name) {
      delete resHeaders[String(name).toLowerCase()];
    },
    writeHead(status, headers) {
      statusCode = status;
      res.statusCode = status;
      res.headersSent = true;
      if (headers) {
        if (typeof headers === "object") {
          for (const k of Object.keys(headers)) {
            resHeaders[k.toLowerCase()] = String(headers[k]);
          }
        }
      }
      return res;
    },
    write(chunk, encoding) {
      if (typeof chunk === "string") chunk = Buffer.from(chunk, encoding);
      else if (!(chunk instanceof Uint8Array)) chunk = Buffer.from(String(chunk));
      bodyChunks.push(chunk);
      return true;
    },
    end(chunk, encoding) {
      if (ended) return res;
      ended = true;
      if (chunk !== undefined && chunk !== null) {
        if (typeof chunk === "string") chunk = Buffer.from(chunk, encoding);
        else if (!(chunk instanceof Uint8Array)) chunk = Buffer.from(String(chunk));
        bodyChunks.push(chunk);
      }
      const body = Buffer.concat(bodyChunks);
      parentPort.postMessage({
        id: msg.id,
        status: statusCode,
        headers: resHeaders,
        body: body.length > 0 ? body.toString("base64") : null,
      });
      return res;
    },
  };

  try {
    const result = handler(req, res);
    if (result && typeof result.catch === "function") {
      result.catch((err) => {
        if (!ended) {
          ended = true;
          parentPort.postMessage({
            id: msg.id,
            status: 500,
            headers: { "content-type": "text/plain" },
            body: Buffer.from(err.message || "Internal Server Error").toString("base64"),
          });
        }
      });
    }
  } catch (err) {
    if (!ended) {
      ended = true;
      parentPort.postMessage({
        id: msg.id,
        status: 500,
        headers: { "content-type": "text/plain" },
        body: Buffer.from(err.message || "Internal Server Error").toString("base64"),
      });
    }
  }
});
"#;

/// Run the entry; Ok carries the process exit code (0, or a natural-exit
/// process.exitCode the script declared — Node honors it, so does oam).
fn run_file(
    file: &Path,
    script_args: &[String],
    inspect: Option<(std::net::SocketAddr, bool)>,
    replay_mode: oam_engine::ReplayMode,
) -> Result<u8, (Vec<Diagnostic>, u8)> {
    // Flags parsed before the subcommand (fork's [...execArgv, "run", file]
    // shape) were stashed by main; a direct `oam run` has none.
    let flags = NODE_FLAGS.get().cloned().unwrap_or_default();
    run_file_with_flags(file, script_args, inspect, replay_mode, &flags)
}

/// Whether `arg` names an existing script file as node's main-entry lookup
/// sees it: on Windows through the namespaced path, so `app.js.` is not
/// `app.js` and `NUL` is not the device.
fn script_is_file(arg: &str) -> bool {
    oam_engine::module_key(Path::new(arg)).is_ok_and(|key| oam_loader::fs_os_path(&key).is_file())
}

fn run_file_with_flags(
    file: &Path,
    script_args: &[String],
    inspect: Option<(std::net::SocketAddr, bool)>,
    replay_mode: oam_engine::ReplayMode,
    flags: &NodeFlags,
) -> Result<u8, (Vec<Diagnostic>, u8)> {
    if let Some("json") = file.extension().and_then(|e| e.to_str()) {
        return Err(err_exit(vec![Diagnostic::new(
            "OAM-MOD0003",
            Severity::Error,
            Origin::Resolve,
            format!(
                "a .json file is not a program — import it from a script instead: {}",
                file.display()
            ),
        )]));
    }
    let mut rt = oam_engine::JsRuntime::new_with_permissions(flags.permissions());
    // process.argv: [exe, absolute script path, ...script args] — Node's
    // shape. Script args arrive after `--` (cargo-run convention).
    let exe = std::env::current_exe()
        .map(|p| p.to_string_lossy().into_owned())
        .unwrap_or_else(|_| "oam".to_string());
    let script = std::path::absolute(file)
        .unwrap_or_else(|_| file.to_path_buf())
        .to_string_lossy()
        .into_owned();
    let mut argv = vec![exe, script];
    argv.extend(script_args.iter().cloned());
    rt.set_process_argv(argv);

    if !matches!(replay_mode, oam_engine::ReplayMode::Off) {
        rt.set_replay_mode(replay_mode);
        rt.apply_replay_patches();
    }

    if let Some((addr, brk)) = inspect {
        match rt.attach_inspector(addr, brk) {
            Ok(url) => {
                // Node prints these two lines to stderr; tooling scrapes the
                // first for the WebSocket URL.
                eprintln!("Debugger listening on {url}");
                eprintln!("For help, see: https://oamjs.org/docs/inspector");
            }
            Err(e) => {
                return Err(err_exit(vec![Diagnostic::new(
                    "OAM-RT0004",
                    Severity::Error,
                    Origin::Runtime,
                    format!("could not start inspector on {addr}: {e}"),
                )]));
            }
        }
    }

    flags.install(&mut rt);
    if let Err(code) = flags.apply_env_files(&mut rt) {
        return Err((Vec::new(), code));
    }
    let exec_argv = flags.exec_argv();
    if !exec_argv.is_empty() {
        let json = serde_json::to_string(&exec_argv).unwrap_or_else(|_| "[]".into());
        let _ = rt.execute_script("<flags>", &format!("globalThis.process.execArgv = {json};"));
    }

    // Entry routing follows module kind: .cjs, a "type": "commonjs" .js, or
    // a typeless .js without module syntax runs as a CJS program through
    // interop; everything else is the ESM graph, as in node.
    let result = if rt.entry_module_kind(file) == oam_loader::ModuleKind::Cjs {
        rt.execute_cjs(file, &CliHost)
    } else {
        rt.execute_module(file, &CliHost)
    };
    match result {
        Ok(()) => {
            rt.emit_process_exit();
            // Node's EmitExit RE-READS process.exitCode after the 'exit'
            // handlers ran: a handler mutation decides the final code.
            Ok(rt.process_exit_code().unwrap_or(0).clamp(0, 255) as u8)
        }
        Err(diagnostics) => {
            // Fatal sub-codes (6 = _fatalException monkeypatched away,
            // 7 = throwing uncaughtException handler): Node exits WITHOUT
            // emitting 'exit', and the code is not handler-overridable.
            let sub_code = rt
                .execute_script_draining(
                    "<fatal-sub-code>",
                    "String((globalThis.process && globalThis.process.__oamFatalCode) || '')",
                    oam_engine::AfterScript::Nothing,
                )
                .ok()
                .and_then(|s| s.parse::<u8>().ok());
            if let Some(code) = sub_code {
                // This return skips `emit_process_exit`, so the JS 'exit'
                // listeners never run -- including the one that puts the
                // terminal back into cooked mode. Drain the hooks by hand.
                // Hooks only: the caller still renders `diagnostics`, and the
                // artifact sweep can wait for the normal exit path.
                oam_engine::run_exit_hooks();
                return Err((diagnostics, code));
            }
            // Regular fatal: Node forces process.exitCode = 1 at
            // TriggerUncaughtException (an earlier script assignment loses,
            // unless process.exit() was already exiting -- fatal_exit_shape),
            // emits 'exit', then re-reads: a handler mutating exitCode (98,
            // or back to 0) decides the final code.
            let (exit_code_script, after_exit) = fatal_exit_shape(&diagnostics);
            let _ = rt.execute_script_draining(
                "<fatal-exit-code>",
                exit_code_script,
                oam_engine::AfterScript::Nothing,
            );
            rt.emit_process_exit_after(after_exit);
            let final_code = rt.process_exit_code().unwrap_or(1).clamp(0, 255) as u8;
            Err((diagnostics, final_code))
        }
    }
}

/// How a run that failed exits: the script that sets `process.exitCode`
/// before the 'exit' emit, and what runs after the emit.
///
/// A fatal exception: node forces exitCode 1 (TriggerUncaughtException,
/// unconditionally -- an earlier assignment loses), emits 'exit', and runs
/// nothing after it, no promise job, no tick. Unless the process is already
/// exiting -- the throw came out of `process.exit()`'s own 'exit' emit --
/// when `_fatalException` leaves exitCode alone: `process.exit(3)` with a
/// throwing listener exits 3 (#399 item 7). A top-level await that never
/// settled is no exception to node: it exits naturally, with the exitCode
/// the script set or else 13 (kUnsettledTopLevelAwait), and drains the
/// promise jobs the 'exit' listeners queue. Either way a listener that
/// changes exitCode decides the final code.
fn fatal_exit_shape(
    diagnostics: &[oam_diagnostics::Diagnostic],
) -> (&'static str, oam_engine::AfterScript) {
    let unsettled = !diagnostics.is_empty() && diagnostics.iter().all(|d| d.code == "OAM-RT0003");
    if unsettled {
        (
            "(function () { var p = globalThis.process; if (p && p.exitCode === undefined) { p.exitCode = 13; } })();",
            oam_engine::AfterScript::Microtasks,
        )
    } else {
        (
            "(function () { var p = globalThis.process; if (p && !p._exiting) { p.exitCode = 1; } })();",
            oam_engine::AfterScript::Nothing,
        )
    }
}

/// Pre-engine failure: diagnostics with Node's generic fatal exit code 1.
fn err_exit(diagnostics: Vec<Diagnostic>) -> (Vec<Diagnostic>, u8) {
    (diagnostics, 1)
}

// -- oam compile: embed a pre-bundled JS file into a standalone binary --

/// Magic trailers marking an embedded payload, checked at startup.
/// - v1 (JS only):     `[JS][u64 LE js_len][b"OAMEXEC\0"]` (16-byte trailer)
/// - v2 (JS+bytecode): `[JS][bytecode][u64 LE js_len][u64 LE bc_len][b"OAMEXC2\0"]`
///   (24-byte trailer). v2 embeds V8 bytecode so the compiled binary's first
///   run skips parse+compile even with no writable cache dir.
///
/// Both are read by `extract_embedded`. `oam compile` writes v2 when bytecode
/// production succeeds, else falls back to v1.
const COMPILE_MAGIC: &[u8; 8] = b"OAMEXEC\0";
const COMPILE_MAGIC_V2: &[u8; 8] = b"OAMEXC2\0";

/// True when `bytes` already ends with either compile trailer magic, i.e. it
/// is itself a compile output rather than a plain oam binary. Used to reject
/// such a file as a `--carrier`: appending onto it would nest payloads, and
/// since the loader reads the LAST trailer it would silently keep running the
/// older embedded program.
fn ends_with_compile_magic(bytes: &[u8]) -> bool {
    let Some(tail) = bytes.get(bytes.len().wrapping_sub(8)..) else {
        return false;
    };
    tail == COMPILE_MAGIC.as_slice() || tail == COMPILE_MAGIC_V2.as_slice()
}

/// clap subcommand names. Lifted to module scope because TWO places need the
/// same list and they must not drift: the bare-script dispatch (a real
/// subcommand wins over a same-named file in the cwd) and `space_form_hint`
/// (a subcommand after a bare grant is a legitimate shape, not a mis-typed
/// list). Duplicating it once already produced a regression that broke
/// `oam --permission --allow-env help`.
const SUBCOMMANDS: &[&str] = &[
    "run",
    "test",
    "repl",
    "check",
    "daemon",
    "mcp",
    "serve",
    "install",
    "trust",
    "compile",
    "cache",
    "self-update",
    "help",
    // The hidden daemon-server subcommand is still a subcommand: a stray cwd
    // file named like it must not win the bare-script dispatch over clap.
    "__oamd-ts",
];

/// Catch the space-separated grant form (`--allow-net 127.0.0.1:5432`) that
/// Deno accepts and oam does not.
///
/// A bare `--allow-net` consumes only itself, so the next token falls through
/// as the script path -- and the run dies with "cannot find module
/// 127.0.0.1:5432", which points at the wrong thing entirely. The test is
/// "the next token is not a flag AND does not exist on disk": the script must
/// exist for the run to succeed at all, so a non-existent non-flag there is
/// always a mistake, whether a space-form grant or a typo'd path. Returns the
/// message to print, or None when the argument is fine.
///
/// `--allow-fs-read` has no bare form, so this ambiguity is unique to the two
/// grants that do.
fn space_form_hint(flag: &str, next: Option<&String>) -> Option<String> {
    let next = next?;
    // A subcommand after node-style flags is a legitimate shape -- the
    // dispatch below lets a real subcommand win -- and subcommand names are
    // neither flags nor files, so without this they read as mis-typed grant
    // lists and `oam --permission --allow-env help` dies instead of running.
    if next.starts_with('-') || SUBCOMMANDS.contains(&next.as_str()) || Path::new(next).exists() {
        return None;
    }
    Some(format!(
        "oam: `{flag} {next}` -- {flag} takes its list with '=' (e.g. {flag}={next}), not a space.\n\
         A bare {flag} grants everything; as written, '{next}' was taken as the script path and does not exist."
    ))
}

/// Same check against a file, reading only its final 8 bytes. A carrier is a
/// whole oam binary (tens of MB), so this must not slurp the file.
fn file_ends_with_compile_magic(path: &Path) -> std::io::Result<bool> {
    use std::io::{Read, Seek, SeekFrom};
    let mut f = std::fs::File::open(path)?;
    if f.metadata()?.len() < 8 {
        return Ok(false);
    }
    let mut magic = [0u8; 8];
    f.seek(SeekFrom::End(-8))?;
    f.read_exact(&mut magic)?;
    Ok(ends_with_compile_magic(&magic))
}

/// Inspect the tail of the current executable for an embedded payload.
/// Returns `Some((source, bytecode))` where `bytecode` is `Some` only for a
/// v2 binary that carries embedded V8 bytecode; `None` for a normal CLI
/// binary. Both the v1 and v2 trailer formats are recognized.
fn extract_embedded() -> Option<(String, Option<Vec<u8>>)> {
    let exe = std::env::current_exe().ok()?;
    let mut f = std::fs::File::open(&exe).ok()?;
    let file_len = f.metadata().ok()?.len();
    if file_len < 8 {
        return None;
    }
    // The magic is always the final 8 bytes.
    let mut magic = [0u8; 8];
    f.seek(SeekFrom::End(-8)).ok()?;
    f.read_exact(&mut magic).ok()?;

    if &magic == COMPILE_MAGIC_V2 {
        // v2 trailer (24 bytes): [js_len u64][bc_len u64][magic].
        if file_len < 24 {
            return None;
        }
        let mut lens = [0u8; 16];
        f.seek(SeekFrom::End(-24)).ok()?;
        f.read_exact(&mut lens).ok()?;
        let js_len = u64::from_le_bytes(lens[0..8].try_into().unwrap());
        let bc_len = u64::from_le_bytes(lens[8..16].try_into().unwrap());
        // The two payloads + 24-byte trailer must fit in the file.
        let payload = js_len.checked_add(bc_len)?;
        if payload > file_len - 24 {
            return None;
        }
        let js_off = file_len - 24 - payload;
        f.seek(SeekFrom::Start(js_off)).ok()?;
        let mut js_buf = vec![0u8; js_len as usize];
        f.read_exact(&mut js_buf).ok()?;
        // The cursor is now at the start of the bytecode (js_off + js_len).
        let mut bc_buf = vec![0u8; bc_len as usize];
        f.read_exact(&mut bc_buf).ok()?;
        let source = String::from_utf8(js_buf).ok()?;
        let bytecode = (!bc_buf.is_empty()).then_some(bc_buf);
        return Some((source, bytecode));
    }

    if &magic == COMPILE_MAGIC {
        // v1 trailer (16 bytes): [js_len u64][magic]. JS only.
        if file_len < 16 {
            return None;
        }
        let mut len_bytes = [0u8; 8];
        f.seek(SeekFrom::End(-16)).ok()?;
        f.read_exact(&mut len_bytes).ok()?;
        let js_len = u64::from_le_bytes(len_bytes);
        if js_len > file_len - 16 {
            return None;
        }
        let offset = file_len - 16 - js_len;
        f.seek(SeekFrom::Start(offset)).ok()?;
        let mut buf = vec![0u8; js_len as usize];
        f.read_exact(&mut buf).ok()?;
        return Some((String::from_utf8(buf).ok()?, None));
    }

    None
}

/// Execute embedded JS source as a CJS script (the typical output of
/// esbuild/rollup --format=cjs). Supports `--inspect` / `--inspect-brk`
/// flags for debugging the compiled binary.
/// `oam -e <code>` / `oam -p <code>`: evaluate a string as a CJS program,
/// Node-shaped. The source runs from a file named `[eval]` inside the CWD
/// so require() resolves relative paths and node_modules from the CWD the
/// way node's eval does; -p prints the completion value via console.log.
/// process.argv = [exe, ...extra] (node omits a script-path slot for eval).
/// Falls back to a temp dir when the CWD is not writable (read-only mount,
/// sandbox) -- require() resolution then roots at that temp dir.
/// Node process-level flags accepted before any oam subcommand (also read
/// from NODE_OPTIONS). They reach JS as non-enumerable globals -- node's own
/// test/common leaked-globals check walks enumerable globals.
#[derive(Default, Clone, PartialEq)]
struct NodeFlags {
    pending_deprecation: bool,
    expose_gc: bool,
    permission: bool,
    /// Node's granular grants. Only meaningful under `--permission`, which
    /// denies everything first. One value per occurrence of the flag, in
    /// order: a repeated flag adds to the earlier ones, as node's does.
    allow_fs_read: Vec<String>,
    allow_fs_write: Vec<String>,
    /// `--allow-net[=list]` and `--allow-env[=list]`, one value per
    /// occurrence. Bare form grants everything (stored as `"*"`); `=a,b`
    /// grants a list.
    ///
    /// Without these, `permissions()` hardcoded net and env closed, so
    /// `--permission` denied all network access with no way to open it. That
    /// made the whole permission model unusable for any server: a process
    /// that cannot open a socket has nothing left to do.
    ///
    /// Both are enforced end to end. `Permissions::check_env` already existed
    /// (oam_engine/src/permissions.rs:142) but nothing called it -- `op_env`
    /// copied the whole environment unconditionally, so env reads succeeded
    /// under `--permission` regardless of any grant. `op_env` now filters
    /// through it, so a denied variable is absent from `process.env` rather
    /// than throwing: it is a snapshot object with no per-property hook, and
    /// an exception would leak the names of variables the script may not see.
    allow_net: Vec<String>,
    allow_env: Vec<String>,
    allow_child_process: bool,
    allow_worker: bool,
    allow_addons: bool,
    /// `--env-file=P` (required) and `--env-file-if-exists=P` (optional), in
    /// command-line order -- Node applies them left to right, later files
    /// winning.
    env_files: Vec<(String, bool)>,
    /// `--input-type=commonjs|module`: how `--eval` source is interpreted.
    /// oam runs eval from a real file, so this picks the extension.
    input_type: Option<String>,
    no_warnings: bool,
    no_deprecation: bool,
    /// `--trace-warnings` / `--trace-deprecation`: the default warning
    /// printer writes the warning's stack (every warning / deprecations),
    /// read from `process.traceProcessWarnings` / `process.traceDeprecation`.
    trace_warnings: bool,
    trace_deprecation: bool,
    /// `--trace-uncaught`: a fatal report ends with the stack V8 captured
    /// at the throw (`Thrown at:`) instead of the hint naming this flag.
    trace_uncaught: bool,
    disabled_warnings: Vec<String>,
    redirect_warnings: Option<String>,
    /// Node flags that are really V8 flags: forwarded verbatim before
    /// V8::initialize rather than reimplemented.
    allow_natives_syntax: bool,
    js_float16array: bool,
    /// `--zero-fill-buffers`: Buffer.allocUnsafe behaves like Buffer.alloc.
    zero_fill_buffers: bool,
    /// `--title=x`: the initial process.title.
    title: Option<String>,
    /// `--expose-internals`: make `require('internal/...')` resolve. A
    /// test/debug surface in Node too -- never listed in builtinModules.
    expose_internals: bool,
    experimental_vm_modules: bool,
    /// `--max-http-header-size=N`, as given (node parses it like strtoull:
    /// `12abc` is 12). Kept raw so execArgv hands it back unchanged.
    max_http_header_size: Option<String>,
    /// It was given as two tokens (`--max-http-header-size N`), which is how
    /// execArgv hands it back.
    max_http_header_size_spaced: bool,
    /// `--v8-pool-size=N`: the V8 platform's worker-thread count (see
    /// oam_engine::set_v8_pool_size). Kept raw, like the header size, so
    /// execArgv hands it back unchanged and a fork child sizes its pool the
    /// same way.
    v8_pool_size: Option<String>,
    v8_pool_size_spaced: bool,
    /// `--insecure-http-parser`.
    insecure_http_parser: bool,
    /// `--trace-require-module=all|no-node-modules`: the once-per-process
    /// ExperimentalWarning when a CommonJS module require()s an ES module
    /// (node 22 prints none without it). `no-node-modules` leaves out a
    /// require made from inside node_modules. Spaced as for the header size.
    trace_require_module: Option<String>,
    trace_require_module_spaced: bool,
    /// `--tls-min-v1.0` / `--tls-min-v1.1` / `--tls-min-v1.2` /
    /// `--tls-min-v1.3` and `--tls-max-v1.2` / `--tls-max-v1.3`: the initial
    /// `tls.DEFAULT_MIN_VERSION` / `DEFAULT_MAX_VERSION`, so the default
    /// version range of every TLS connection and server. Each is kept as
    /// given -- execArgv hands every one back -- and node's precedence when
    /// several are set is applied by `tls_default_versions`.
    tls_min_v1_0: bool,
    tls_min_v1_1: bool,
    tls_min_v1_2: bool,
    tls_min_v1_3: bool,
    tls_max_v1_2: bool,
    tls_max_v1_3: bool,
    /// The flags argv gave, kept apart from NODE_OPTIONS's once the two are
    /// merged (`merged`): what `process.execArgv` reflects, node listing
    /// only argv there. None on a set that was never merged.
    argv: Option<Box<NodeFlags>>,
}

impl NodeFlags {
    /// NODE_OPTIONS's flags (`self`) under argv's: a value argv gave wins,
    /// a toggle either gave is on, a list holds the environment's entries
    /// then argv's (node applies NODE_OPTIONS first, so a later `--env-file`
    /// on the command line still wins, and a permission grant in either
    /// holds), and `argv` is kept for execArgv.
    fn merged(self, argv: NodeFlags) -> NodeFlags {
        let env = self;
        let (max_http_header_size, max_http_header_size_spaced) =
            if argv.max_http_header_size.is_some() {
                (
                    argv.max_http_header_size.clone(),
                    argv.max_http_header_size_spaced,
                )
            } else {
                (env.max_http_header_size, env.max_http_header_size_spaced)
            };
        let (trace_require_module, trace_require_module_spaced) =
            if argv.trace_require_module.is_some() {
                (
                    argv.trace_require_module.clone(),
                    argv.trace_require_module_spaced,
                )
            } else {
                (env.trace_require_module, env.trace_require_module_spaced)
            };
        let (v8_pool_size, v8_pool_size_spaced) = if argv.v8_pool_size.is_some() {
            (argv.v8_pool_size.clone(), argv.v8_pool_size_spaced)
        } else {
            (env.v8_pool_size, env.v8_pool_size_spaced)
        };
        NodeFlags {
            pending_deprecation: env.pending_deprecation || argv.pending_deprecation,
            expose_gc: env.expose_gc || argv.expose_gc,
            permission: env.permission || argv.permission,
            allow_fs_read: [env.allow_fs_read, argv.allow_fs_read.clone()].concat(),
            allow_fs_write: [env.allow_fs_write, argv.allow_fs_write.clone()].concat(),
            allow_net: [env.allow_net, argv.allow_net.clone()].concat(),
            allow_env: [env.allow_env, argv.allow_env.clone()].concat(),
            allow_child_process: env.allow_child_process || argv.allow_child_process,
            allow_worker: env.allow_worker || argv.allow_worker,
            allow_addons: env.allow_addons || argv.allow_addons,
            env_files: [env.env_files, argv.env_files.clone()].concat(),
            input_type: argv.input_type.clone().or(env.input_type),
            no_warnings: env.no_warnings || argv.no_warnings,
            no_deprecation: env.no_deprecation || argv.no_deprecation,
            trace_warnings: env.trace_warnings || argv.trace_warnings,
            trace_deprecation: env.trace_deprecation || argv.trace_deprecation,
            trace_uncaught: env.trace_uncaught || argv.trace_uncaught,
            disabled_warnings: [env.disabled_warnings, argv.disabled_warnings.clone()].concat(),
            redirect_warnings: argv.redirect_warnings.clone().or(env.redirect_warnings),
            allow_natives_syntax: env.allow_natives_syntax || argv.allow_natives_syntax,
            js_float16array: env.js_float16array || argv.js_float16array,
            zero_fill_buffers: env.zero_fill_buffers || argv.zero_fill_buffers,
            title: argv.title.clone().or(env.title),
            expose_internals: env.expose_internals || argv.expose_internals,
            experimental_vm_modules: env.experimental_vm_modules || argv.experimental_vm_modules,
            max_http_header_size,
            max_http_header_size_spaced,
            v8_pool_size,
            v8_pool_size_spaced,
            trace_require_module,
            trace_require_module_spaced,
            insecure_http_parser: env.insecure_http_parser || argv.insecure_http_parser,
            tls_min_v1_0: env.tls_min_v1_0 || argv.tls_min_v1_0,
            tls_min_v1_1: env.tls_min_v1_1 || argv.tls_min_v1_1,
            tls_min_v1_2: env.tls_min_v1_2 || argv.tls_min_v1_2,
            tls_min_v1_3: env.tls_min_v1_3 || argv.tls_min_v1_3,
            tls_max_v1_2: env.tls_max_v1_2 || argv.tls_max_v1_2,
            tls_max_v1_3: env.tls_max_v1_3 || argv.tls_max_v1_3,
            argv: Some(Box::new(argv)),
        }
    }

    /// The initial `tls.DEFAULT_MIN_VERSION` / `DEFAULT_MAX_VERSION` the
    /// flags ask for, in node's precedence (lib/tls.js: the first of
    /// --tls-min-v1.0, v1.1, v1.2, v1.3 that is set names the minimum, and
    /// --tls-max-v1.3 beats --tls-max-v1.2, from argv and NODE_OPTIONS
    /// together), or None for node's own default.
    fn tls_default_versions(&self) -> (Option<&'static str>, Option<&'static str>) {
        let min = if self.tls_min_v1_0 {
            Some("TLSv1")
        } else if self.tls_min_v1_1 {
            Some("TLSv1.1")
        } else if self.tls_min_v1_2 {
            Some("TLSv1.2")
        } else if self.tls_min_v1_3 {
            Some("TLSv1.3")
        } else {
            None
        };
        let max = if self.tls_max_v1_3 {
            Some("TLSv1.3")
        } else if self.tls_max_v1_2 {
            Some("TLSv1.2")
        } else {
            None
        };
        (min, max)
    }

    /// Publish `--max-http-header-size` / `--insecure-http-parser` to the
    /// process-wide state oam_core reads (they are not per-runtime: workers
    /// share them, as in node).
    fn apply_http_parser_flags(&self) {
        use oam_engine::http_head;
        if let Some(raw) = &self.max_http_header_size {
            http_head::set_max_http_header_size(http_head::parse_max_header_size_flag(raw));
        }
        if self.insecure_http_parser {
            http_head::set_insecure_http_parser(true);
        }
    }

    fn install(&self, rt: &mut oam_engine::JsRuntime) {
        let env_is_1 = |name: &str| std::env::var(name).as_deref() == Ok("1");
        // NODE_PENDING_DEPRECATION is one of node's options, read once at
        // startup; a worker that inherits this process's options inherits it.
        let mut options = self.clone();
        options.pending_deprecation |= env_is_1("NODE_PENDING_DEPRECATION");
        let mut js = options.environment_js(env_is_1("NODE_NO_WARNINGS"));
        js.push_str(&self.process_js());
        if !js.is_empty() {
            let _ = rt.execute_script("<flags>", &js);
            rt.sync_trace_uncaught();
            // oam.fork()'s in-process pool gets its own isolate; publish the
            // same snippet so it inherits the flags instead of starting
            // clean. (A worker_threads Worker decides its own: see
            // worker_flags_js.)
            oam_engine::set_inherited_flags_js(js);
        }
        PARENT_OPTIONS.set(options).ok();
    }

    /// The flags node keeps per environment -- each worker_threads Worker has
    /// its own, decided by its `execArgv` and `env` -- as the JS snippet that
    /// installs them. `no_warnings_env` is NODE_NO_WARNINGS=1 in that
    /// environment's process.env.
    fn environment_js(&self, no_warnings_env: bool) -> String {
        let mut js = String::new();
        if self.pending_deprecation {
            js.push_str(&define_flag_global(
                "__oamPendingDeprecation",
                "true".into(),
            ));
        }
        // --no-warnings, and NODE_NO_WARNINGS=1 which is the same thing to
        // node: the default 'warning' listener is not there at all, so
        // `process.listenerCount("warning")` is 0 (the event is still
        // emitted to a program's own listeners).
        if self.no_warnings || no_warnings_env {
            let def = define_flag_global;
            js.push_str(&def("__oamNoWarnings", "true".into()));
            js.push_str(
                "for (const f of globalThis.process.listeners('warning')) \
                   if (f.name === 'onWarning') globalThis.process.removeListener('warning', f);",
            );
        }
        let def = define_flag_global;
        if self.no_deprecation {
            js.push_str(&def("__oamNoDeprecation", "true".into()));
            js.push_str("globalThis.process.noDeprecation = true;");
        }
        // node defines these only when the flag is given (absent otherwise,
        // not false), read-only, enumerable and configurable; the printer
        // reads them on each warning, so a program can set them too.
        for (set, name) in [
            (self.trace_warnings, "traceProcessWarnings"),
            (self.trace_deprecation, "traceDeprecation"),
        ] {
            if set {
                js.push_str(&format!(
                    "Object.defineProperty(globalThis.process, '{name}', \
                       {{ value: true, writable: false, enumerable: true, configurable: true }});"
                ));
            }
        }
        // The engine reads it once the snippet has run
        // (JsRuntime::sync_trace_uncaught), to capture uncaught throws'
        // stacks before any user code runs.
        if self.trace_uncaught {
            js.push_str(&def("__oamTraceUncaught", "true".into()));
        }
        if !self.disabled_warnings.is_empty() {
            let list =
                serde_json::to_string(&self.disabled_warnings).unwrap_or_else(|_| "[]".into());
            js.push_str(&def("__oamDisabledWarnings", list));
        }
        if let Some(path) = &self.redirect_warnings {
            let p = serde_json::to_string(path).unwrap_or_else(|_| "\"\"".into());
            js.push_str(&def("__oamRedirectWarnings", p));
        }
        // cjs.rs reads it on the first require() of an ES module. node keeps
        // it per environment, so a worker's own execArgv / NODE_OPTIONS
        // decide it. The value is one of node's two words, so quoting it is
        // all the escaping it needs.
        if let Some(mode) = &self.trace_require_module {
            js.push_str(&def("__oamTraceRequireModule", format!("\"{mode}\"")));
        }
        // node:tls reads these as the initial DEFAULT_MIN_VERSION /
        // DEFAULT_MAX_VERSION (the names are node's own four, so quoting
        // them is all the escaping they need).
        let (tls_min, tls_max) = self.tls_default_versions();
        if let Some(v) = tls_min {
            js.push_str(&def("__oamTlsMinVersion", format!("\"{v}\"")));
        }
        if let Some(v) = tls_max {
            js.push_str(&def("__oamTlsMaxVersion", format!("\"{v}\"")));
        }
        js
    }

    /// The flags node keeps for the whole process (a Worker refuses them in
    /// its `execArgv` with ERR_WORKER_INVALID_EXEC_ARGV, and every thread
    /// has them), as the JS snippet that installs them.
    fn process_js(&self) -> String {
        let mut js = String::new();
        if self.zero_fill_buffers {
            js.push_str(&define_flag_global("__oamZeroFillBuffers", "true".into()));
        }
        if let Some(title) = &self.title {
            let t = serde_json::to_string(title).unwrap_or_else(|_| "\"\"".into());
            js.push_str(&format!("globalThis.process.title = {t};"));
        }
        js
    }

    /// Apply `--env-file` before the program runs. Node parses these in C++
    /// (node_dotenv.cc); oam reuses the same parser userland gets via
    /// `process.loadEnvFile` so the two can never drift. Err = exit code 9,
    /// matching Node's abort on a missing required file.
    fn apply_env_files(&self, rt: &mut oam_engine::JsRuntime) -> Result<(), u8> {
        for (path, required) in &self.env_files {
            let literal = serde_json::to_string(path).unwrap_or_else(|_| "\"\"".into());
            let script = format!("globalThis.process.loadEnvFile({literal});");
            if let Err(e) = rt.execute_script("<env-file>", &script) {
                if *required {
                    let exe = std::env::current_exe()
                        .map(|p| p.to_string_lossy().into_owned())
                        .unwrap_or_else(|_| "oam".to_string());
                    let _ = e;
                    eprintln!("{exe}: {path}: not found");
                    return Err(9);
                }
                eprintln!("{path} not found. Continuing without it.");
            }
        }
        Ok(())
    }

    /// Node's `--permission` denies everything not explicitly allowed; oam's
    /// permission checks are already enforced in the native fs/net/env ops,
    /// so the flag just constructs the restrictive option set.
    fn permissions(&self) -> Option<oam_engine::PermissionsOptions> {
        if !self.permission {
            return None;
        }
        // Every occurrence of a flag grants its entries (`values`, in
        // order). A value `*` is "everything", beside any other value, as in
        // node; any other value is a comma-separated allow-list, oam's
        // spelling (node v22 takes a value as one path:
        // docs/node-divergences.md, section 4).
        fn grant(values: &[String]) -> oam_engine::BoolOrList {
            if values.is_empty() {
                return oam_engine::BoolOrList::Bool(false);
            }
            if values.iter().any(|value| value == "*") {
                return oam_engine::BoolOrList::Bool(true);
            }
            oam_engine::BoolOrList::List(
                values
                    .iter()
                    .flat_map(|value| value.split(','))
                    .map(str::trim)
                    .filter(|entry| !entry.is_empty())
                    .map(str::to_string)
                    .collect(),
            )
        }
        Some(oam_engine::PermissionsOptions {
            read: grant(&self.allow_fs_read),
            write: grant(&self.allow_fs_write),
            net: grant(&self.allow_net),
            env: grant(&self.allow_env),
            // --allow-addons is node's name for loading native addons, which
            // is what oam's `ffi` permission gates.
            ffi: oam_engine::BoolOrList::Bool(self.allow_addons),
            child: oam_engine::BoolOrList::Bool(self.allow_child_process),
            // Separate from `child` now that a worker INHERITS this permission
            // set. --allow-worker used to imply --allow-child-process because
            // an all-granted worker could spawn its way out; with inheritance
            // that is no longer true, and conflating them over-granted every
            // caller that only wanted a worker.
            worker: oam_engine::BoolOrList::Bool(self.allow_worker),
        })
    }

    /// The subset node reflects in process.execArgv: the flags argv gave,
    /// never NODE_OPTIONS's (a merged set answers for its `argv` half; one
    /// never merged answers for itself).
    fn exec_argv(&self) -> Vec<String> {
        if let Some(argv) = &self.argv {
            return argv.exec_argv();
        }
        let mut out = Vec::new();
        if self.pending_deprecation {
            out.push("--pending-deprecation".into());
        }
        if self.expose_gc {
            out.push("--expose-gc".into());
        }
        if self.experimental_vm_modules {
            out.push("--experimental-vm-modules".into());
        }
        if self.permission {
            out.push("--permission".into());
        }
        for list in &self.allow_fs_read {
            out.push(format!("--allow-fs-read={list}"));
        }
        for list in &self.allow_fs_write {
            out.push(format!("--allow-fs-write={list}"));
        }
        // Round-trip the bare form as bare: a script reading process.execArgv
        // to re-spawn itself should get back the flags it was given, not a
        // `=*` spelling node never produces.
        for list in &self.allow_net {
            out.push(if list == "*" {
                "--allow-net".into()
            } else {
                format!("--allow-net={list}")
            });
        }
        for list in &self.allow_env {
            out.push(if list == "*" {
                "--allow-env".into()
            } else {
                format!("--allow-env={list}")
            });
        }
        if self.allow_child_process {
            out.push("--allow-child-process".into());
        }
        if self.allow_worker {
            out.push("--allow-worker".into());
        }
        if self.allow_addons {
            out.push("--allow-addons".into());
        }
        if self.no_warnings {
            out.push("--no-warnings".into());
        }
        if self.no_deprecation {
            out.push("--no-deprecation".into());
        }
        if self.trace_warnings {
            out.push("--trace-warnings".into());
        }
        if self.trace_deprecation {
            out.push("--trace-deprecation".into());
        }
        if self.trace_uncaught {
            out.push("--trace-uncaught".into());
        }
        for w in &self.disabled_warnings {
            out.push(format!("--disable-warning={w}"));
        }
        if let Some(p) = &self.redirect_warnings {
            out.push(format!("--redirect-warnings={p}"));
        }
        if let Some(v) = &self.max_http_header_size {
            if self.max_http_header_size_spaced {
                out.push("--max-http-header-size".into());
                out.push(v.clone());
            } else {
                out.push(format!("--max-http-header-size={v}"));
            }
        }
        if let Some(v) = &self.v8_pool_size {
            if self.v8_pool_size_spaced {
                out.push("--v8-pool-size".into());
                out.push(v.clone());
            } else {
                out.push(format!("--v8-pool-size={v}"));
            }
        }
        if let Some(v) = &self.trace_require_module {
            if self.trace_require_module_spaced {
                out.push("--trace-require-module".into());
                out.push(v.clone());
            } else {
                out.push(format!("--trace-require-module={v}"));
            }
        }
        if self.insecure_http_parser {
            out.push("--insecure-http-parser".into());
        }
        for (set, flag) in [
            (self.tls_min_v1_0, "--tls-min-v1.0"),
            (self.tls_min_v1_1, "--tls-min-v1.1"),
            (self.tls_min_v1_2, "--tls-min-v1.2"),
            (self.tls_min_v1_3, "--tls-min-v1.3"),
            (self.tls_max_v1_2, "--tls-max-v1.2"),
            (self.tls_max_v1_3, "--tls-max-v1.3"),
        ] {
            if set {
                out.push(flag.into());
            }
        }
        out
    }
}

/// Remove the eval source file (and its temp dir, when the CWD was not
/// writable). Best-effort: a `process.exit()` inside the eval terminates the
/// process before this runs, so the CWD file name carries the pid and a
/// stale-file sweep is not attempted.
fn cleanup_eval_artifacts(tmp_dir: Option<&Path>, tmp_file: &Path) {
    match tmp_dir {
        Some(dir) => {
            let _ = std::fs::remove_dir_all(dir);
        }
        None => {
            let _ = std::fs::remove_file(tmp_file);
        }
    }
}

fn run_eval(source: &str, print: bool, extra_args: &[String], flags: &NodeFlags) -> ExitCode {
    // Node's eval module resolves from CWD; oam executes a real file, so
    // place it in the CWD (unique name, cleaned up below).
    // Node reads --input-type to decide how to parse --eval source; oam runs
    // it from a real file, so the extension carries the same decision.
    let ext = match flags.input_type.as_deref() {
        None | Some("commonjs") => "cjs",
        Some("module") => "mjs",
        Some(other) => {
            eprintln!("oam: --input-type must be \"commonjs\" or \"module\", got \"{other}\"");
            return ExitCode::from(9);
        }
    };
    let cwd_candidate = std::env::current_dir()
        .ok()
        .map(|d| d.join(format!(".oam-eval-{}.{ext}", std::process::id())));
    let (tmp_dir, tmp_file) = match cwd_candidate {
        // Scratch, the owner's alone whatever mask this started under: a
        // parent may have set one that takes the owner's own bits off, and
        // the source written here is read back by this process.
        Some(p) if own_files::write(&p, "", Audience::Scratch).is_ok() => (None, p),
        _ => {
            let dir = std::env::temp_dir().join(format!("oam-eval-{}", std::process::id()));
            own_files::create_dir_all(&dir, Audience::Scratch).expect("create eval temp dir");
            let file = dir.join(format!("__oam_eval.{ext}"));
            (Some(dir), file)
        }
    };
    // The cleanup below only runs if the script RETURNS. `oam -e
    // "process.exit(0)"` never does -- V8 exits from inside the op -- so the
    // artifact was left in the user's working directory. Register it so the
    // hard-exit path removes it too.
    oam_engine::register_exit_cleanup(tmp_dir.clone().unwrap_or_else(|| tmp_file.clone()));
    // Queued loader warnings must survive a `process.exit()` inside the eval
    // the same way the temp file must be removed by one.
    drain_loader_warnings_on_hard_exit(false);
    // -p evaluates through a DIRECT eval, which yields the completion value
    // of a statement list the way node's script evaluation does
    // (`-p "a(); b"` prints b) AND inherits the enclosing module scope. It
    // used to be an indirect `(0, eval)`, whose scope is the GLOBAL one --
    // so `oam -pe "require('assert')"` died with "require is not defined"
    // while the identical `-e` worked, because require is a parameter of
    // the CJS module wrapper, not a global.
    //
    // The user source stays the FIRST thing in the file so a leading
    // 'use strict' keeps its directive-prologue position and line numbers
    // are not shifted; the builtin-globals prelude runs separately, before
    // this file (see EVAL_PRELUDE at the call site).
    let body = if print {
        format!(
            "console.log(eval({}));\n",
            serde_json::to_string(source).expect("encode eval source")
        )
    } else {
        source.to_string()
    };
    own_files::write(&tmp_file, body, Audience::Scratch).expect("write eval source to temp");

    let mut rt = oam_engine::JsRuntime::new_with_permissions(flags.permissions());
    let exe = std::env::current_exe()
        .map(|p| p.to_string_lossy().into_owned())
        .unwrap_or_else(|_| "oam".to_string());
    let mut argv = vec![exe];
    argv.extend(extra_args.iter().cloned());
    rt.set_process_argv(argv);
    // Node's eval context exposes builtin modules as lazy globals
    // (addBuiltinLibsToObject): `oam -e "url.parse(...)"` works bare, and
    // assignment overrides the getter. Sub-path builtins (timers/promises),
    // '_'-prefixed legacy aliases, and existing globals are skipped. Runs
    // as its own script so the user source keeps prologue position.
    // Sourced from the builtin registry, NOT require(): this runs as a bare
    // script (no CJS scope), and it must run before the user source so the
    // globals exist without displacing the source's directive prologue.
    const EVAL_PRELUDE: &str = "(function () {\n  var reg = globalThis.__oamNode;\n  if (!reg || !reg.factories || typeof reg.get !== 'function') return;\n  var names = Object.keys(reg.factories);\n  for (var i = 0; i < names.length; i++) (function (n) {\n    if (n.indexOf('/') !== -1 || n.charAt(0) === '_' || n === 'module' || n in globalThis) return;\n    Object.defineProperty(globalThis, n, {\n      configurable: true, enumerable: false,\n      get: function () {\n        var v = reg.get(n);\n        Object.defineProperty(globalThis, n, { configurable: true, enumerable: false, writable: true, value: v });\n        return v;\n      },\n      set: function (v) {\n        Object.defineProperty(globalThis, n, { configurable: true, enumerable: false, writable: true, value: v });\n      },\n    });\n  })(names[i]);\n})();\n";
    let _ = rt.execute_script("<eval-prelude>", EVAL_PRELUDE);
    // execArgv carries the node flags (suite children re-spawn with
    // [...process.execArgv, ...]); the eval source itself is not included.
    flags.install(&mut rt);
    if flags.apply_env_files(&mut rt).is_err() {
        return ExitCode::from(9);
    }
    let exec_argv = flags.exec_argv();
    if !exec_argv.is_empty() {
        let json = serde_json::to_string(&exec_argv).unwrap_or_else(|_| "[]".into());
        let _ = rt.execute_script("<flags>", &format!("globalThis.process.execArgv = {json};"));
    }

    // --input-type=module makes the eval source an ES module.
    let result = if ext == "mjs" {
        rt.execute_module(&tmp_file, &CliHost)
    } else {
        // No main module for eval source, as in node: require.main stays
        // undefined, so the temp file never reads as the program's entry.
        rt.execute_cjs_eval(&tmp_file, &CliHost)
    };
    cleanup_eval_artifacts(tmp_dir.as_deref(), &tmp_file);
    report_loader_warnings(false);
    // Same fatal-path shape as run_file: sub-codes skip 'exit', a regular
    // fatal forces 1 + honors exit-handler mutations.
    match result {
        Ok(()) => {
            rt.emit_process_exit();
            ExitCode::from(rt.process_exit_code().unwrap_or(0).clamp(0, 255) as u8)
        }
        Err(diagnostics) => {
            let sub_code = rt
                .execute_script_draining(
                    "<fatal-sub-code>",
                    "String((globalThis.process && globalThis.process.__oamFatalCode) || '')",
                    oam_engine::AfterScript::Nothing,
                )
                .ok()
                .and_then(|s| s.parse::<u8>().ok());
            if let Some(code) = sub_code {
                // Skips `emit_process_exit` -- see the run_file site above.
                oam_engine::run_exit_hooks();
                for d in &diagnostics {
                    render(d, false);
                }
                return ExitCode::from(code);
            }
            let (exit_code_script, after_exit) = fatal_exit_shape(&diagnostics);
            let _ = rt.execute_script_draining(
                "<fatal-exit-code>",
                exit_code_script,
                oam_engine::AfterScript::Nothing,
            );
            // node runs the 'exit' listeners, then prints the report
            // (TriggerUncaughtException: _fatalException, then
            // ReportFatalException), as run_file's caller does (#399 item 10).
            rt.emit_process_exit_after(after_exit);
            for d in &diagnostics {
                render(d, false);
            }
            ExitCode::from(rt.process_exit_code().unwrap_or(1).clamp(0, 255) as u8)
        }
    }
}

fn run_embedded(source: &str, bytecode: Option<Vec<u8>>, args: Vec<String>) -> ExitCode {
    // Parse --inspect / --inspect-brk from raw args (we bypass clap for
    // embedded binaries so the user's positional args pass through).
    let mut inspect: Option<(std::net::SocketAddr, bool)> = None;
    let mut script_args: Vec<String> = Vec::new();
    let mut iter = args.iter().skip(1); // skip argv[0]
    #[allow(clippy::while_let_on_iterator)] // need iter.cloned() inside the loop body
    while let Some(arg) = iter.next() {
        if arg == "--inspect-brk" || arg.starts_with("--inspect-brk=") {
            let value = if let Some(v) = arg.strip_prefix("--inspect-brk=") {
                v.to_string()
            } else {
                "127.0.0.1:9229".to_string()
            };
            match resolve_inspect(None, Some(&value)) {
                Ok(v) => inspect = v,
                Err(e) => {
                    eprintln!("{e}");
                    return ExitCode::FAILURE;
                }
            }
        } else if arg == "--inspect" || arg.starts_with("--inspect=") {
            let value = if let Some(v) = arg.strip_prefix("--inspect=") {
                v.to_string()
            } else {
                "127.0.0.1:9229".to_string()
            };
            match resolve_inspect(Some(&value), None) {
                Ok(v) => inspect = v,
                Err(e) => {
                    eprintln!("{e}");
                    return ExitCode::FAILURE;
                }
            }
        } else if arg == "--" {
            script_args.extend(iter.cloned());
            break;
        } else {
            script_args.push(arg.clone());
        }
    }

    // ALL-GRANTED, deliberately -- audited as an exemption in
    // `runtime_construction_audit` below, not an oversight.
    //
    // Two reasons a CLI permission flag cannot be honoured here. `main` calls
    // this at the top, BEFORE the node-flag pre-parse runs, so `NODE_FLAGS` is
    // never populated on this path. And the loop above deliberately forwards
    // every unrecognised argument to the embedded script -- that pass-through
    // is the contract for a self-contained binary, so lifting `--permission`
    // out of argv would silently steal an argument from an app that defines its
    // own.
    //
    // The gap this leaves is real: an embedded binary always runs unsandboxed
    // and its user has no flag to change that. The right fix is to bake the
    // grant set into the binary at build time, where the app author declares it
    // and the user cannot weaken it -- an `oam build` feature, not an argv
    // parse. Until that exists, do not describe embedded binaries as
    // sandboxable.
    drain_loader_warnings_on_hard_exit(false);
    let mut rt = oam_engine::JsRuntime::new();
    // Seed embedded bytecode (v2 binaries) now that V8 is initialized, so the
    // CJS loader consumes it without needing a writable cache dir. Keyed by the
    // embedded source -- the same string the loader keys on after writing it to
    // the temp file below.
    if let Some(blob) = bytecode {
        oam_engine::seed_cjs_bytecode(source, blob);
    }
    // The app's argv is its own, so the one node option a compiled binary
    // honours, --trace-uncaught, comes from NODE_OPTIONS -- the form a
    // primitive's fatal report has a user reach for (its hint names the
    // flag). Nothing else in NODE_OPTIONS is applied here.
    let mut env_flags = NodeFlags::default();
    apply_node_options_env(&mut env_flags);
    if env_flags.trace_uncaught {
        let _ = rt.execute_script(
            "<flags>",
            &define_flag_global("__oamTraceUncaught", "true".into()),
        );
        rt.sync_trace_uncaught();
    }
    let exe = std::env::current_exe()
        .map(|p| p.to_string_lossy().into_owned())
        .unwrap_or_else(|_| "oam-compiled".to_string());

    if let Some((addr, brk)) = inspect {
        match rt.attach_inspector(addr, brk) {
            Ok(url) => {
                eprintln!("Debugger listening on {url}");
                eprintln!("For help, see: https://oamjs.org/docs/inspector");
            }
            Err(e) => {
                eprintln!("could not start inspector: {e}");
                return ExitCode::FAILURE;
            }
        }
    }

    // Write the embedded source to a temp file so the CJS loader has a
    // real path for __filename / __dirname / require() resolution.
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_nanos();
    let tmp_dir = std::env::temp_dir().join(format!("oam-embed-{}-{nanos}", std::process::id()));
    own_files::create_dir_all(&tmp_dir, Audience::Scratch)
        .expect("create temp dir for embedded source");
    let tmp_file = tmp_dir.join("__oam_embedded.js");
    own_files::write(&tmp_file, source, Audience::Scratch).expect("write embedded source to temp");

    // Node convention: argv[0]=binary, argv[1]=script path. argv[1] is the
    // temp file spelled the way the loader spells __filename (module_key:
    // canonical, 8.3 short names and symlinks resolved), so the usual
    // main-module check -- `process.argv[1] === __filename`, or
    // import.meta.url against pathToFileURL(argv[1]) -- holds even on a
    // short-name TEMP (`C:\Users\RUNNER~1\...`) or a symlinked /tmp, where
    // the raw temp_dir() spelling and the canonical one differ.
    let script = oam_engine::module_key(&tmp_file).unwrap_or_else(|_| tmp_file.clone());
    let mut argv = vec![exe, script.to_string_lossy().into_owned()];
    argv.extend(script_args);
    rt.set_process_argv(argv);

    let result = rt.execute_cjs(&tmp_file, &CliHost);
    let _ = std::fs::remove_dir_all(&tmp_dir);
    report_loader_warnings(false);
    // Same fatal-path shape as run_file: sub-codes 6/7 skip the 'exit'
    // event entirely and are not handler-overridable; a regular fatal
    // forces exitCode = 1, emits 'exit', then honors handler mutations.
    match result {
        Ok(()) => {
            rt.emit_process_exit();
            ExitCode::from(rt.process_exit_code().unwrap_or(0).clamp(0, 255) as u8)
        }
        Err(diagnostics) => {
            let sub_code = rt
                .execute_script_draining(
                    "<fatal-sub-code>",
                    "String((globalThis.process && globalThis.process.__oamFatalCode) || '')",
                    oam_engine::AfterScript::Nothing,
                )
                .ok()
                .and_then(|s| s.parse::<u8>().ok());
            if let Some(code) = sub_code {
                // Skips `emit_process_exit` -- see the run_file site above.
                oam_engine::run_exit_hooks();
                for d in &diagnostics {
                    render(d, false);
                }
                return ExitCode::from(code);
            }
            let (exit_code_script, after_exit) = fatal_exit_shape(&diagnostics);
            let _ = rt.execute_script_draining(
                "<fatal-exit-code>",
                exit_code_script,
                oam_engine::AfterScript::Nothing,
            );
            // node runs the 'exit' listeners, then prints the report
            // (TriggerUncaughtException: _fatalException, then
            // ReportFatalException), as run_file's caller does (#399 item 10).
            rt.emit_process_exit_after(after_exit);
            for d in &diagnostics {
                render(d, false);
            }
            ExitCode::from(rt.process_exit_code().unwrap_or(1).clamp(0, 255) as u8)
        }
    }
}

/// One-line remedy appended to every "this entry cannot be embedded" error.
const COMPILE_ENTRY_HINT: &str = "oam compile embeds a pre-bundled CommonJS file as-is and does \
                                  not transpile or bundle; bundle to CJS first (e.g. esbuild \
                                  --bundle --format=cjs --platform=node) and compile the output.";

/// Whether `carrier` is the running binary, however it is spelled (a relative
/// `./oam`, a symlink, an 8.3 short name). Canonicalize both sides; if either
/// side cannot be resolved, answer false -- the conservative outcome is a
/// JS-only payload, which never yields a binary that rejects its own bytecode.
fn carrier_is_running_binary(carrier: &Path) -> bool {
    let Ok(me) = std::env::current_exe().and_then(std::fs::canonicalize) else {
        return false;
    };
    std::fs::canonicalize(carrier).is_ok_and(|c| c == me)
}

/// `oam compile <entry> --output <path>`: read the JS source, produce its V8
/// bytecode, copy the carrier binary, and append the payload with a magic
/// trailer.
fn compile_command(entry: &Path, output: &Path, carrier: Option<&Path>) -> ExitCode {
    // 0. Refuse an entry that is not plain JavaScript. The embedded program
    //    runs through the CJS loader as-is (no transpile, no bundling), so a
    //    .ts/.tsx/.jsx entry would read fine here and die with a SyntaxError
    //    on the binary's first run -- possibly on a machine the author never
    //    runs it on (--carrier).
    if oam_loader::classify(entry) != SourceKind::JavaScript {
        eprintln!(
            "oam compile: {} is not plain JavaScript. {COMPILE_ENTRY_HINT}",
            entry.display()
        );
        return ExitCode::FAILURE;
    }

    // 1. Read the entry JS file.
    let source = match std::fs::read(entry) {
        Ok(bytes) => bytes,
        Err(e) => {
            eprintln!("oam compile: could not read {}: {e}", entry.display());
            return ExitCode::FAILURE;
        }
    };

    // Validate it's UTF-8 (JS source must be).
    if std::str::from_utf8(&source).is_err() {
        eprintln!(
            "oam compile: {} is not valid UTF-8 (expected a JS source file)",
            entry.display()
        );
        return ExitCode::FAILURE;
    }

    // 2. Resolve the carrier binary. Defaults to the running oam; `--carrier`
    //    points at a different one so a release binary for another OS/arch
    //    can be used, which is what makes cross-compiling possible. The JS
    //    half of the payload appended below is platform-independent -- only
    //    the carrier decides the output's platform. The bytecode half is NOT:
    //    it is bound to the V8 build that produced it, i.e. to this binary
    //    (step 3 embeds it only when the carrier is this binary).
    let exe = match carrier {
        Some(p) => {
            if !p.is_file() {
                eprintln!("oam compile: carrier {} is not a file", p.display());
                return ExitCode::FAILURE;
            }
            // Refuse a carrier that already carries a payload. Compiling onto
            // a previous compile output would nest payloads, and the loader
            // reads the LAST magic footer -- so it would silently run the
            // older embedded program instead of this one.
            //
            // Read only the trailing 8 bytes. A carrier is a whole oam binary
            // (~64 MB); slurping it to inspect a footer would allocate the
            // entire file for an 8-byte check. Mirrors extract_embedded above.
            match file_ends_with_compile_magic(p) {
                Ok(true) => {
                    eprintln!(
                        "oam compile: carrier {} is already a compiled output (it ends with the \
                         payload magic). Pass a plain oam binary.",
                        p.display()
                    );
                    return ExitCode::FAILURE;
                }
                Ok(false) => {}
                Err(e) => {
                    eprintln!("oam compile: could not read carrier {}: {e}", p.display());
                    return ExitCode::FAILURE;
                }
            }
            p.to_path_buf()
        }
        None => match std::env::current_exe() {
            Ok(p) => p,
            Err(e) => {
                eprintln!("oam compile: could not locate own executable: {e}");
                return ExitCode::FAILURE;
            }
        },
    };
    // Same file spelled two ways (`--carrier ./oam` from the install dir) is
    // still self. Anything else -- another version, another platform -- gets
    // a JS-only payload: V8 checks version, flag hash and read-only snapshot
    // on consume, so a blob from this V8 would be rejected on every run of
    // the output and cost a recompile plus a cache write each time.
    let carrier_is_self = carrier.is_none_or(carrier_is_running_binary);

    // 3. Produce V8 bytecode for the entry so the compiled binary's first run
    //    skips parse+compile (v2). Before the carrier copy, so a bad entry
    //    fails here without leaving a half-written output. Three outcomes: a
    //    blob (v2); V8 declining to produce a cache (JS-only v1 -- the lazy
    //    runtime cache still kicks in there); or a source that does not
    //    compile as CommonJS at all (a SyntaxError, an ESM import/export,
    //    TypeScript syntax) -- a hard failure carrying V8's message, since the
    //    binary would only die with that same error on its first run.
    let source_str = std::str::from_utf8(&source).expect("UTF-8 validated above");
    // The compile-check runs UNCONDITIONALLY: syntax validity is
    // carrier-independent, and a broken entry behind --carrier used to exit 0
    // and hand the author a binary that dies with that same SyntaxError on
    // its first run -- possibly on a machine the author never touches. Only
    // the BLOB is carrier-bound (V8 bytecode is tied to the producing build),
    // so a foreign carrier discards it and gets the JS-only (v1) payload.
    let blob = match oam_engine::JsRuntime::precompile_cjs_source(
        &entry.display().to_string(),
        source_str,
    ) {
        Ok(blob) => blob,
        Err(message) => {
            eprintln!("oam compile: {message}");
            eprintln!("oam compile: the entry must compile as CommonJS. {COMPILE_ENTRY_HINT}");
            return ExitCode::FAILURE;
        }
    };
    let bytecode = if carrier_is_self {
        blob
    } else {
        eprintln!(
            "oam compile: --carrier is not the running binary; embedding JS only (V8 bytecode \
             is bound to the compiling binary, so the output builds its own cache on first run)"
        );
        None
    };

    // 4. Copy the carrier to the output path.
    if let Some(parent) = output.parent()
        && !parent.as_os_str().is_empty()
        && let Err(e) = std::fs::create_dir_all(parent)
    {
        eprintln!(
            "oam compile: could not create output directory {}: {e}",
            parent.display()
        );
        return ExitCode::FAILURE;
    }
    if let Err(e) = std::fs::copy(&exe, output) {
        eprintln!(
            "oam compile: could not copy binary to {}: {e}",
            output.display()
        );
        return ExitCode::FAILURE;
    }

    // 5. Append. v2: [JS][bytecode][u64 LE js len][u64 LE bc len][magic
    //    "OAMEXC2\0"]; v1: [JS][u64 LE js len][magic "OAMEXEC\0"].
    let mut out_file = match std::fs::OpenOptions::new().append(true).open(output) {
        Ok(f) => f,
        Err(e) => {
            eprintln!(
                "oam compile: could not open {} for append: {e}",
                output.display()
            );
            return ExitCode::FAILURE;
        }
    };
    use std::io::Write;

    let js_len = source.len() as u64;
    let write_result = match &bytecode {
        Some(bc) => out_file
            .write_all(&source)
            .and_then(|()| out_file.write_all(bc))
            .and_then(|()| out_file.write_all(&js_len.to_le_bytes()))
            .and_then(|()| out_file.write_all(&(bc.len() as u64).to_le_bytes()))
            .and_then(|()| out_file.write_all(COMPILE_MAGIC_V2)),
        None => out_file
            .write_all(&source)
            .and_then(|()| out_file.write_all(&js_len.to_le_bytes()))
            .and_then(|()| out_file.write_all(COMPILE_MAGIC)),
    };
    if let Err(e) = write_result {
        eprintln!("oam compile: write failed: {e}");
        let _ = std::fs::remove_file(output);
        return ExitCode::FAILURE;
    }

    let out_abs = std::path::absolute(output).unwrap_or_else(|_| output.to_path_buf());
    match &bytecode {
        Some(bc) => eprintln!(
            "oam compile: {} ({} bytes JS + {} bytes bytecode) -> {}",
            entry.display(),
            source.len(),
            bc.len(),
            out_abs.display()
        ),
        None => eprintln!(
            "oam compile: {} ({} bytes JS, no bytecode embedded) -> {}",
            entry.display(),
            source.len(),
            out_abs.display()
        ),
    }
    // The output embeds the whole oam runtime -- V8 (BSD-3), ICU (Unicode),
    // the Node streams port (MIT) and ~380 Rust crates. Whoever ships that
    // binary inherits their notice obligations, and would have no way to know
    // it from a success line that only reports byte counts.
    eprintln!(
        "oam compile: the output embeds oam's runtime (V8, ICU and others); if you \
         redistribute it, ship the notices from LICENSE, NOTICE and \
         THIRD_PARTY_LICENSES.md with it"
    );
    ExitCode::SUCCESS
}

/// `oam cache info|clean`: inspect or delete the V8 bytecode cache. The cache
/// is a pure optimization, so `clean` is safe at any time -- the next run
/// recompiles and repopulates it. `info` reports the directory this process
/// would use (`NODE_COMPILE_CACHE`'s per-build subdirectory wins, then
/// `OAM_CACHE_DIR`, then the platform cache dir), the number
/// of blobs and their total size; `--json` emits the same as one object.
fn cache_command(action: &CacheAction, json: bool) -> ExitCode {
    match action {
        CacheAction::Info => {
            let stats = oam_engine::code_cache_stats();
            if json {
                println!(
                    "{}",
                    serde_json::json!({
                        "path": stats.path.to_string_lossy(),
                        "entries": stats.entries,
                        "bytes": stats.bytes,
                    })
                );
            } else {
                println!("path:    {}", stats.path.display());
                println!("entries: {}", stats.entries);
                println!("bytes:   {}", stats.bytes);
            }
            ExitCode::SUCCESS
        }
        CacheAction::Clean => {
            let path = oam_engine::code_cache_dir();
            match oam_engine::code_cache_clean() {
                Ok(()) => {
                    if json {
                        println!(
                            "{}",
                            serde_json::json!({ "removed": path.to_string_lossy() })
                        );
                    } else {
                        eprintln!("oam cache: removed {}", path.display());
                    }
                    ExitCode::SUCCESS
                }
                Err(e) => {
                    eprintln!("oam cache: could not remove {}: {e}", path.display());
                    ExitCode::FAILURE
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::resolve_inspect;

    #[test]
    fn inspect_bare_port_binds_127_0_0_1() {
        let (addr, brk) = resolve_inspect(Some("9229"), None).unwrap().unwrap();
        assert_eq!(addr.to_string(), "127.0.0.1:9229");
        assert!(!brk);
    }

    #[test]
    fn inspect_host_port_pair_is_honored() {
        let (addr, brk) = resolve_inspect(Some("0.0.0.0:7000"), None)
            .unwrap()
            .unwrap();
        assert_eq!(addr.to_string(), "0.0.0.0:7000");
        assert!(!brk);
    }

    #[test]
    fn inspect_brk_wins_over_inspect() {
        let (_, brk) = resolve_inspect(Some("9229"), Some("9230"))
            .unwrap()
            .unwrap();
        assert!(brk);
    }

    #[test]
    fn inspect_ipv6_bracketed_host_port_parses() {
        // [::1]:9229 must NOT trip the bare-port heuristic. The whole string
        // is a valid SocketAddr literal; pass-through must succeed.
        let (addr, _) = resolve_inspect(Some("[::1]:9229"), None).unwrap().unwrap();
        assert_eq!(addr.to_string(), "[::1]:9229");
    }

    #[test]
    fn inspect_bare_ipv6_host_fails_with_with_host_in_message() {
        // A bare IPv6 address (no port) is a user error. The error message
        // must surface what was actually parsed -- previously the message
        // echoed the raw input, hiding that ':' triggered the host branch.
        let err = resolve_inspect(Some("::1"), None).unwrap_err();
        assert!(err.contains("::1"), "err: {err}");
        assert!(err.contains("[host:]port"), "err: {err}");
    }

    #[test]
    fn inspect_neither_flag_returns_none() {
        assert!(resolve_inspect(None, None).unwrap().is_none());
    }

    #[test]
    fn compile_magic_is_8_bytes() {
        assert_eq!(super::COMPILE_MAGIC.len(), 8);
        assert_eq!(super::COMPILE_MAGIC, b"OAMEXEC\0");
        assert_eq!(super::COMPILE_MAGIC_V2.len(), 8);
        assert_eq!(super::COMPILE_MAGIC_V2, b"OAMEXC2\0");
    }

    // --- `--carrier` guard ------------------------------------------------

    #[test]
    fn ends_with_compile_magic_detects_both_trailer_versions() {
        let mut v1 = b"a plain binary".to_vec();
        v1.extend_from_slice(super::COMPILE_MAGIC);
        assert!(super::ends_with_compile_magic(&v1));

        let mut v2 = b"a plain binary".to_vec();
        v2.extend_from_slice(super::COMPILE_MAGIC_V2);
        assert!(super::ends_with_compile_magic(&v2));
    }

    #[test]
    fn file_magic_check_reads_only_the_tail() {
        let dir = std::env::temp_dir().join(format!("oam-carrier-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();

        let plain = dir.join("plain.bin");
        std::fs::write(&plain, vec![0u8; 4096]).unwrap();
        assert!(!super::file_ends_with_compile_magic(&plain).unwrap());

        let compiled = dir.join("compiled.bin");
        let mut bytes = vec![0u8; 4096];
        bytes.extend_from_slice(super::COMPILE_MAGIC_V2);
        std::fs::write(&compiled, bytes).unwrap();
        assert!(super::file_ends_with_compile_magic(&compiled).unwrap());

        // Shorter than the magic must not error or panic on the seek.
        let tiny = dir.join("tiny.bin");
        std::fs::write(&tiny, b"abc").unwrap();
        assert!(!super::file_ends_with_compile_magic(&tiny).unwrap());

        // A missing carrier surfaces as Err, not a false negative.
        assert!(super::file_ends_with_compile_magic(&dir.join("nope.bin")).is_err());

        std::fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn space_form_hint_fires_only_on_a_nonexistent_non_flag() {
        // The space form a Deno user would reach for.
        assert!(
            super::space_form_hint("--allow-net", Some(&"127.0.0.1:5432".to_string())).is_some()
        );
        assert!(super::space_form_hint("--allow-env", Some(&"DATABASE_URL".to_string())).is_some());

        // A real script path is the legitimate next token -- must not fire.
        let script = std::env::temp_dir().join(format!("oam-sfh-{}.mjs", std::process::id()));
        std::fs::write(&script, "").unwrap();
        let as_str = script.to_string_lossy().to_string();
        assert!(super::space_form_hint("--allow-net", Some(&as_str)).is_none());
        std::fs::remove_file(&script).ok();

        // Another flag, or nothing at all, is fine.
        assert!(super::space_form_hint("--allow-net", Some(&"--permission".to_string())).is_none());
        assert!(super::space_form_hint("--allow-net", None).is_none());

        // EVERY subcommand is a legitimate token after a bare grant. Asserting
        // the whole list, not a sample, so adding a subcommand without
        // updating this cannot silently start rejecting it.
        for sub in super::SUBCOMMANDS {
            assert!(
                super::space_form_hint("--allow-env", Some(&sub.to_string())).is_none(),
                "`--allow-env {sub}` must dispatch to the subcommand, not be read as a grant list"
            );
        }
    }

    /// SUBCOMMANDS and clap must not drift: the `cache` subcommand shipped
    /// without a list entry, so `oam ... cache` could dispatch a cwd FILE
    /// named `cache` and `oam --allow-env cache info` died with a bogus
    /// space-form hint. Bidirectional: every clap subcommand is listed, and
    /// every listed name (minus clap's auto `help`) is a real subcommand.
    #[test]
    fn subcommands_const_matches_clap_exactly() {
        use clap::CommandFactory;
        let cmd = super::Cli::command();
        let clap_names: Vec<String> = cmd
            .get_subcommands()
            .map(|c| c.get_name().to_string())
            .collect();
        for name in &clap_names {
            assert!(
                super::SUBCOMMANDS.contains(&name.as_str()),
                "clap subcommand '{name}' is missing from SUBCOMMANDS: the \
                 bare-script dispatch and space_form_hint would mis-handle it"
            );
        }
        for name in super::SUBCOMMANDS {
            assert!(
                *name == "help" || clap_names.iter().any(|c| c == name),
                "SUBCOMMANDS entry '{name}' is not a clap subcommand"
            );
        }
    }

    #[test]
    fn ends_with_compile_magic_rejects_plain_and_short_input() {
        assert!(!super::ends_with_compile_magic(b"not a compile output"));
        // The magic must be at the END, not merely present.
        let mut leading = super::COMPILE_MAGIC.to_vec();
        leading.extend_from_slice(b"trailing bytes");
        assert!(!super::ends_with_compile_magic(&leading));
        // Shorter than the magic: must not panic on the subtraction.
        assert!(!super::ends_with_compile_magic(b""));
        assert!(!super::ends_with_compile_magic(b"abc"));
    }

    // --- `--allow-net` / `--allow-env` ------------------------------------

    fn perms_for(flags: &super::NodeFlags) -> oam_engine::PermissionsOptions {
        flags.permissions().expect("--permission was set")
    }

    fn is_denied(g: &oam_engine::BoolOrList) -> bool {
        matches!(g, oam_engine::BoolOrList::Bool(false))
    }

    #[test]
    fn permission_without_net_or_env_grants_denies_both() {
        // The pre-existing posture, now reachable only when the grants are
        // actually absent rather than hardcoded.
        let flags = super::NodeFlags {
            permission: true,
            ..Default::default()
        };
        let p = perms_for(&flags);
        assert!(is_denied(&p.net));
        assert!(is_denied(&p.env));
    }

    #[test]
    fn node_options_carries_the_permission_flags_a_child_inherits() {
        // What a parent under `--permission` appends to a child's
        // NODE_OPTIONS (process.execArgv's permission flags, space-joined,
        // as node's copyPermissionModelFlagsToEnv writes them) puts the
        // child under the same permission set.
        let raw = [
            "--max-http-header-size=100",
            "--permission",
            "--allow-fs-read=C:/a,C:/b",
            "--allow-fs-write=*",
            "--allow-net",
            "--allow-env=HOME",
            "--allow-child-process",
            "--allow-worker",
        ]
        .join(" ");
        let mut flags = super::NodeFlags::default();
        assert!(super::apply_node_options(&mut flags, &raw));
        assert!(flags.permission);
        assert_eq!(flags.allow_fs_read, ["C:/a,C:/b"]);
        assert_eq!(flags.allow_fs_write, ["*"]);
        assert_eq!(flags.allow_net, ["*"]);
        assert_eq!(flags.allow_env, ["HOME"]);
        assert!(flags.allow_child_process && flags.allow_worker);
        let p = perms_for(&flags);
        assert!(matches!(p.write, oam_engine::BoolOrList::Bool(true)));
        assert!(matches!(p.child, oam_engine::BoolOrList::Bool(true)));
        // Without them, NODE_OPTIONS leaves the permission model off.
        let mut plain = super::NodeFlags::default();
        super::apply_node_options(&mut plain, "--no-warnings");
        assert!(plain.permissions().is_none());
        // And a bare `--permission` grants nothing.
        let mut bare = super::NodeFlags::default();
        super::apply_node_options(&mut bare, "--permission");
        let p = perms_for(&bare);
        assert!(is_denied(&p.read) && is_denied(&p.write) && is_denied(&p.child));
    }

    /// The entries a list grant holds, or a panic naming what it was.
    fn listed(grant: &oam_engine::BoolOrList) -> Vec<String> {
        match grant {
            oam_engine::BoolOrList::List(v) => v.clone(),
            other => panic!("expected a list grant, got {other:?}"),
        }
    }

    #[test]
    fn a_repeated_list_flag_adds_its_entries_to_the_earlier_ones() {
        // node v22.22.2: `--allow-fs-write=A --allow-fs-write=B` admits
        // writes under A and under B (#363). oam kept only B. The same holds
        // for every list-valued permission flag, oam's own two included.
        let raw = [
            "--permission",
            "--allow-fs-read=/r1",
            "--allow-fs-read=/r2",
            "--allow-fs-write=/w1",
            "--allow-fs-write=/w2",
            "--allow-fs-write=/w3",
            "--allow-net=a.test",
            "--allow-net=b.test:80",
            "--allow-env=ONE",
            "--allow-env=TWO",
        ]
        .join(" ");
        let mut flags = super::NodeFlags::default();
        assert!(super::apply_node_options(&mut flags, &raw));
        let p = perms_for(&flags);
        assert_eq!(listed(&p.read), ["/r1", "/r2"]);
        assert_eq!(listed(&p.write), ["/w1", "/w2", "/w3"]);
        assert_eq!(listed(&p.net), ["a.test", "b.test:80"]);
        assert_eq!(listed(&p.env), ["ONE", "TWO"]);
        // A `*` among them grants everything, as node's does.
        let mut star = super::NodeFlags::default();
        super::apply_node_options(
            &mut star,
            "--permission --allow-fs-read=/r1 --allow-fs-read=* --allow-net=a.test --allow-net",
        );
        let p = perms_for(&star);
        assert!(matches!(p.read, oam_engine::BoolOrList::Bool(true)));
        assert!(matches!(p.net, oam_engine::BoolOrList::Bool(true)));
    }

    #[test]
    fn node_options_grants_add_to_argvs_and_exec_argv_lists_every_occurrence() {
        // node applies NODE_OPTIONS and then argv, and a list flag in both
        // grants both; process.execArgv holds argv's occurrences, each as it
        // was given, which is what a child under `--permission` inherits.
        let mut env = super::NodeFlags::default();
        super::apply_node_options(&mut env, "--allow-fs-write=/env --allow-env=E");
        let mut argv = super::NodeFlags::default();
        super::apply_node_options(
            &mut argv,
            "--permission --allow-fs-write=/a --allow-fs-write=/b --allow-env=A",
        );
        let merged = env.merged(argv);
        let p = perms_for(&merged);
        assert_eq!(listed(&p.write), ["/env", "/a", "/b"]);
        assert_eq!(listed(&p.env), ["E", "A"]);
        assert_eq!(
            merged.exec_argv(),
            [
                "--permission",
                "--allow-fs-write=/a",
                "--allow-fs-write=/b",
                "--allow-env=A",
            ]
        );
    }

    #[test]
    fn bare_allow_net_and_allow_env_grant_everything() {
        let flags = super::NodeFlags {
            permission: true,
            allow_net: vec!["*".into()],
            allow_env: vec!["*".into()],
            ..Default::default()
        };
        let p = perms_for(&flags);
        assert!(matches!(p.net, oam_engine::BoolOrList::Bool(true)));
        assert!(matches!(p.env, oam_engine::BoolOrList::Bool(true)));
    }

    #[test]
    fn list_form_grants_only_the_listed_entries() {
        let flags = super::NodeFlags {
            permission: true,
            allow_net: vec!["127.0.0.1:5432, example.com".into()],
            allow_env: vec!["DATABASE_URL".into()],
            ..Default::default()
        };
        let p = perms_for(&flags);
        match p.net {
            // Whitespace around list entries is trimmed, so a human-spaced
            // list behaves the same as a tight one.
            oam_engine::BoolOrList::List(ref v) => {
                assert_eq!(
                    v,
                    &["127.0.0.1:5432".to_string(), "example.com".to_string()]
                );
            }
            _ => panic!("expected a list grant, got {:?}", p.net),
        }
        match p.env {
            oam_engine::BoolOrList::List(ref v) => assert_eq!(v, &["DATABASE_URL".to_string()]),
            _ => panic!("expected a list grant, got {:?}", p.env),
        }
    }

    #[test]
    fn grants_are_inert_without_permission() {
        // Node's grants only mean anything under --permission; asking for one
        // without it must not silently enable the restrictive mode.
        let flags = super::NodeFlags {
            permission: false,
            allow_net: vec!["*".into()],
            ..Default::default()
        };
        assert!(flags.permissions().is_none());
    }

    #[test]
    fn exec_argv_round_trips_bare_and_list_forms() {
        // A script re-spawning itself from process.execArgv must get back what
        // it was given -- bare stays bare, a list stays a list.
        let bare = super::NodeFlags {
            permission: true,
            allow_net: vec!["*".into()],
            allow_env: vec!["*".into()],
            ..Default::default()
        };
        let argv = bare.exec_argv();
        assert!(argv.contains(&"--allow-net".to_string()));
        assert!(argv.contains(&"--allow-env".to_string()));
        assert!(!argv.iter().any(|a| a.contains("=*")));

        let listed = super::NodeFlags {
            permission: true,
            allow_net: vec!["a,b".into()],
            ..Default::default()
        };
        assert!(listed.exec_argv().contains(&"--allow-net=a,b".to_string()));
    }

    #[test]
    fn tls_default_versions_follow_nodes_precedence() {
        let none = super::NodeFlags::default();
        assert_eq!(none.tls_default_versions(), (None, None));
        // lib/tls.js checks v1.0, v1.1, v1.2, v1.3 in that order for the
        // minimum, and v1.3 before v1.2 for the maximum (measured on
        // v22.22.2: `--tls-min-v1.3 --tls-min-v1.0` is TLSv1 and
        // `--tls-max-v1.2 --tls-max-v1.3` is TLSv1.3, from argv and
        // NODE_OPTIONS alike, whichever came first).
        let several = super::NodeFlags {
            tls_min_v1_0: true,
            tls_min_v1_3: true,
            tls_max_v1_2: true,
            tls_max_v1_3: true,
            ..Default::default()
        };
        assert_eq!(
            several.tls_default_versions(),
            (Some("TLSv1"), Some("TLSv1.3"))
        );
        let one_each = super::NodeFlags {
            tls_min_v1_3: true,
            tls_max_v1_2: true,
            ..Default::default()
        };
        assert_eq!(
            one_each.tls_default_versions(),
            (Some("TLSv1.3"), Some("TLSv1.2"))
        );
        let middle = super::NodeFlags {
            tls_min_v1_1: true,
            tls_min_v1_2: true,
            ..Default::default()
        };
        assert_eq!(middle.tls_default_versions(), (Some("TLSv1.1"), None));
        // Every flag given comes back through execArgv, as node hands them
        // back, and none that was not.
        let argv = several.exec_argv();
        for flag in [
            "--tls-min-v1.0",
            "--tls-min-v1.3",
            "--tls-max-v1.2",
            "--tls-max-v1.3",
        ] {
            assert!(argv.contains(&flag.to_string()), "{argv:?}");
        }
        assert!(
            !argv
                .iter()
                .any(|a| a == "--tls-min-v1.1" || a == "--tls-min-v1.2"),
            "{argv:?}"
        );
        assert!(none.exec_argv().iter().all(|a| !a.starts_with("--tls-")));
    }

    #[test]
    fn merged_folds_node_options_under_argv_and_reflects_argv_alone() {
        let env = super::NodeFlags {
            no_warnings: true,
            tls_max_v1_2: true,
            max_http_header_size: Some("1000".into()),
            max_http_header_size_spaced: true,
            title: Some("from-env".into()),
            disabled_warnings: vec!["EnvWarning".into()],
            env_files: vec![("env.env".into(), true)],
            ..Default::default()
        };
        let argv = super::NodeFlags {
            expose_gc: true,
            tls_max_v1_3: true,
            max_http_header_size: Some("2000".into()),
            max_http_header_size_spaced: false,
            disabled_warnings: vec!["ArgvWarning".into()],
            env_files: vec![("argv.env".into(), false)],
            ..Default::default()
        };
        let merged = env.merged(argv);
        // Toggles from either source are on; a value argv gave wins as a
        // pair; a value only the environment gave stands; lists apply the
        // environment's entries first.
        assert!(merged.no_warnings && merged.expose_gc);
        assert!(merged.tls_max_v1_2 && merged.tls_max_v1_3);
        assert_eq!(merged.max_http_header_size.as_deref(), Some("2000"));
        assert!(!merged.max_http_header_size_spaced);
        assert_eq!(merged.title.as_deref(), Some("from-env"));
        assert_eq!(merged.disabled_warnings, vec!["EnvWarning", "ArgvWarning"]);
        assert_eq!(
            merged.env_files,
            vec![
                ("env.env".to_string(), true),
                ("argv.env".to_string(), false)
            ]
        );
        // execArgv is argv's alone: node never lists NODE_OPTIONS there.
        let reflected = merged.exec_argv();
        assert_eq!(
            reflected,
            vec![
                "--expose-gc",
                "--disable-warning=ArgvWarning",
                "--max-http-header-size=2000",
                "--tls-max-v1.3",
            ]
        );
        // An environment-only set reflects nothing; argv-only, everything.
        let env_only = super::NodeFlags {
            no_warnings: true,
            ..Default::default()
        }
        .merged(super::NodeFlags::default());
        assert!(env_only.no_warnings);
        assert!(env_only.exec_argv().is_empty());
        let argv_only = super::NodeFlags::default().merged(super::NodeFlags {
            no_warnings: true,
            ..Default::default()
        });
        assert_eq!(argv_only.exec_argv(), vec!["--no-warnings"]);
    }

    #[test]
    fn trace_flags_come_from_node_options_and_argv_and_only_argv_reflects_them() {
        // NODE_OPTIONS carries --trace-warnings / --trace-deprecation, as
        // node's does (#364).
        let mut env = super::NodeFlags::default();
        assert!(super::apply_node_options(&mut env, "--trace-deprecation"));
        assert!(env.trace_deprecation && !env.trace_warnings);
        let mut both = super::NodeFlags::default();
        assert!(super::apply_node_options(
            &mut both,
            "--trace-warnings --trace-deprecation"
        ));
        assert!(both.trace_warnings && both.trace_deprecation);
        // Merged under argv's: either source turns a flag on, and execArgv
        // lists argv's alone.
        let merged = env.merged(super::NodeFlags {
            trace_warnings: true,
            ..Default::default()
        });
        assert!(merged.trace_warnings && merged.trace_deprecation);
        assert_eq!(merged.exec_argv(), vec!["--trace-warnings"]);
        let argv_both = super::NodeFlags::default().merged(super::NodeFlags {
            trace_warnings: true,
            trace_deprecation: true,
            ..Default::default()
        });
        assert_eq!(
            argv_both.exec_argv(),
            vec!["--trace-warnings", "--trace-deprecation"]
        );
    }

    #[test]
    fn trace_uncaught_comes_from_node_options_and_argv_and_only_argv_reflects_it() {
        let mut env = super::NodeFlags::default();
        assert!(super::apply_node_options(&mut env, "--trace-uncaught"));
        assert!(env.trace_uncaught);
        assert!(env.environment_js(false).contains("__oamTraceUncaught"));
        // NODE_OPTIONS turns it on but is not execArgv; argv's is.
        let merged = env.merged(super::NodeFlags::default());
        assert!(merged.trace_uncaught);
        assert!(merged.exec_argv().is_empty());
        let argv = super::NodeFlags::default().merged(super::NodeFlags {
            trace_uncaught: true,
            ..Default::default()
        });
        assert_eq!(argv.exec_argv(), vec!["--trace-uncaught"]);
        assert!(
            !super::NodeFlags::default()
                .environment_js(false)
                .contains("__oamTraceUncaught")
        );
    }

    #[test]
    fn node_options_takes_v8_pool_size_in_both_forms_and_ignores_an_empty_one() {
        // Pins the NODE_OPTIONS arms for --v8-pool-size, which mirror the
        // header-size ones: an empty `=` value is node's exit 9, but the
        // allowlist ignores the token instead (it must not read as a pool of
        // 0), and the spaced form takes the next token as the value.
        let mut flags = super::NodeFlags::default();
        assert!(super::apply_node_options(
            &mut flags,
            "--v8-pool-size= --v8-pool-size 2"
        ));
        assert_eq!(flags.v8_pool_size.as_deref(), Some("2"));
        // The `=` form alone sets it too.
        let mut eq = super::NodeFlags::default();
        assert!(super::apply_node_options(&mut eq, "--v8-pool-size=3"));
        assert_eq!(eq.v8_pool_size.as_deref(), Some("3"));
        // An empty `=` value alone leaves it unset, and the return value
        // reports that nothing changed rather than an error.
        let mut empty = super::NodeFlags::default();
        assert!(!super::apply_node_options(&mut empty, "--v8-pool-size="));
        assert_eq!(empty.v8_pool_size, None);
        // A trailing spaced form with no value is ignored the same way.
        let mut trailing = super::NodeFlags::default();
        assert!(!super::apply_node_options(&mut trailing, "--v8-pool-size"));
        assert_eq!(trailing.v8_pool_size, None);
    }

    #[test]
    fn merged_takes_argv_v8_pool_size_as_a_pair_and_reflects_it() {
        // Pins the merge arm for --v8-pool-size: argv's value wins together
        // with its spacing (the environment's spaced `1` does not leak its
        // `spaced` bit onto argv's `=2`), and execArgv hands argv's form
        // back so a fork child sizes its pool the same way.
        let env = super::NodeFlags {
            v8_pool_size: Some("1".into()),
            v8_pool_size_spaced: true,
            ..Default::default()
        };
        let argv = super::NodeFlags {
            v8_pool_size: Some("2".into()),
            v8_pool_size_spaced: false,
            ..Default::default()
        };
        let merged = env.merged(argv);
        assert_eq!(merged.v8_pool_size.as_deref(), Some("2"));
        assert!(!merged.v8_pool_size_spaced);
        assert_eq!(merged.exec_argv(), vec!["--v8-pool-size=2"]);
        // A value only the environment gave stands, pair intact, and is
        // not reflected: node never lists NODE_OPTIONS in execArgv.
        let env_only = super::NodeFlags {
            v8_pool_size: Some("1".into()),
            v8_pool_size_spaced: true,
            ..Default::default()
        }
        .merged(super::NodeFlags::default());
        assert_eq!(env_only.v8_pool_size.as_deref(), Some("1"));
        assert!(env_only.v8_pool_size_spaced);
        assert!(env_only.exec_argv().is_empty());
        // argv's spaced form is reflected as two tokens.
        let spaced = super::NodeFlags::default().merged(super::NodeFlags {
            v8_pool_size: Some("4".into()),
            v8_pool_size_spaced: true,
            ..Default::default()
        });
        assert_eq!(spaced.exec_argv(), vec!["--v8-pool-size", "4"]);
    }

    #[test]
    fn a_worker_given_env_or_exec_argv_decides_its_own_flags() {
        // #370, node v22.22.2's Worker: given either, the worker starts from
        // the defaults, takes NODE_OPTIONS from the environment it is given,
        // then its execArgv; NODE_NO_WARNINGS is its own environment's.
        // (The main thread's inheriting path reads PARENT_OPTIONS,
        // process-global state conformance case 490 covers end to end.)
        let env = |pairs: &'static [(&'static str, &'static str)]| {
            move |name: &str| {
                pairs
                    .iter()
                    .find(|(key, _)| *key == name)
                    .map(|(_, value)| value.to_string())
            }
        };
        let args = |list: &[&str]| list.iter().map(|s| s.to_string()).collect::<Vec<_>>();
        let (none, _) = super::worker_flags_js(None, false, &[], &env(&[]));
        assert!(!none.contains("__oamNoWarnings"), "{none}");
        let (quiet, _) =
            super::worker_flags_js(None, false, &[], &env(&[("NODE_NO_WARNINGS", "1")]));
        assert!(quiet.contains("__oamNoWarnings"), "{quiet}");
        let (argv, _) = super::worker_flags_js(None, false, &args(&["--no-warnings"]), &env(&[]));
        assert!(argv.contains("__oamNoWarnings"), "{argv}");
        let (options, _) = super::worker_flags_js(
            None,
            false,
            &args(&["--tls-min-v1.3"]),
            &env(&[("NODE_OPTIONS", "--no-deprecation --tls-min-v1.0")]),
        );
        assert!(options.contains("__oamNoDeprecation"), "{options}");
        // Both minimums set: node's precedence takes the lowest.
        assert!(options.contains("\"TLSv1\""), "{options}");
        let (pending, _) =
            super::worker_flags_js(None, false, &[], &env(&[("NODE_PENDING_DEPRECATION", "1")]));
        assert!(pending.contains("__oamPendingDeprecation"), "{pending}");
        // --trace-require-module is per environment in node too: a worker's
        // own execArgv sets it, and one given execArgv: [] does not have it.
        let (traced, _) = super::worker_flags_js(
            None,
            false,
            &args(&["--trace-require-module=all"]),
            &env(&[]),
        );
        assert!(traced.contains("__oamTraceRequireModule"), "{traced}");
        assert!(!none.contains("__oamTraceRequireModule"), "{none}");
        // A worker that inherits takes its creator's resolved options: a
        // worker given `--no-warnings` creates one with no options, and that
        // one has no 'warning' listener either. Given an execArgv instead, it
        // starts from the defaults again.
        let (_, creator) =
            super::worker_flags_js(None, false, &args(&["--no-warnings"]), &env(&[]));
        let (inner, _) = super::worker_flags_js(Some(&creator), true, &[], &env(&[]));
        assert!(inner.contains("__oamNoWarnings"), "{inner}");
        let (fresh, _) = super::worker_flags_js(Some(&creator), false, &[], &env(&[]));
        assert!(!fresh.contains("__oamNoWarnings"), "{fresh}");
    }
}

/// Every all-granted runtime construction in this binary has to be something
/// somebody wrote down.
///
/// `--permission` is only as strong as its weakest entry point. `oam run` and
/// `oam -e` took a permission set from the start; `oam repl` and `oam test` did
/// not, and used the all-granted constructor instead. So
/// `oam --permission test suspect.test.js` accepted the flag, printed no
/// warning, and ran the file with full disk, network and spawn access. A flag
/// that is silently ignored is worse than one that does not exist, because it
/// is precisely what you reach for when you already suspect the code.
///
/// Permissions are fixed at construction -- the ops read an `Arc<Permissions>`
/// out of an isolate slot written by `new_inner` -- so this cannot be caught by
/// looking at what happens after the runtime exists. It has to be checked at
/// the call.
///
/// The engine-side sibling is `oam_engine`'s `permission_audit`, which holds
/// every `op_*` to the same rule. That one cannot see CLI entry points; this
/// one covers them.
#[cfg(test)]
mod runtime_construction_audit {
    const SRC: &str = include_str!("main.rs");

    /// How many call sites may build an all-granted runtime. Currently one:
    /// `run_embedded`, which runs before the node-flag pre-parse and forwards
    /// unrecognised argv straight to the embedded script.
    ///
    /// Raising this is a security decision, not a mechanical fix. An entry
    /// point that can reach `NODE_FLAGS` should construct with
    /// `flags.permissions()` rather than be added here.
    const ALLOWED_ALL_GRANTED: usize = 1;

    /// Entry points that must keep constructing WITH a permission set:
    /// `run`, `eval`, `repl`, `test`.
    const SANDBOX_CAPABLE_ENTRY_POINTS: usize = 4;

    // Built at runtime from pieces so this module's own source does not match
    // the scan it performs.
    fn all_granted_needle() -> String {
        format!("JsRuntime::{}", "new()")
    }
    fn declaration_marker() -> String {
        format!("ALL-GRANTED, {}", "deliberately")
    }
    fn permissioned_needle() -> String {
        format!("JsRuntime::{}", "new_with_permissions(")
    }

    #[test]
    fn every_all_granted_runtime_is_declared() {
        let needle = all_granted_needle();
        let marker = declaration_marker();
        let lines: Vec<&str> = SRC.lines().collect();
        let mut sites = 0usize;
        let mut undeclared = Vec::new();

        for (i, line) in lines.iter().enumerate() {
            if !line.contains(&needle) {
                continue;
            }
            sites += 1;
            // The justification has to sit directly above the call, not in some
            // other file a reader will not open.
            let from = i.saturating_sub(25);
            if !lines[from..i].iter().any(|l| l.contains(&marker)) {
                undeclared.push(i + 1);
            }
        }

        assert!(
            undeclared.is_empty(),
            "main.rs builds an all-granted runtime at line(s) {undeclared:?} with no \
             justification above the call.\nThat entry point ignores --permission: it \
             will accept the flag and run with full disk, network and spawn access.\n\
             Either construct it with `flags.permissions()` (see `test_command` / \
             `repl_command`), or, if it genuinely cannot take a permission set, write a \
             comment above the call containing `{marker}` explaining why and bump \
             ALLOWED_ALL_GRANTED.",
        );

        assert_eq!(
            sites, ALLOWED_ALL_GRANTED,
            "expected {ALLOWED_ALL_GRANTED} all-granted runtime construction(s) in \
             main.rs, found {sites}. A new one is a new way for --permission to be \
             silently ignored -- justify it at the call site and update this constant, \
             or give the entry point a permission set.",
        );
    }

    #[test]
    fn sandbox_capable_entry_points_still_take_permissions() {
        let found = SRC.matches(&permissioned_needle()).count();
        assert_eq!(
            found, SANDBOX_CAPABLE_ENTRY_POINTS,
            "expected {SANDBOX_CAPABLE_ENTRY_POINTS} entry points constructing with a \
             permission set (run, eval, repl, test), found {found}. If one was swapped \
             back to the all-granted constructor, --permission stops working for that \
             command with no other symptom.",
        );
    }
}
