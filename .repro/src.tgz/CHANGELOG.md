# Changelog

All notable changes to oam are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

Entries are derived from the commit history between release tags. Pure internal
churn — formatting passes, lockfile syncs, benchmark receipt refreshes — is
omitted. oam is pre-1.0: breaking changes can land in a minor release.

Version numbering is not contiguous: **0.9.3 and 0.9.5 were never tagged**, so a
gap between headings below is expected rather than a missing entry. Not every tag
is a published GitHub Release either — 0.9.2 through 0.10.1 were tagged without
one, so `install.sh`, which resolves the latest Release, never handed them out.

## [Unreleased]

## [0.19.1] - 2026-10-13

### Changed

- **A typeless `.js` file is CommonJS unless it has module syntax, as in node.** A `.js` file whose
  nearest `package.json` has no `"type"`, or that has none above it, ran as an ES module in oam
  (ESM-first). It is now decided by node v22.22.2's own test: an `import` or `export` statement,
  `import.meta` or a top-level `await` makes it an ES module, anything else is CommonJS. This holds
  for the entry, `import`, `import()`, `require()`, `createRequire`, a Worker's entry and files
  under `node_modules`. Like node, oam emits a `MODULE_TYPELESS_PACKAGE_JSON` warning, once per
  `package.json`, when the test makes a file an ES module. If you relied on ESM-first: a file that
  uses `import`/`export` needs nothing. Otherwise add `"type": "module"` to `package.json` or rename
  the file to `.mjs`, and do the same to drop the warning.

- **`oam run` no longer type-checks TypeScript by default; it runs it unchecked, as node does.**
  The default was `--check=warn`, which checks alongside the program and reports after it ends --
  so every run's exit waited for the checker, up to `OAM_CHECK_WAIT_MS` (10 s). A file with no
  `tsconfig.json` has no daemon and starts a fresh `tsgo` each run, so a short script exited 1-7 s
  after its last output. `--check=warn` and `--check=block` still check, as does `oam check`;
  `oam serve` no longer checks either. The bare form `oam x.ts` never checked.

### Added

- **`v8.getHeapSnapshot()` and `v8.writeHeapSnapshot()` take real heap snapshots, as node's do.**
  `getHeapSnapshot` was missing, so importing it was a link-time `SyntaxError`, and
  `writeHeapSnapshot` wrote nothing and returned `""`. Both now serialize V8's own snapshot, the
  `.heapsnapshot` JSON Chrome DevTools loads: a `HeapSnapshotStream` of Buffers, or a file named as
  node names it (`Heap.<date>.<time>.<pid>.<threadId>.<seq>.heapsnapshot`, one process-wide `seq`),
  in a worker too, with node's argument checks and errors. The `exposeInternals` and
  `exposeNumericValues` options are checked but not honoured, and `worker.getHeapSnapshot()` rejects
  rather than resolve an empty array; see docs/node-divergences.md.

- **node's compile-cache API, over oam's V8 bytecode cache.** `node:module` has
  `enableCompileCache`, `getCompileCacheDir`, `flushCompileCache` and
  `constants.compileCacheStatus`, with node v22.22.2's return shapes, statuses and messages;
  `module.enableCompileCache()` threw "is not a function", and importing any of the names failed at
  link time. `NODE_COMPILE_CACHE` and `enableCompileCache(dir)` move the cache into a per-build
  `oam-v<version>-<arch>-<V8 tag>` directory, and `NODE_DISABLE_COMPILE_CACHE` turns it off. The
  existing cache backs it for CommonJS and ES modules alike: entries keyed by content hash, V8
  version and flags and now oam's version, written atomically, and a corrupt or unwritable cache
  only costs a compile. `process.exit()` and `flushCompileCache()` now write the ES module entries
  still pending and the CommonJS modules whose body is still running. Each worker thread has its
  own API state, as in node. The cache stays on by default, unlike node's; see
  `docs/node-divergences.md`. Conformance cases 438-439.

### Added

- **`--trace-uncaught`, and the hint that names it.** oam refused the flag, and a fatal
  report of a thrown primitive (`throw 42`, `throw null`) ended at the value, without node's
  `(Use \`node --trace-uncaught ...\` to show where the exception was thrown)`. The flag is
  accepted on the command line, in `NODE_OPTIONS` and in a `Worker`'s `execArgv`, and lists
  in `process.execArgv` as node's does. Without it the hint follows a primitive's report,
  naming the program as node does (`oam`); with it every fatal report of an uncaught
  exception ends with `Thrown at:` and the stack V8 captured at the throw, in node's frame
  format. A binary built with `oam compile` honours it from `NODE_OPTIONS`, its arguments
  being the app's own. A primitive
  thrown from an ES module entry or a `queueMicrotask` callback is now printed as
  `String()` gives it (`a string`, not `'a string'`), as node prints it. Node's frame
  above those two still has no oam counterpart; see docs/node-divergences.md #54.
  Conformance case 573.

### Added

- **`require()` of an ES module, with node 22's semantics.** Every such `require()` threw
  `ERR_REQUIRE_ESM` while `process.features.require_module` said `true`. The graph now loads and
  evaluates synchronously inside the `require()`, sharing one module map with `import()` and
  running no ticks or promise jobs, for a `.mjs`, a `.js` under `"type": "module"` and a typeless
  `.js` with module syntax (in node_modules too). It returns the namespace, the facade that adds
  `__esModule: true` when there is a default export, or an export named `'module.exports'`. A
  graph with top-level await is `ERR_REQUIRE_ASYNC_MODULE` even once an `import()` has run it, a
  cycle is `ERR_REQUIRE_CYCLE_MODULE` in node's wordings, an unresolved import is
  `ERR_MODULE_NOT_FOUND`, and an evaluation error is rethrown as the same object on every
  `require()`. `--trace-require-module` gives node's once-per-process warning, silent by default.
  `require.cache` is now node's `Module._cache`, shared and live, ES modules included. A CommonJS
  dependency still runs before the ES modules ahead of it; see docs/node-divergences.md.

### Fixed

- **A bodyless HTTP/1 request the handler never reads ends the moment `request` returns, as node's
  does.** The request learned its body was over only from an async round trip to the engine, so a
  connection event that arrived first (a client that goes away after the response started,
  conformance case 272) destroyed the request first and oam emitted `req aborted` -- ahead of the
  socket's `'close'`, where node's parser had already run `on_message_complete` and emits nothing.
  The engine now reports a request that declares no body (content length 0, or no framing that
  says there is one) at dispatch, as it already did for an h2 `END_STREAM`, and JS completes the
  message as node's parser does as soon as the handler has returned. A handler that reads the
  request is untouched: its read drains before any connection event can be delivered. Measured on
  the linux builder: the racy exchange diverged 5/480 runs before and 0/480 after (node 0/960).

- **`fs.readdir` honours `encoding: "buffer"`, as node's does.** Each entry was returned as a
  string regardless of the option, so `Buffer.isBuffer(entry)` was false; with `{ encoding:
  "buffer" }` (and with `withFileTypes`) a name is now a `Buffer` of its raw UTF-8 bytes, as node
  returns. Every other encoding, and the default, are unchanged; `recursive: true` together with
  `"buffer"` throws node's `ERR_INVALID_ARG_TYPE` on a non-empty directory.
- **Buffer's string paths no longer encode into a temporary, and match node where they did not.**
  `Buffer.from(string)`, `buf.write`, `Buffer.byteLength` and `TextEncoder` encoded into a scratch
  array and copied it over; they now encode straight into the destination, and `byteLength` counts
  without encoding. `buf.toString()` decodes long spans with V8's own decoders, the ones node calls.
  Per 100k ops, debug build, medians of 5 interleaved with node (before -> after, node):
  `Buffer.from(utf8)` 205 -> 49 ms (58), `Buffer.byteLength` 157 -> 28 ms (18), `buf.toString()`
  61 -> 36 ms (14), `buf.write` 101 -> 17 ms (29), `Buffer.concat` 84 -> 19 ms (30). Parity fixes
  found on the way: `Buffer.from(string)` places its bytes in the pool as node's `fromStringFast`
  does, so `byteOffset` and `.buffer` match; base64 reads each code unit's low byte, and
  `byteLength` discounts at most two trailing `=`; `Buffer.concat` allocates from the pool;
  `toString` over an empty range ignores the encoding; `TextEncoder#encodeInto` validates its
  arguments and reports `read` exactly.

- **Windows std handles: a detached child no longer holds oam's stdout or stderr open after oam
  exits, as under node.** oam left the inherit flag set on its stdin, stdout and stderr handles, so
  every child took a copy whatever its `stdio` said. A `detached: true` child (which stays out of
  the kill-on-close job) with `stdio: 'ignore'` then kept oam's output pipes open, and
  `$(oam run x.js)`, `oam run x.js | tail` or a CI log capture waited for that child to exit. oam
  now makes its std handles non-inheritable at startup, as node does. Children with
  `stdio: 'inherit'` still write to oam's stdout and stderr; they receive a fresh duplicate. The
  descriptors a parent hands oam above these three are covered by the next entry.
- **Inherited descriptors above the std three (fds 3 and up) no longer leak into oam's children, as
  under node.** A parent that spawns oam with `stdio: [..., 'pipe']` hands it extra descriptors; oam
  left them inheritable, so every child oam started took a copy whatever its `stdio` said, and the
  parent's read of that pipe ended when the last such child exited instead of when oam did. At
  startup oam now does what node's `uv_disable_stdio_inheritance` does: on Windows it clears the
  inherit flag on the std handles and on every CRT fd the parent passed, on unix it sets
  `FD_CLOEXEC` on the inherited fds 3 and up (never on 0-2, which `stdio: 'inherit'` children
  receive in place). oam's own reads and writes of an inherited fd, and a child explicitly given one
  (`stdio: [..., 4]`), are unaffected. Descriptors at 64 and above are not covered
  ([node-divergences #19](docs/node-divergences.md)). The fix is tested on Windows; the unix half
  has not yet been built or run on unix, and its test stays ignored until it has.
- **`fs.opendir`, `fs.opendirSync` and `fs.promises.opendir` honour `recursive`, as node's do
  (#286).** The `Dir` took one listing with one parent for all of it and ignored every option, so
  `{ recursive: true }` listed the top level only. It now walks as node v22.22.2's does. Handing out
  a directory's Dirent opens that directory. Entries come `bufferSize` (32) at a time, so the walk
  is breadth first while a directory fits in a chunk and interleaves past that. Every Dirent carries
  its own `parentPath`. If a subdirectory is gone before its turn, that read fails with node's
  `opendir` error, path included, and the walk goes on. The options and `bufferSize` are checked as
  node checks them, and a refused `-0` reads `Received -0`. `read(cb)` and `close(cb)` used to call
  back before returning; they now call back asynchronously. While a read is in flight, the reads and
  closes made meanwhile are queued, `readSync` / `closeSync` throw `ERR_DIR_CONCURRENT_OPERATION`,
  and the read shows as an `FSReqCallback` in `process.getActiveResourcesInfo()`, as does a close.
  `fs.promises.opendir` takes a third argument as opendir's callback, as node's promisify does.
  `new fs.Dir()` throws `ERR_MISSING_ARGS` and `Dir.length` is 3. `path` is a getter, and
  `entries()`, `Symbol.dispose` and `Symbol.asyncDispose` exist, as on node's `Dir`.
- **A `worker_threads` Worker finds and runs its entry as node's does (#287).** A missing entry
  threw a `TypeError` ("worker script not found") from the constructor; now the Worker is made,
  emits `'error'` with node's `MODULE_NOT_FOUND` error (`requireStack: []`) and exits 1. The entry
  is searched for as node searches for a program's: the file, then with `.js` added, then a
  directory's `main` or index. A directory whose package.json is not a JSON object fails with
  `ERR_INVALID_PACKAGE_CONFIG`, and a `main` that resolves to nothing with node's "Please verify
  that the package.json has a valid \"main\" entry" error, which carries `path` and `requestPath`.
  An extension neither loader knows, such as `x.txt` or a file really named `x.js.` (whose extension
  node reads as `.`), runs as CommonJS, where oam refused it as an "unsupported module type"; in a
  `"type": "module"` package, or when the file has module syntax, it fails with node's
  `ERR_UNKNOWN_FILE_EXTENSION`, naming the entry's real path. A string that is not absolute or
  `./`/`../`-relative throws node's `ERR_WORKER_PATH`, as a `file:` URL string does; oam resolved
  both against the cwd. `eval: true` with a filename that is not a string throws node's
  `ERR_INVALID_ARG_VALUE`. A worker's `'error'` event carries the error's class and `code`, not only
  a message. And a Worker's `'error'` or `'message'` whose listener throws, or an `'error'` with no
  listener, is an uncaught exception, as in node, and the Worker's later events still come; it was
  an unhandled rejection.
- **A server's `close()` made before `listen()`'s bind has landed closes it, as in node (#387,
  #369).** oam binds every server asynchronously, and `close()` acted only on a server already
  bound. So a `close()` in the same tick as `listen()` closed nothing: net, http, https and http2
  servers then listened and served, with `close(cb)` never called back, and a tls server emitted
  `'close'` with its port still bound and nothing accepting. Now the bind is closed when it lands.
  There is no `'listening'`, then `'close'` comes and the port is free. `cb` gets no arguments for a
  `listen()` without a host. It gets `ERR_SERVER_NOT_RUNNING` when node would have had no handle: a
  `listen(port, host)`, whose lookup node abandons, or a bind that failed, whose `'error'` is still
  emitted first. A second `close()` in that window gets `ERR_SERVER_NOT_RUNNING`, with its `'close'`
  after the first one. A `listen()` on the same port after the `close()` binds it again, where it
  used to fail with `EADDRINUSE`. A failed bind's `'error'` with no listener is an uncaught
  exception, as in node, not an unhandled rejection. `close(cb)` on a net, tls or http2 server that
  is not running now calls back with `ERR_SERVER_NOT_RUNNING` (it never called back), and a second
  `listen()` throws node's `ERR_SERVER_ALREADY_LISTEN`.
- **fs's stat forms honour `bigint` and `throwIfNoEntry`, as node's do (#392).** They ignored their
  options. So a `statSync(p, { throwIfNoEntry: false })` existence check threw ENOENT, and
  `{ bigint: true }` gave plain numbers. Now `statSync` and `lstatSync` answer `undefined` for a
  path that is not there (ENOENT or ENOTDIR) when `throwIfNoEntry` is `false`. `bigint: true` gives
  a `BigIntStats` with exact 64-bit fields and the `*Ns` times in every form: `statSync`,
  `lstatSync`, `fstatSync`, `stat`, `lstat`, `fstat`, `fs.promises.stat` / `lstat`,
  `FileHandle.stat` and `watchFile`. The options are read as node reads them: unvalidated, in node's
  order, and as many times as node reads them (the callback forms read `bigint` twice). A null
  options throws, or rejects in the promise forms. The `*Ms` times keep the fraction of a
  millisecond that node reports; oam's were whole milliseconds. `Stats` is built as node builds it:
  prototypes, lazy Date fields that can be assigned, and the deprecated `fs.Stats` constructor
  (DEP0180), which takes node's positional arguments and warns once per code alongside
  `util.deprecate` wrappers. The callback `stat`, `lstat` and `fstat` are named and have length 1,
  as node's are.
- **`tty.ReadStream` and `tty.WriteStream` are node's classes, and on a terminal `process.stdout`,
  `process.stderr` and `process.stdin` are instances of them, as in node (#391).** They were empty
  stubs that constructed over any descriptor. They now refuse a non-terminal with node's
  `ERR_TTY_INIT_FAILED` and a bad descriptor with `ERR_INVALID_FD`, are `stream.Duplex` streams
  that answer `instanceof net.Socket`, and carry node's `getColorDepth`, `hasColors`, `cursorTo`,
  `clearLine` and `getWindowSize` (a ReadStream `setRawMode`). `tty.isatty` answers for any
  descriptor, so a terminal the program opened (`/dev/tty`, `\\.\CONOUT$`) is one and is sized; an
  msys/cygwin pty pipe (Git Bash's mintty) is a pipe there, as libuv says, so `process.stdout.isTTY`
  is no longer true under mintty. A write in another encoding (`write('68690a', 'hex')`) writes its
  bytes, and stdout's `'resize'` watch no longer shows up in `eventNames()`. `readline.clearLine`
  without a stream returns `true`, as node's does.
- **`events.once` is an async function and an abort rejects with node's `AbortError`, as in node (#344).**
  It was a plain function, so the continuation of `await once(...)` ran before the microtasks the
  same emit queued, and its kind and `length` (3) were not node's. An aborted `once` rejected with a
  `DOMException` (`code` 20, no `cause`); it now rejects with node's `AbortError`, `code` `"ABORT_ERR"`
  and the signal's reason as `cause`. A null emitter rejects with node's `TypeError`.
- **At an ES module's top level `process.nextTick` runs after the promise jobs, as in node (#345).**
  node evaluates an ES module inside a microtask drain, so the promise jobs its top level queues,
  and the code after a top-level await they settle, run before any tick. oam ran the ticks first.
  Now the main module's and a worker's match node; CommonJS and timer callbacks were already right.
  A `.js` or `.ts` file with no package.json "type", which oam runs as an ES module, gets the order
  node gives it, decided by node's own test of the syntax: an ES module's if the file has an import
  or export (`export {}` too), a top-level await, `import.meta`, or a top-level declaration of
  `require`, `module`, `exports`, `__filename` or `__dirname`; CommonJS's if it has none. And no
  tick runs where node's never does: before the report of an ES module entry that throws, at its top
  level or after any top-level await (its `uncaughtException` origin is now node's
  `'unhandledRejection'`), after a fatal microtask throw at an ES module's top level, from an
  `'exit'` listener, or after the `'exit'` emit of a fatal exit. A top-level await that never
  settles exits as node's does: code 13 unless `process.exitCode` was set, and the `'exit'`
  listeners' promise jobs run, where oam exited 1. A module that `import()` loads still runs its top
  level early (#397).
- **`fs.cp`, `fs.cpSync` and `fs.promises.cp` honour their options, as node's do (#390).** The copy
  read `recursive` alone. So `force: false` overwrote the file it was asked to keep, `errorOnExist`
  never failed, and `filter`, `dereference`, `verbatimSymlinks`, `preserveTimestamps` and `mode`
  did nothing. The copies are now node v22.22.2's, ported: the options are checked as node checks
  them, links are copied as links (absolute, or verbatim), and the errors are node's
  (`ERR_FS_CP_EEXIST`, `ERR_INCOMPATIBLE_OPTION_PAIR`, a promise from cpSync's `filter`). A
  directory symlink inside the tree no longer stops `cpSync`, and a junction is copied as the
  directory it leads to, as node does. On Windows `fs.unlink` removes a directory symlink or
  junction, as libuv does, where it failed `EPERM`. Where node's cpSync fails by its
  platform's std::filesystem, or aborts, oam fails as node does on Linux; see
  docs/node-divergences.md.
- **Abort reasons, error headers, `AbortError` and `MessageChannel` are node's (#401).**
  `ac.abort(null)` keeps null as the reason everywhere node does (`signal.reason`,
  `throwIfAborted`, `AbortSignal.any`, an `AbortError`'s `cause`, fetch's rejection); a fetch body
  being read still fails with undici's `DOMException`, "The operation was aborted.".
  `util.inspect` heads an error with its constructor as node does (`DOMException [AbortError]: x`,
  `Foo [Error]: x`), an error whose stack cannot be built prints `[object Error]` instead of
  throwing, and `%s` in `util.format` and `console.log` inspects errors. events, timers/promises,
  the streams, fs and readline reject with one `AbortError` class, and the `fs.writeFile` family
  honours an aborted signal before it opens anything. `util.aborted` resolves with the abort
  `Event`. `MessageChannel` and `MessagePort` are globals, and a port is node's
  `NodeEventTarget`, delivering messages as node's does. `worker_threads.receiveMessageOnPort`
  works. A worker exits once its `parentPort` has no `'message'` listener left. `structuredClone`
  of a function or a symbol throws `DataCloneError`. `util.inspect` (and so `%s`) prints a boxed
  BigInt or Symbol as node does (`[BigInt: 1n]`, `[Symbol: Symbol(q)]`, recognised by internal
  slot like the other boxes, so `[Number (null prototype): 5]`), a `Blob` or `File` as
  `Blob { size: 1, type: '' }`, and an error whose `stack` is not a string with node's
  one-entry-per-line layout. `util.types.isBigIntObject` exists, and `isBoxedPrimitive` counts
  BigInt and Symbol boxes.
- **A `SystemError` code is an instance of its own `NodeError` class, as node's is (#288).**
  node raises `fs.cp`'s `ERR_FS_CP_*` and `ERR_FS_EISDIR`, and `os.getPriority`'s
  `ERR_SYSTEM_ERROR`, as a per-code `class NodeError extends SystemError`. oam built every one
  with a single class, so `err.constructor.name` read `SystemError` where node's reads
  `NodeError`. `fs.rm`'s `ERR_FS_EISDIR` is node's stackless subclass of that code's class, whose
  `constructor` answers `SystemError`. And the `kIsNodeError` mark is each error's own, as
  node's is. The name, code, keys and message are unchanged.
- **A connect made after `server.close()` is refused, as node's is (#338).** A `net` or `tls`
  server's close only woke the accept parked on it, which still held the listening socket, so a
  connect that came before that accept ran landed in its backlog. The connection was then accepted
  for the closed server: the client either stayed connected to nothing, or failed with an error
  other than node's `connect ECONNREFUSED`. Now the close of a TCP or Unix-socket server drops
  the listening socket before it returns, and a connection accepted before `close()` but
  answered after it is reset. A Windows named-pipe server still lets its waiting pipe instance go
  only when its accept wakes (#388).
- **On Windows an open is refused where node's C runtime refuses the handle (#330).** libuv hands
  every handle its open gets to `_open_osfhandle`, which refuses one whose type `GetFileType`
  cannot name. So the root of a share that is no disk is `EINVAL` however it is spelled --
  `\\.\UNC\srv\IPC$` opened, where `\\srv\IPC$` and `\\?\UNC\srv\IPC$` already refused --
  and the mailslot namespace, `\\.\mailslot`, is `UNKNOWN` (errno -4094), where it opened. This
  holds for every open, and for `readFile`, `writeFile` and `appendFile`.

- **On Windows `fstat` of a console opened to write only fails `EISDIR`, as node's does (#331).**
  `fs.fstatSync(fs.openSync("\\\\.\\CONOUT$", "w"))` (and `\\.\CON` or `\\.\CONIN$` opened `"w"`,
  or `"a"`) answered as a character device. libuv sees a console only through a handle that
  can read; one that can only write is a file to it, whose information a console does not
  have. NUL, and a console opened to read, are character devices as before.

- **On Windows `readdir` of a volume or a device namespace refuses it, as node's does (#332).**
  `readdirSync("\\\\?\\C:")` and `"\\\\.\\C:"` (the volume, not its root directory) listed the
  root; node's are `EPERM`. `"\\\\.\\pipe"` with no separator after it listed the pipes; node's is
  `ENOTDIR`. A device is what node says it is, where it was `ENOTDIR`: `"\\\\.\\NUL"`,
  `"\\\\.\\CONIN$"` and `"\\\\.\\CONOUT$"` are `EISDIR`, `"\\\\.\\CON"` is `EINVAL`. And
  `"\\\\.\\mailslot\\"` lists as empty, where it was `ENOENT`. `"\\\\?\\C:\\"` and `"\\\\.\\pipe\\"`,
  with a separator, list as before and as in node; `opendir` is unchanged.

- **`fs.openAsBlob` of a directory gives a Blob, as node's does (#335).** It rejected
  `ERR_INVALID_ARG_VALUE`. A directory opens and has a size -- 0 on Windows, the
  directory's own on Linux and macOS -- so the Blob is made with that size, and reading a
  non-empty one fails `NotReadableError`, as reading a directory does; so does reading a
  Blob, a `Response` or `Request` body or a `FormData` made with one. A non-string
  `options.type` is reported as node reports it (`The "options.type" property ...`). Found on
  the way, for any `Blob`: `stream()` of an empty one gave a zero-length chunk where node
  gives none, and the chunks it gave were the Blob's own bytes, so writing to one changed
  the Blob.

- **What prints a process warning is a `'warning'` listener that can be removed (#342).** oam
  printed warnings from inside `process.emitWarning`, so `process` had no `'warning'`
  listener and the printing could not be turned off: a program that took over warning
  reporting the documented way -- `process.removeAllListeners("warning")`, then its own
  listener -- got every warning twice. The printer is now node's `onWarning` listener:
  `process.listeners("warning")` shows it, removing it stops the printing, and it prints
  any `Error` the event carries, one emitted with `process.emit("warning", err)` included
  (those were not printed). Under `--no-warnings` it is not installed, and
  `NODE_NO_WARNINGS=1` now means the same, as it does to node. Node's one-time hint naming
  `--trace-warnings` is printed too, now that oam has the flag (see Added, #364).

- **`fs.mkdir` applies its mode, checks its options, and says what it made.** In all three
  forms (`mkdirSync`, `fs.mkdir`, `fs.promises.mkdir`):
  - the mode -- `mkdirSync(dir, 0o700)`, `{ mode }` -- was dropped on Linux and macOS, every
    directory being created `0o777` less the mask; it now goes to `mkdir(2)`, for every
    directory a recursive call makes and none that was already there;
  - the options are checked as node checks them: a `recursive` that is not a boolean and a
    mode that is not one are refused (`{ recursive: "yes" }` was taken as `false`), in node's
    order for each form, and `fs.mkdir` has node's `length` and `name`;
  - a recursive mkdir returns (or calls back with, or resolves to) the first directory it
    made, where it returned `undefined`;
  - a recursive mkdir through a file is `ENOTDIR` (it was `EEXIST`), of an empty path
    `ENOENT`, of a drive root `EPERM` and onto a dangling link `ENOENT` (the last three
    succeeded or said `EEXIST`), and the callback and promise forms name the component
    that failed.

- **`process.umask` is the process's file mode creation mask.** It kept a number of its
  own: it started at `0` whatever the process had inherited, and setting it changed nothing
  about the files created afterwards. It is now `umask(2)` on Linux and macOS, so it reads
  what the process started with, applies to every file and directory created after a set,
  and is inherited by child processes. On Windows it keeps the owner's read and write bits
  and decides whether a created file is read-only, as node's does. A mask is checked as node
  checks one (an octal string or a 32-bit unsigned integer), and a worker may read the mask
  but not set it (`ERR_WORKER_UNSUPPORTED_OPERATION`). What oam writes for itself -- its
  bytecode and transpile caches, crash reports, the scratch files of `-e`, of a compiled
  binary and of `serve --workers` -- does not follow a mask the program sets: caches and
  reports keep the modes the mask oam started under gives them, with the owner's own
  bits always kept, and scratch files are the owner's alone.

- **The `mode` of an open that creates its file is applied (#324).** It was checked and then
  dropped: every file was created with the default `0o666`. On Windows a mode with no
  owner-write bit now creates the file read-only, as node's does (`openSync(f, "w", 0o444)`
  gave a writable file); on Linux and macOS the mode goes to `open(2)`, so a file created
  `0o600` is no longer readable by group and other. This holds for `fs.open`, `openSync`
  and `fs.promises.open`, for `writeFile` and `appendFile` in their three forms, and for
  `createWriteStream` and `createReadStream`. A file that is already there keeps its mode,
  except, on Windows and as with node, one a truncating open (`"w"`) replaces.

- **The pool learns an origin that closes right after answering, so a request is not written
  into a connection it is closing (#312).** A server that answers and closes in one go -- a
  `302` then `end()`, the last answer of a keep-alive budget -- left a pooled connection
  whose close was still on its way, and the next request to that origin could be written
  into it: read twice by the server, or lost if it could not be sent again. The pool's 1 ms
  wait covered a plain-TCP close and not a TLS one, which arrives later (102-135 of 1,000
  redirect hops read twice and 288-313 of 400 `POST`s through, against a node TLS server
  where node's own client measures 0 and 400). The pool now remembers an origin it finds
  has closed a connection within 250 ms of answering on it and, for a minute, does not reuse a
  connection to it parked less than 250 ms ago: such a request opens its own, and of the
  connections those leave one is kept. The rule is per origin and applies to http as well
  as https, so an origin that closes after some answers sees more connections from oam for
  that minute; one that has sat idle longer is reused as before, and an origin never seen
  to close this way is unaffected. The same run now measures 0-1 and 400. What stays open
  is the first request or two to such an origin, sent before there is anything to have
  learned from.
- **`FileHandle.readFile` checks its options before it reads (#351).** It read first and
  decoded at the end, so an unknown `encoding` was reported with the wrong code
  (`ERR_UNKNOWN_ENCODING`), not reported at all for an empty file, and hidden behind the
  read's own `EBADF` on a handle that cannot be read. The options are now checked first,
  as node's are (`ERR_INVALID_ARG_VALUE`; `"buffer"` is `ERR_UNKNOWN_ENCODING`), and a
  `signal` is honoured: one already aborted, or aborted between reads, rejects
  `AbortError`, and one aborted right after the call is seen before anything is read. A
  regular file is read up to the size it had when the read began, as node's is, so what is
  appended meanwhile is left for the next read. Conformance case 402.
- **`Buffer.isEncoding` is true only for a string**, as node's is. An array or a `String`
  object that coerces to a known name (`["utf8"]`) was accepted, by it and by every
  option check built on it.
- **A `FileHandle` is an `EventEmitter`, and a stream over one is tied to it (#343).**
  `fs.promises.open()` returned a plain object: `handle.on("close", ...)` threw, and
  `handle.close()` closed the descriptor on the spot. It is now node's `FileHandle`
  class. `close()` emits `'close'`, and the handle counts who is using its descriptor --
  each method while its operation runs, and each stream made over it -- closing the
  descriptor, and settling `close()`, when the last one is done. So closing a handle
  under a stream closes the stream cleanly (it failed its next read `EBADF`), a second
  stream on the same handle no longer fails when the first ends, an `autoClose: false`
  stream is closed with its handle instead of outliving it, and a `close()` made while a
  read is in flight waits for the read. Conformance case 401.
- **An `EventEmitter` has an own `_maxListeners`**, as node's does: `undefined` until
  `setMaxListeners()` sets it, and the third of an emitter's own keys.
- **Callback `fs.readFile(fd, cb)` answers as node's does when the descriptor cannot be
  read (#334).** node's callback form drops a failed read of a descriptor it was handed
  and calls back with what was read so far, and no error: an empty Buffer (or `""`) for a
  descriptor opened to write only, and for a directory. oam reported the read's `EBADF` /
  `EISDIR`. A descriptor that is not open gets node's own `ERR_INVALID_ARG_TYPE` there
  rather than `EBADF` `fstat`, and `readFileSync(fd, "utf8")` of one fails `EBADF`
  `read`, as node's stat-less utf8 read does. `readFileSync(fd)` and
  `FileHandle.readFile()` report the failure, as before. Conformance case 400.
- **`readFile` honours its `flag` (#336).** `readFileSync`, `fs.readFile` and
  `fs.promises.readFile` always opened read-only, whatever `flag` said. The path is now
  opened with the flag given, as node's is, so its effects are the call's:
  `{ flag: "w+" }` empties the file before reading it, `"a+"` creates one that is missing,
  `"wx"` refuses one that is there, and a write-only flag fails the read `EBADF`. The
  options are checked before anything is opened, as node checks them: a bad `encoding` is
  `ERR_INVALID_ARG_VALUE`, and a signal that is already aborted rejects `AbortError`.
  Conformance case 399.
- **Under `--permission`, an open is checked for every grant it needs**: the read grant
  unless it is write-only, and the write grant unless it can only read -- both, for an
  open that reads and writes (`"r+"`, `"w+"`, `"a+"`), as node's rule has it.
- **`fs/promises` no longer exports `_globAsPromise`**, an internal helper that had been
  left on the module object; `import { _globAsPromise } from "node:fs/promises"` linked in
  oam and is the `SyntaxError` it is in node.
- **Numeric open flags mean what their bits say (#328).** oam turned a numeric `flags`
  into the nearest flag string, and no string spells "write, do not truncate":
  `fs.openSync(p, O_WRONLY)`, `O_WRONLY | O_CREAT` and `O_RDWR | O_CREAT` opened as `"w"`
  / `"w+"` and **emptied the file**, and `O_WRONLY` created one that was missing. The open
  is now made from the bits themselves, by every form (`open`, `openSync`,
  `fs.promises.open`, the `flag` of `writeFile`, file streams): through `open(2)` as
  given on Linux and macOS, and on Windows as the one `CreateFileW` libuv builds from
  them (`O_TRUNC` without `O_CREAT` is `EINVAL`, `O_APPEND` appends whatever the access
  mode, both access bits are `EINVAL`). Conformance case 398.
- **Under `--permission`, an open needs the write grant unless it can only read.** The
  grant used to be read off the flag string. It is now decided from the bits the open is
  made with: read-only access plus flags that change nothing is a read, and everything
  else needs `--allow-fs-write` -- `O_CREAT`, `O_TRUNC` or `O_APPEND` with read-only
  access, Windows's delete-on-close `O_TEMPORARY`, and any bit oam has no name for.
- **`fs.constants`' open flags are the platform's.** They were one hand-written table:
  `O_SYNC`, `O_DIRECTORY` and `O_NOFOLLOW` were listed on Windows, where node has none of
  them, and with one value for every platform. The table now comes from the platform the
  binary was built for, with node's names for it (`UV_FS_O_FILEMAP`, and on Linux and
  macOS `O_NOCTTY`, `O_DSYNC`, `O_NONBLOCK` and the rest).
- **The synchronous flag strings ask for `O_SYNC`.** `"rs"`, `"rs+"`, `"as"` and `"as+"`
  opened as their plain twins on Linux and macOS.
- **On Windows an exclusive open through a junction whose target is gone makes the
  target (#333)**, as a directory, and returns its descriptor, as node's does; it failed
  `EEXIST`.
- **`fs.createWriteStream` opens its file when the stream is made (#323).** oam opened at
  the first write, or at `end()` when there was none. A stream nobody had written to had no
  file and had emitted nothing; one ended without data never emitted `'open'` or `'ready'`;
  and one over a path that does not open stayed silent until it was written to. The open
  now happens at construction, as node's does: `'open'` then `'ready'` fire, writes queue
  behind it, and a failed open destroys the stream with the open's error (`'error'`, then
  `'close'`), so `finished()` and `pipeline()` see it without a write. Conformance case
  397.
- **`createWriteStream` and `createReadStream` honour `flags`.** A write stream opened
  `"a"` or else `"w"`, and a read stream always `"r"`: `{ flags: "r+" }` truncated the
  file it was meant to write into, and `"wx"` overwrote one that was there. The flag given
  is the flag opened with.
- **`createWriteStream` honours `start`, `flush` and a string `encoding`.** `start` was
  ignored (every write went to the cursor); `flush: true` now syncs before the close; and
  `createWriteStream(path, "latin1")` encodes strings as it says. The write stream's
  default `highWaterMark` is node's 16384 (it was 65536).
- **File streams have node's properties**: `fd` (null until open and once closed),
  `pending`, `autoClose`, `flags`, `mode`, `start`, `pos`, and `end` on a read stream,
  where there were only `path` and the byte count. `pos` is the live cursor, `path` from
  a `file:` URL is a string, and a stream handed a descriptor has no `path`, `flags` or
  `mode`. Options are checked as node checks them, in its order: a bad `encoding` is
  `ERR_INVALID_ARG_VALUE`, and `start` / `end` are range-checked.
- **A file stream closes its descriptor when it is destroyed, after the read or write in
  flight.** `write()` followed at once by `destroy()` used to close the descriptor under
  the write and lose it; the write now lands first, as in node. With `autoClose: false`,
  `destroy()` and `close(cb)` left the descriptor open (and `close`'s callback never
  ran); both close it now. A read stream keeps its descriptor through `'end'`, and
  `'close'` comes a turn of the event loop after `'finish'` or `'end'`, as in node.
- **`WriteStream` has `destroySoon()` and writes a queued batch as one write**, so
  `bytesWritten` moves once per batch as node's does. `createReadStream` honours
  `emitClose`.
- **A read error under `FileHandle.readLines()` no longer ends the process (#337).** A
  `readline` Interface did not listen for its input stream's `'error'`, so a failed read
  was thrown as an uncaught exception -- from inside a `try` / `catch` around
  `for await (const line of handle.readLines())` that never saw it. The Interface now
  emits its input's error on itself, as node's does: an `'error'` listener on it is called,
  and the async iterator rejects with it after the lines that arrived first. The same goes
  for `readline.createInterface({ input })` and `readline/promises` over any stream that
  fails. Conformance case 396.
- **A `readline` Interface's async iterator is node's.** It is made once per Interface;
  several `next()` calls made at once are answered in order (all but the last used to
  hang); `return()` keeps the lines already queued; it has `throw()`; and with more than
  1024 lines unread the Interface is paused and then resumed as they are read, so a slow
  `for await` no longer buffers the whole input.
- **`events.on()` takes `close`, `highWaterMark` and `lowWaterMark`.** `close` names
  events that end the iteration; the watermarks call the emitter's `pause()` and
  `resume()`. Its iterator now stops listening the moment it sees an `'error'`, keeps
  queued events readable after `return()`, and has `%AsyncIteratorPrototype%` as its
  prototype, as node's does.
- **On Windows `fchmod` works through a descriptor opened for reading (#322).**
  `fchmodSync(fd, 0o444)`, `fs.fchmod` and `FileHandle.chmod()` failed `EPERM: operation not
  permitted, fchmod` when the descriptor was opened `"r"`: oam set the read-only attribute
  on the descriptor's own handle, which has no right to. It now reopens the handle for that
  one right, as libuv does, so what the descriptor was opened for does not matter, and
  writes the file's times back as it read them, so `ctime` no longer moves. A piped stdin or
  stdout now fails `EBUSY` (it succeeded) and the NUL device `EINVAL` (it was `EISDIR`), as
  node's do. Conformance case 395.
- **On Windows a truncating open of a named pipe returns a descriptor (#320).**
  `openSync(pipe, "w")`, `"w+"`, `writeFile` and a write stream over a pipe failed
  `EINVAL: invalid argument, open` -- after connecting to the pipe's server, twice. oam
  opened through std, whose truncating open is an open and then a truncation of the handle,
  and a pipe has nothing to truncate. It is now the single `CREATE_ALWAYS` open libuv
  makes: the descriptor comes back, the write arrives, and the server sees one connection.
  `\\.\CON` opens `"w"` the same way. Conformance case 394.
- **On Windows a truncating open no longer empties a hidden or system file (#321).** node
  refuses `"w"`, `"w+"` and `writeFile` on one (`EPERM: operation not permitted, open`)
  and leaves it as it was; oam truncated it. `"r+"` and `"a"` open it in both.
- **On Windows a truncating open replaces the file**, as node's does, where oam emptied it
  in place: its alternate data streams go and its attributes are reset to the archive bit
  (the read-only bit a `mode` without the owner's write bit asks for is still not set: #324).
  Through a junction or directory symlink whose target is gone the open now fails `ENOENT`
  (it was `EPERM`).
- **On Windows `readdir` of a link of the wrong kind reports what node does (#285).** oam
  listed through std's `read_dir`, whose one answer for anything that is no directory it
  reported as `ENOTDIR`. libuv's scandir opens the path first and reports that open:
  `readdirSync` of a file symlink to a directory is now `EPERM`, and of a directory symlink
  or junction to a file `ENOENT`, in every form (`withFileTypes`, `recursive`, callback,
  promise). A plain file is still `ENOTDIR`. `opendir` follows libuv's other listing, which
  reads the link's own attributes: a directory link to a file is `ENOENT`, a file symlink
  `ENOTDIR` wherever it leads. Conformance case 393.
- **On Windows `readdir` keeps a trailing separator.** It is the one call whose path does:
  `readdirSync("file.txt\\")` fails `ENOENT: no such file or directory, scandir
  'C:\cwd\file.txt\'` as node's does, where oam dropped the separator and answered
  `ENOTDIR` for `'C:\cwd\file.txt'`. A directory lists the same either way.
- **A failed `opendir` names `opendir`.** `fs.opendir`, `fs.promises.opendir` and
  `opendirSync` reported syscall `scandir` on every platform; node reports `opendir`, and
  `opendirSync`'s error carries no `path` (`ENOTDIR: not a directory, opendir`).
- **On Windows `opendir("")` lists the current directory**, as node's does, with `dir.path`
  still `""`; it failed `ENOENT`. `readdir("")` is `ENOENT` in both.
- **On Windows a directory opens, as node's does (#284).** oam opened through std without
  `FILE_FLAG_BACKUP_SEMANTICS`, which libuv asks for on every path and without which
  Windows opens no directory at all, so every open node allows failed `EPERM`. Now
  `openSync(dir, "r")`, `"r+"`, `"a"` and `"a+"` (and `fs.open`, `fs.promises.open`)
  return a descriptor: `fstat` of it is a directory, a read or write on it fails `EISDIR:
  illegal operation on a directory, read` / `..., write` with no path (`EBADF` on a
  descriptor not opened for that direction), `fchmod` is `EPERM`, and the directory can be
  renamed or removed under it. It follows that `appendFileSync(dir, "")` and
  `fs.promises.appendFile(dir, "")` succeed instead of failing `EISDIR` `write`,
  `truncateSync(dir)` fails `EINVAL` `ftruncate` instead of `EPERM` `open`,
  `openSync(dir, "ax")` is `EEXIST` instead of `EPERM`, `createReadStream(dir)` and
  `createWriteStream(dir, { flags: "a" })` emit `'open'` before their `EISDIR`, and a drive
  or share root (`C:\`, `\\srv\sh`) opens for reading. What failed in node still fails the same way:
  `openSync(dir, "w")` `EISDIR`, `readFileSync(dir)` `EISDIR` `read`, a write open of a
  root `EPERM`. Conformance case 392.
- **Callback `fs.writeFile` and `fs.appendFile` issue their write even for no data.** node's
  callback forms write once before looking at what is left, so the descriptor answers:
  `fs.writeFile(fdOpenedForRead, "", cb)` and `fs.writeFile(path, "", { flag: "r" }, cb)`
  are `EBADF` `write`, where oam called back with no error, and
  `fs.appendFile(dir, "", cb)` on Windows stays `EISDIR` `write` now that the directory
  opens. The sync and promise forms skip an empty write in both runtimes.
- **On Windows `stat` reports a directory's size as 0.** `statSync("C:\\").size` was the
  root's index allocation (12288 on NTFS); libuv reports 0 for every directory.
- **Windows child processes honour `windowsHide` and stop paying for a console each.** Every child
  was started with `CREATE_NO_WINDOW`, so each console child got a hidden conhost.exe of its own
  (~35 ms a spawn), and `windowsHide` was ignored. The flags now follow libuv: `CREATE_NO_WINDOW`
  only for `windowsHide: true` with no inherited slot, so by default a child shares oam's console;
  a console-less oam still starts children windowless (divergence 53). `spawn`, `spawnSync` and
  `fork` reject a non-boolean `windowsHide` with `ERR_INVALID_ARG_TYPE`, as node does. A spawn with
  more than three stdio slots (CDP over pipes) read its pipes by polling with a 50 ms sleep; a read
  now blocks in `ReadFile` and returns as data arrives, `destroy()` on such a stream closes the
  pipe and cancels the read, and output written just before the child exits is read to the end.
  Debug build, medians of 5 interleaved with node on a loaded box (ms): 20 echo round trips over
  four slots 979 -> 8 (node 13); 20 `spawnSync` of `cmd /c exit` 3252 -> 1745 (node 1975), 20
  `spawn` 3087 -> 1937; conformance case 394 102751 -> 44660 (node 33971), case 395 57015 ->
  41855 (node 36880). Cases 450-452.
- **A worker_threads Worker's own `execArgv` and `env` decide its process flags, as node's do
  (#370).** Every worker ran with the flags of its parent's command line, whatever it was given:
  `execArgv: []` under a parent run with `--no-warnings` had no default `'warning'` listener, and
  `env: { NODE_NO_WARNINGS: "1" }` did not remove it. Now a Worker given neither option shares its
  creator's options (a worker's own, when a worker creates it); given either, it starts from the
  defaults, takes `NODE_OPTIONS` from the environment it is given, then its `execArgv`, and reads
  `NODE_NO_WARNINGS` from its own `process.env` -- for `--no-warnings`, `--no-deprecation`,
  `--pending-deprecation`, `--disable-warning`, `--redirect-warnings`, `--trace-require-module`
  and the `--tls-min/max-v1.x` defaults. `--title` and `--zero-fill-buffers` stay the whole
  process's, as in node. `stderr: true` now sends the worker's `process.stderr` output, its
  warnings included, to `worker.stderr`; it went to the process's stderr.
- **A worker whose run fails fatally ends as node's does (#399).** It now emits `'exit'` with code 1
  on its own `process` before the parent hears of the error (nothing an `'exit'` listener queues
  runs, the thread exits with the `exitCode` the listeners leave, and no `'exit'` is emitted when an
  `'uncaughtException'` listener threw), and the parent's `'error'` event gets the error itself: an
  `Error` of the nearest built-in class with its own `message`, `name`, `stack`, `code` and other
  properties, a `cause` rebuilt the same way, any other thrown value as itself, and an unhandled
  rejection of a non-`Error` as node's `ERR_UNHANDLED_REJECTION` error. It was a plain `Error` whose
  `message` was the whole rendered report, which oam also printed to stderr under `worker N:`;
  nothing is printed now unless the parent leaves `'error'` unhandled. A synchronous throw from a
  CommonJS worker entry now reaches the worker's own `'uncaughtException'` listeners too.
- **A fatal microtask throw ends the run at the throw, as in node.** `queueMicrotask(() => { throw
  e })` with no `uncaughtException` listener let the rest of the drain run first -- a sibling
  `.then`, a later `queueMicrotask` callback, an async function's continuation -- so their output
  came before the report. Nothing queued after the throw runs now, from an ES module or CommonJS
  entry and the modules it imports statically, and `uncaughtExceptionMonitor` hears the throw
  once, not twice (#398). A module loaded by `import()` still lets its checkpoint and the
  importer's continuation run before the report (docs/node-divergences.md, the `import()`
  evaluation entry), and a worker keeps running the rest of the drain, as node's does.
- **Throws on the way out behave as node's.** A promise job an `'exit'` listener queues that throws
  is reported and exits 1 (it was lost, exit 0), and an `uncaughtException` listener sees it. A
  promise such a listener rejects and leaves unhandled now exits 1, as in node, though it is
  reported as oam's `OAM-RT0004` line and not offered to an `uncaughtException` listener
  (divergence #55). A throw from an `'exit'` listener goes to the `uncaughtException` listeners,
  is reported with its source frame and node's report, keeps a `process.exitCode` already set
  (`process.exit(3)` exits 3; it was always 1), and stops the emit: later listeners and the
  promise jobs the listeners queued no longer run. Past a fatal throw, a throwing `'exit'`
  listener is no longer reported after the original error. `oam -e` and compiled binaries run the
  `'exit'` listeners before printing the report, as `oam run` does. A worker's own `'exit'`
  listeners keep their earlier handling; a worker whose run fails fatally is the worker entry
  above (#399).
- **A throwing `uncaughtException` listener's report names the listener's line**, not a line of
  oam's internal dispatcher (#399).
- **The report of a thrown value that is not an Error is node's.** `throw 42`, `throw "text"`, `throw
  { a: 1 }` and the like open with an empty line and put the value right under the caret, and a
  primitive prints as `String()` gives it (`text`, not `'text'`; `5`, not `5n`), wherever oam has
  the throw's source frame. Node's `--trace-uncaught` hint is still not printed (#399).
- **The nextTick queue around exits and handled throws matches node.** `process.nextTick` queues
  nothing once the process is exiting, so a warning emitted from an `'exit'` listener is not
  printed. After an `uncaughtException` listener handles a tick's throw, the rest of the batch
  runs at node's next tick point -- before the next immediate, at the end of the timers phase,
  and before the loop waits for a timer that is not due yet -- where it ran after them; a timer
  due in the same timers phase runs before it, and V8's tasks and I/O callbacks no longer run in
  the middle of a timers phase (#366, #399).
- **Windows: `fs.stat` of NUL gives its character-device stat, and other device paths fail as
  in node.** `statSync`, `lstatSync`, `fs.stat` and `fs.promises.stat` of `\\.\NUL` (and
  `\\?\NUL`, `\\.\Global\NUL`, `\\.\GLOBALROOT\Device\Null`) failed `EISDIR`; they now give
  the shape `fstat` of an open NUL gives (`mode` 0o20666, `rdev` 1376256, `blksize` 4096). The
  pipe and mailslot namespaces and `KsecDD` fail `EINVAL` where oam said `EISDIR` (a volume,
  `\\.\C:`, stays `EISDIR`, as in node), and `readdirSync` of `KsecDD` is `EISDIR` (was
  `ENOTDIR`). oam asks what libuv asks:
  the path by name (GetFileInformationByName, Windows 11 24H2 and later), then the handle's device
  type and its file information (#380, #383).
- **Windows: a stat of a path that goes on past a looping symlink is `ENOENT`, as in node.**
  With `l` a link to itself, `statSync("l/a")` and `mkdirSync("l/a", { recursive: true })` (all
  three forms) failed `ELOOP`; they are `ENOENT`, and `statSync("l")` stays `ELOOP` (#362).
- **Windows: `fs.access` and `fs.chmod` read and set a path's own attributes, as libuv does.**
  A dangling or looping symlink is accessible (`existsSync` still says `false`) and `chmod`
  changes the link rather than failing `ENOENT`; a read-only directory passes `W_OK`; a device or
  a volume (`\\.\C:`) is `EINVAL` (was `EISDIR`) and a share root that is no disk (`\\localhost\IPC$`) `ENOTSUP` (was
  `EINVAL`). `cpSync` from any of these reports the same code, under `lstat`, and names the path
  without its `\\?\` prefix, as node's does (#383).
- **Windows: `fs.realpathSync` and `fs.realpath` of a `\\?\` or `\\.\` path follow node's walk.**
  The path a recursive `mkdirSync` returns (`\\?\C:\...`) resolved in oam; node v22.22.2's
  component walk fails it `EISDIR: ..., lstat 'C:'`, and oam now does too. NUL resolves to itself
  (oam failed `EISDIR`). The `.native` forms and `fs.promises.realpath` still resolve such a path
  (#361, #383).
- **Windows: an open with `UV_FS_O_FILEMAP` of a console or the pipe namespace fails, as in
  node.** libuv asks such a handle for its standard information and fails the open when it has
  none: a console is `EISDIR`, `\\.\pipe\` `EINVAL`; oam handed out a descriptor. A write-only
  `UV_FS_O_FILEMAP` open also asks read access, as libuv's does (#384).
- **A repeated permission flag adds its grant, as node's does.** Under `--permission`,
  `--allow-fs-write=A --allow-fs-write=B` kept only the last occurrence, so writes under `A` were
  refused; every occurrence of `--allow-fs-read`, `--allow-fs-write`, `--allow-net` and
  `--allow-env` now grants its entries, from the command line and `NODE_OPTIONS` together.
  `process.execArgv` lists each occurrence, so a child started under `--permission` inherits all
  of them (#363).
- **A `*` in an fs grant entry is a wildcard, as in node.** `--allow-fs-read=C:\T\*` (or `dir/*`)
  granted only a file named `*`, so every read under the directory was refused. The text before
  the first `*` is now a prefix: `dir/*` and `dir\*` grant `dir` and everything under it, `dir*`
  every path starting with `dir`, and `/*` or `C:\*` the whole root, for `--allow-fs-read` and
  `--allow-fs-write` alike (#376). On POSIX a `\` in a grant entry or a path is now part of the
  name, as node and the OS read it, rather than a separator.
- **A Windows named-pipe server's `close()` closes the pipe before it returns, as node's does.**
  The pipe instances still waiting for a client stayed open until the server's pending accept woke
  and dropped them, so a client that dialled the name right after `close()` could connect to one
  and then see the pipe dropped (or, from `fs.openSync`, get an fd) where node gives `ENOENT`. The
  close now disconnects every waiting instance, so none takes a client, and returns once they are
  closed (#388). A client that had connected but not yet been handed to the server (no
  `'connection'` yet) is closed with it too and reads `'end'`; its pipe instance used to stay open
  until the next tick, so a dial right after `close()` waited 30 s for `ETIMEDOUT`, and a `listen`
  on the name in the same tick was `EADDRINUSE`. Unchanged, by decision: an oam pipe server still
  refuses clients that reach it through a UNC server name, `\\localhost\pipe\x` included, with
  `EPERM`, where node's accepts them (#385; see `docs/node-divergences.md`, entry 50).

- **`tty.WriteStream` and `tty.ReadStream` over a console opened by name refuse what node's refuse,
  with node's errno (#381).** On Windows they took any descriptor `tty.isatty` called a terminal and
  refused the rest with `EBADF`. They now ask the console what libuv's `uv_tty_init` asks: a console
  opened write-only (`\\.\CON` with `w`, `\\.\CONOUT$` and `\\.\CONIN$` with `w` or `a`), and a
  screen buffer opened without write access (`\\.\CONOUT$` with `r`, `a+` or `as+`, which is still
  a terminal to `isatty`), are `ERR_TTY_INIT_FAILED` with `EPERM`, and `EBADF` is left to a
  descriptor with no console behind it. `tty.isatty` of a console opened by name, and of a
  descriptor once it is closed, already answered as node's does (#379); both are now pinned in a
  console test.
- **`MaxListenersExceededWarning` is a process warning, as in node.** Past an `EventEmitter`'s
  listener limit oam printed its own line with `console.warn`, which `--no-warnings` and a program
  handling warnings itself could not stop. It now goes through `process.emitWarning` with node's
  text and the `emitter`, `type` and `count` fields, and an `EventTarget` (including an
  `AbortSignal` given a limit) warns too, once per target, with `target` in place of `emitter`. A
  target takes `events.defaultMaxListeners` when it is made; `events.setMaxListeners(n)` with no
  target sets that default, and it checks `n` as node's does (`ERR_INVALID_ARG_TYPE` /
  `ERR_OUT_OF_RANGE` naming `"setMaxListeners"`). An `EventTarget`
  and an `AbortSignal` now inspect as node's (`EventTarget {}`, `AbortSignal { aborted: false }`)
  (#365).
- **`process.emitWarning` reads its type and code as node's does.** An empty or falsy `type`
  (positional, or in the options form) gives the name `Warning` instead of an empty name, and a
  bad `type` or `code` is reported as the `"type"` / `"code"` argument, never as an `options.`
  property; a `DeprecationWarning` under `process.noDeprecation` is dropped even when
  `process.throwDeprecation` is set (#367).
- **The deprecations node v22.22.2 emits at runtime, and the legacy names they guard.** `punycode`
  warns DEP0040 when first loaded (not when a package loads it -- node's own check, which looks
  for `/node_modules/` in each frame's script name, so on Windows only a package's ES modules,
  named by their `file://` URLs, are skipped), and has its `version`; `util.isArray` warns DEP0044; `util._extend` (DEP0060),
  `net._setSimultaneousAccepts` (DEP0121) and `require("sys")` (DEP0025, `util` under its old
  name, in `module.builtinModules` too) are there; `crypto.Hash` and `crypto.Hmac` construct, with
  or without `new`, and warn DEP0179 / DEP0181. `createHash` / `createHmac` throw node's
  `ERR_INVALID_ARG_TYPE` for a non-string algorithm (#368).
- **A BYOB read fills at most the view it is given, as node's does (#372).** `getReader({ mode:
  "byob" })` ignored the mode and returned a default reader, so `read(new Uint8Array(2))` of a
  3-byte chunk handed back all 3 bytes. A byte stream now has node's BYOB reader: `read(view, {
  min })` transfers the view's buffer and fills it from the queue -- at most the view, across
  chunks, the rest left for the next read -- or waits for the source, which can answer through
  `controller.byobRequest` (`respond()`, `respondWithNewView()`); `tee()` of a byte stream gives
  two byte streams and a copy of each chunk to the second branch, as node's does. A `Blob`'s
  stream, a `fetch` body and `FileHandle.readableWebStream()` read the same way.
- **`fs.openAsBlob` gives a file-backed Blob that is read only when it is (#373).** It read the
  whole file into memory at the call. The Blob now holds the path and the size and mtime the
  open's fstat gave; each read opens the file then and fails `NotReadableError` once the file has
  changed, as node's does, and so do slices of it, Blobs made of it and `Response`, `Request` and
  `FormData` bodies (a `fetch` sends them with their content-length, and fails once the file
  changed). A large file costs no memory until it is read.
- **`fs.openAsBlob` checks its arguments and opens the file at the call (#374).** It checked the
  options and the path asynchronously and turned every failure into `ERR_INVALID_ARG_VALUE`. Bad
  options, a bad type, a bad path and a missing file now throw at the call, as node's do, and a
  `--permission` denial is node's `ERR_ACCESS_DENIED`. `openAsBlob` of `\\.\NUL` is a 0-byte
  Blob on Windows (#383).
- **`Blob` matches node's in its parts, slices, types and clones (#375).** `stream()` gives one
  chunk per part (a file in 64 KiB chunks) rather than the whole Blob at once; `slice()` converts
  its arguments as node does (`slice(NaN, Infinity)` is empty) and an omitted content type is
  `""`, not the Blob's; the constructor validates `sources` and `options` and honours `endings`;
  `structuredClone` of a Blob gives a working Blob (it gave a broken one), and of `fs.openAsBlob`'s
  Blob throws with `code: "ERR_INVALID_STATE"`; `util.inspect` shows `Blob { size, type }` (and a
  File's name and lastModified) rather than `Blob {}`. A chunk read from a `Response` body made from
  bytes or a Blob is the reader's own copy, so writing to it no longer changes the Blob or a
  `clone()`.
- **`util.inspect` of a `ReadableStream` is node's summary.** It printed every internal field of
  the stream; it is now `ReadableStream { locked, state, supportsBYOB }`, as node's is, and so is
  the stream in the message of `getReader({ mode: "byob" })`'s "must be a byte stream" error.
- **A `--permission` denial's message names the flag that grants it.** `ERR_ACCESS_DENIED` said
  only "Access to this API has been restricted"; it now goes on, as node's does, "Use
  --allow-fs-read to manage permissions." with the flag of the denied scope (`--allow-fs-write`,
  `--allow-child-process`, `--allow-worker`, ...). oam's own net and environment scopes name
  `--allow-net` and `--allow-env` (#363).

- **`import()` loads and evaluates its module in promise jobs after the call, as node's does
  (#397).** oam evaluated the module inside the import hook, with the importer's frame on the
  stack, and ran a microtask checkpoint there. So the module's top level ran before the importer's
  next statement, its `process.nextTick` callbacks ran before the importer's continuation (from
  CommonJS `micro | tick | after import`, where node prints `micro | after import | tick`), and a
  CommonJS importer's own promise jobs ran ahead of its ticks. `import()` now runs node v22.22.2's
  loader chain -- resolve in the call, then load, link, instantiate and evaluate in promise jobs --
  so every step lands on node's microtask turn: a module with no imports of its own evaluates on
  the 8th turn after the call and `import()` settles on the 14th, as in node. A module whose
  top-level await waits on a timer can now be imported (oam rejected it as unsupported), and a
  dynamic import cycle under top-level await deadlocks and exits 13, as node's does, where oam
  handed back a partial namespace. A CommonJS module still runs when oam loads it, not when node
  would (docs/node-divergences.md, entry 52); an `import()` such a module makes inside a
  `require()` of an ES module now loads its graph after the `require()` returns, as node's does.

- **Deep recursion through a sync op throws a `RangeError` on Windows instead of killing the
  process (#395).** Recursion that called a native op at the bottom of the JS stack could overflow
  the native stack first: the process died with `thread 'main' has overflowed its stack`
  (`0xC00000FD`) where node throws a catchable `RangeError: Maximum call stack size exceeded`.
  Measured on a release build with `fs.copyFileSync`, `fs.cpSync` and `zlib.deflateSync`, and on a
  debug build with `fs.readdirSync` and `fs.opendirSync` too. oam.exe's main thread had the
  linker's 1 MiB stack, of which V8 takes ~984 KiB for JS; it now reserves 8 MiB, as node.exe's
  header does. Worker threads (and `oam.fork` isolates) get node's 4 MiB worker stack, up from
  2 MiB. How deep JS can recurse is unchanged on every thread: V8 sets that, not the stack size.
  It is not node's depth: a worker recurses a quarter to a third as deep as node's, and the main
  thread somewhat deeper, so a 1500-deep `fs.cpSync` with a `filter` or `fs.rmSync` recursive
  completes in oam where node throws `RangeError` (see docs/node-divergences.md).
- **A CommonJS module that throws while an ES module entry's imports load is an uncaught
  exception, as in node (#437).** `import "./dep.cjs"` where `dep.cjs` throws ended the run
  with oam's one-line `error[OAM-RT0001]: ...: Uncaught <value>` and offered the throw to no
  listener. It now goes the way of the entry's own throw: `uncaughtExceptionMonitor`, a
  capture callback and the `'uncaughtException'` listeners see it with origin
  `unhandledRejection`, a listener that takes it lets the run go on without the entry's
  body, and otherwise the report is node's fatal one (the source frame and stack of an
  Error, the `--trace-uncaught` hint after a primitive, `Thrown at:` under the flag), exit
  1, or 7 when a listener throws. A `Worker`'s entry hands its parent the value. When the
  rest of the graph does not load, compile or link, that failure is the report and no
  listener sees the value, as in node, which links the whole graph before it runs any of
  it; oam checks the rest without running another CommonJS body. An ES
  module entry's throw, this one included, now gives the monitor origin
  `uncaughtException` when a capture callback is set, as node's loader does, and a
  callback that throws there is offered its throw once more, origin `unhandledRejection`
  (its exit 7 stands only if it throws again), where oam ended the run at the first. What
  still differs is docs/node-divergences.md #52 and #54. Conformance case 574.

### Performance

- **`stat` and `readdir` results no longer make a JSON round trip.** `stat`, `lstat` and `fstat`
  (sync, callback, promise, `FileHandle`) and `readdir` / `opendir` listings came back as JSON the
  native serialized and V8 parsed back on every call. A stat is now a `StatRecord` -- node's fourteen
  `Stats` values as doubles plus the kind, the ids flag and the Windows reparse tag, integers exact --
  which a sync stat writes into one reused `Float64Array` (as node's binding fills `statValues`, so no
  allocation per call) and an async stat resolves as a `Float64Array` over a buffer of its own; the JS
  side builds `Stats` / `BigIntStats` from it. A listing is two arrays, names and internalized kind
  names, so a plain `readdir` returns the names array as it is. The win is largest for `readdir` on a
  wide directory and for the sync stat forms, which now allocate nothing per call.
- **File streams open, read, write and close through `options.fs`, or the live `fs.*`, as node's
  do.** `fs.createReadStream` and `fs.createWriteStream` opened, read, wrote and closed natively, so
  neither an `options.fs` nor a function assigned over `fs.open`, `fs.read`, `fs.write`,
  `fs.writev`, `fs.fsync` or `fs.close` (graceful-fs, mock-fs and test spies patch them) was ever
  called. Each is now called with node's arguments -- `open` with the stream's path, flags and mode
  as given; `read` into a buffer of the stream's own at its position; node's write loop, with a
  short write followed by one for the rest -- and the `options.fs` methods a stream needs are
  checked to be functions, in node's order, with node's `ERR_INVALID_ARG_TYPE`. A stream whose
  `open` is its own (a subclass's, or one assigned) opens by calling it, and
  `ReadStream.prototype.open` / `WriteStream.prototype.open` are node's deprecated no-ops
  (DEP0135). `fs.writev` no longer calls a patched `fs.write`. A method the constructor does not
  check (`close` with `autoClose: false`, `fsync` with `flush` set later) that is missing fails
  the call with node's `TypeError`, where oam closed natively the descriptor `options.fs.open`
  handed out. (#356)
- **`fs.cpSync` of a directory whose destination cannot be made fails as node's does.** The error
  node's C++ raises has its keys in node's order (`errno`, `code`, `path`, `syscall`; oam put
  `syscall` before `path`), and on Windows it is MSVC's, as node's is: a file in the way is
  `errno` 183 with an empty `code` and "Cannot create a file when that file already exists.", a
  directory that may not be written in `errno` 5, `EIO`, "Access is denied.", a missing drive or a
  name too long `errno` 3, `ESRCH`, and a name Windows does not allow `errno` 123, `ENOPROTOOPT`
  -- where oam gave Linux's `ENOTDIR`, `EPERM` and `ENOENT`. `fs.cp`, `cpSync` and
  `fs.promises.cp` making a missing destination parent, and the async forms' `ENOTDIR` from
  `mkdir`, are now guarded by a conformance case. (#360)

### Added

- **Native `fs.watch` and `fs.promises.watch`.** Watchers sit on the OS's change notifications
  (ReadDirectoryChangesW and FSEvents through the `notify` crate; on Linux one inotify instance per
  run shared by every watcher) as node's do through libuv: `rename` and `change` events naming the
  entry relative to the watched directory, `recursive: true` on every platform, every `encoding`
  including `'buffer'`, `signal`, and `ref()` / `unref()` / `persistent: false` deciding whether a
  watcher keeps the process alive. `fs.promises.watch` is node's async generator, with `maxQueue`
  and `overflow`. Each event is its own callback, as in node: `process.nextTick` and the microtasks
  drain after every listener call, and a listener's throw is an uncaught exception. `fs.watch`
  polled the path's mtime every 100 ms: no `rename`, nothing from inside a directory, and a watcher
  that kept the process alive however it was unref'd. Conformance cases 421 and 422; what still
  differs is in docs/node-divergences.md.

### Added

- **`node:zlib` zstd, as Node v22.22.2 has it.** `zstdCompress`, `zstdCompressSync`,
  `zstdDecompress`, `zstdDecompressSync`, `createZstdCompress`, `createZstdDecompress`, the
  `ZstdCompress` / `ZstdDecompress` classes and the `ZSTD_*` constants, over libzstd 1.5.7
  -- the library Node links, through the `zstd-safe` binding -- so the compressed bytes,
  every `ZSTD_c_*` / `ZSTD_d_*` parameter and the `ZSTD_error_*` errors are Node's. The
  streams run Node's own `ZlibBase` loop, so its quirks match too: a one-shot decompress
  returns the first frame only, a frame cut short decodes without error, and `flush()`,
  `reset()` and `close()` work. `process.versions.zstd` reports the linked libzstd.
  Conformance cases 435-437.
- **`--trace-warnings` and `--trace-deprecation`, and node's hint that names them.** Both flags
  are accepted on the command line, in `NODE_OPTIONS` and in a `Worker`'s own `execArgv`, set
  `process.traceProcessWarnings` /
  `process.traceDeprecation`, and make the default warning printer write the warning's stack (for
  every warning, or for deprecations only) in place of its one-line text. Without them, the first
  warning printed carries node's one-time hint, `(Use \`oam --trace-warnings ...\` to show where
  the warning was created)`, naming the flag for its kind (#364).

## [0.19.0] - 2026-10-11

### Fixed

- **A nextTick batch interrupted by a handled throw waits for the pending timer, as Node's
  does.** The stranded-tick backstop drained a deferred batch at the first idle check --
  BEFORE the loop waited for an already-scheduled timer, so `process.nextTick(() => { throw })
  ; process.nextTick(...) ; setTimeout(...)` with an `uncaughtException` handler printed the
  batch's remainder ahead of the timer. The order was a race against the timer's deadline:
  it came out Node's way only when the 1 ms deadline happened to pass first, which is why
  the two `next_tick_*` e2e tests flaked on the mac and Windows release legs (release builds
  reproduced the wrong order ~6/7 locally, debug ~1/6). The backstop now runs only when no
  ref'd timer and no inflight op holds the loop open -- the condition
  `docs/design/nexttick-engine.md` already described -- so the batch drains at the next tick
  point (the timer's scope close), matching Node's probe-verified order on every delay and
  in the no-timer and unref-only cases.

### Added

- **`listen(path)` on the `tls`, `http`, `https` and `http2` servers (#282, #313).** A Windows
  named pipe or Unix domain socket, as Node's: the server binds it, `address()` answers
  the path (while listening and after close), a NUL in the path is the async EINVAL bind
  error, and a connection's address fields are undefined (`server.address()` on the
  socket answers `{}`), as Node leaves them. oam's native TLS and HTTP servers run on
  the pipe connection itself -- on Unix over the socket, on Windows through a tokio
  duplex whose pumps copy the bytes (a named pipe's halves share one handle and cannot
  join hyper directly). The CLIENT side of TLS over a pipe (`tls.connect({ path })`, an
  https request's `socketPath`) is still the recorded refusal -- the workaround is TLS
  over an existing socket. Conformance cases 388-391.

### Changed

- **The Rust toolchain is pinned exactly, not a floating `stable`, and every release leg
  asserts it.** `channel = "stable"` resolved per host at install time -- 1.96 on the
  Windows release box, 1.97 on the GCP builder -- so the v0.18.1 linux leg died on a lint
  the local gate had never run. `rust-toolchain.toml` now pins `1.99.0` and
  `scripts/lib/rust-pin.sh` checks it in ci-local preflight, remote prep and release
  preflight; `OAM_ALLOW_RUST_MISMATCH=1` is the ad-hoc escape hatch.

### Fixed

- **A pipe's TCP bind error keeps its real port, and a split HTTP/2 preface survives the
  pipe's consuming reads (#314).** Review follow-ups to `listen(path)`: the http/https/h2c
  pipe error handlers stamped `port: -1` on every bind failure (node reports `-1` only for
  a pipe's -- a TCP one keeps the port), and the h2c preface probe on a pipe discarded the
  bytes each retry consumed, so an `PRI * HTTP/2.0` preface split across pipe reads was
  never seen whole. The probe now accumulates across retries (a TCP peek re-reads the
  untouched head, so nothing changes there); cases 388-391 are byte-identical to node
  v22.22.2 after the fixes.
- **The installers refuse an install another `oam` would shadow on PATH (#315).** A
  v0.18.0+ install whose binary is not the `oam` the shell resolves delivers only a
  license file. `install.sh` and `install.ps1` now refuse before the download when an
  earlier PATH entry resolves an oam (install.sh only when its install dir is already a
  PATH entry, since its guidance prepends when missing; install.ps1 always, since it
  appends and appending cannot fix a shadow, and it catches `oam.cmd`/`oam.bat` via
  PATHEXT too).
  `OAM_SKIP_PATH_SHADOW=1` lifts the refusal into a loud warning for setups where an
  earlier oam (e.g. one bundled by another product) is intended. `install.ps1` also warns
  when a surviving `oam.exe.old` is left behind instead of leaving it silently.

## [0.18.1] - 2026-10-10

### Added

- **`os.getPriority([pid])` and `os.setPriority([pid,] priority)`.** Node's validation
  (`ERR_INVALID_ARG_TYPE` / `ERR_OUT_OF_RANGE`, priority in -20..19), libuv's mapping onto
  Windows priority classes and back, and `ERR_SYSTEM_ERROR` naming `uv_os_getpriority` /
  `uv_os_setpriority` for a pid with no process. Only `os.constants.priority` existed before, so
  a program importing either name failed to link. Conformance case 386.
- **`OAM_PRIORITY` and `OAM_ECOQOS`.** `OAM_PRIORITY=below_normal|idle|normal` (or 0..19)
  lowers oam's own scheduling priority at startup, before any thread exists, so its V8 and I/O
  threads and every child process run lowered. It never raises a process its launcher started
  lower. `OAM_ECOQOS=1` opts a Windows process into
  EcoQoS. Both are read by every `oam` in a fork tree, since children inherit the environment.
- **`--v8-pool-size` takes effect, and `OAM_V8_POOL_SIZE`.** The flag was accepted (it is in
  `process.allowedNodeEnvironmentFlags`) but ignored. It now sizes the V8 worker pool from argv
  or `NODE_OPTIONS` and round-trips through `process.execArgv`; `OAM_V8_POOL_SIZE` is the
  fallback (a value that is not an integer is a warning and keeps the default).

### Changed

- **The conformance differential's case pairs run on a worker pool instead of one at a time.**
  Every case binds its own ephemeral ports and carries no cross-case state, so pairs run
  `OAM_CONFORMANCE_JOBS`-at-a-time (default half the cores, 2-8); results are reassembled in
  sorted case order, so the scorecard and the gate's arithmetic do not depend on scheduling.
  Wall clock on windows-aarch64, full harness: 36 min from a cold build cache at 4 workers,
  against 34 min (warm build) and 52 min (busy box) for the serial runs -- most of the
  parallel run's time was the one-time cold build, and the case phase is now bounded by the
  slowest worker instead of the sum of the cases. A spawn failure is recorded per case and
  fails the run after the pool drains, as the serial loop's error did.
- **The differential's V8 bytecode cache can be reused across runs** by pointing
  `OAM_CONFORMANCE_CACHE_DIR` at a fixed path; the default stays a per-run temporary directory.
  Each case's cache lives in its own subdirectory named after the case, and cache blobs are
  written temp-file + rename, so a reader never observes a torn file.
- **The V8 platform worker pool defaults to 4 threads, not one per core.** Node's default.
  Every oam process started one V8 worker per core but one (11 on a 12-core machine), so a box
  running a dozen oam sidecars, hooks and test children held well over a hundred mostly idle
  V8 threads that all woke for each process's GC, and each short-lived `oam run` paid to create
  them. On machines with 5 or fewer cores nothing changes. `--v8-pool-size=0` or
  `OAM_V8_POOL_SIZE=0` restores the per-core pool.

- **`oam install` no longer offers or decodes transfer-level compression (#173).** reqwest's
  `gzip` / `deflate` features left the workspace dependency: `fetch` and `http.request` have
  decoded bodies themselves since #143, and the installer reads each tarball whole with
  `bytes()`. The registries oam resolves against serve tarballs identity-encoded whatever the
  offer (registry.npmjs.org, registry.yarnpkg.com, npmmirror's CDN -- measured), so the
  `accept-encoding: gzip, deflate` header the features added never paid for itself. Without
  them, a mirror or proxy that encodes a response unasked now fails loudly at the integrity
  check (sha512 mismatch) instead of being silently decoded -- pinned by install.rs's
  `tarball_download_sends_no_accept_encoding_and_passes_an_encoded_body_through`. The three
  packages that existed only for those features (`async-compression`, `compression-codecs`,
  `compression-core`) leave the dependency graph; `flate2` stays (node:zlib and tarball
  extraction). `process.versions` and oam_engine/build.rs's single-version checks are
  unchanged -- reqwest itself remains in the build for `oam install` and `oam self-update`.

### Fixed

- **The code cache's once-a-day sweep now actually runs once a day on Windows.** The sweep
  stamped `<cache>/bytecode/.sweep` by rewriting it as an empty file, and Rust's std emulates
  create+truncate on Windows as `OPEN_ALWAYS` plus a manual truncate, so rewriting a 0-byte
  file with 0 bytes never advanced its LastWriteTime. The stamp froze at its first write and
  every oam process that loaded a module started a background walk of the whole cache --
  measured on a Windows arm64 host with an 11,096-blob / 416 MB cache: a short hook script
  cost 234 ms CPU instead of ~47 ms, and a 3-second script 1,547 ms instead of ~47 ms. The
  stamp's mtime is now set explicitly after the write. Pinned by code_cache.rs's
  `sweep_advances_an_existing_empty_stamp`. POSIX `O_TRUNC` already marks the mtime for
  update, so Linux and macOS were not expected to be affected.

- **`util.promisify(exec)` and `util.promisify(execFile)` resolve `{ stdout, stderr }`, as node's
  do (#302).** Neither function had a `util.promisify.custom`, so the generic promisify resolved
  the stdout string alone (`const { stdout } = await ...` gave `undefined`) and rejected an
  error with no `stdout` / `stderr` on it. Both now carry node v22's custom form
  (non-enumerable, named after the original): it resolves `{ stdout, stderr }`, rejects the
  callback's error with `err.stdout` and `err.stderr` set, exposes the ChildProcess as
  `promise.child`, and keeps Buffers under `encoding: 'buffer'`. Pinned by conformance case
  385.

- **The conformance harness's worker pool is clippy-clean, keeps a FAIL block together, tells a
  deliberate watchdog from a slow host, and summarises the cases a stopped worker never ran.**
  The pool loop bound an index it never used, so `cargo clippy --workspace -- -D warnings` --
  the release gate's own step -- failed on main. A case's FAIL diagnostic was six separate
  prints from a worker thread, so with 2-8 workers another case's lines could land inside it
  and `--log-failed` output blamed the wrong divergence; it is now one print. Case 384 fires
  its watchdog on purpose on every host, which made the end-of-run "a host this slow" warning
  fire on every run; a case whose header says it cuts itself on purpose is now listed as such
  and the warning is kept for the accidental ones. A worker that stops on a harness error left
  every case it never pulled filed as "the worker ended without recording an outcome", the
  message reserved for a panic, and the bail listed hundreds of them ahead of the one real
  error; they are now "not run (a worker stopped on an earlier harness error)" and the bail
  prints the real errors first with a one-line count of the rest.
- **The e2e 302-hop guard for #155 measures the documented race instead of hard-asserting it
  away.** `pool::reuse_h1`'s 1 ms freshness wait is a heuristic, and a FIN that lands after it
  still doubles a GET hop about once in 2,000; the test asserted every one of 200 hops arrived
  exactly once, which went red on an idle box about one run in ten. It now runs the issue's
  own 1,000 hops and tolerates 3 doubled `/final` paths -- a 0.2% flake gate on, while a
  gate-off build (7-59 doubles per 1,000) still fails it -- with `ok` and the `/redir` count
  hard as before. The pool's unit tests dial the reserved host `gate.test`, which the
  published-URLs gate did not allowlist, so that gate was red on main too.

- **Fourteen tests for the branches the PRs since 0.18.0 left unpinned.** The pool's pop-first
  invariant (a concurrent checkout cannot take an entry another is ageing), the hand-written
  getaddrinfo rows and the unknown-code text fallback, the Windows priority-class raise ladder
  and the EcoQoS read-back, `--v8-pool-size` through `NODE_OPTIONS` and the merge with argv,
  the `OAM_V8_POOL_SIZE` warning contract and the bare flag's exit 9, an `http.request` with
  `family` / `hints` reaching the agent socket, `oam install` failing loudly on a tarball that
  arrives content-encoded, and the harness's worker-error, panic-payload, timeout and FAIL-block
  paths (the FAIL block is now assembled by `fail_block`, same bytes). One e2e is `#[ignore]`d
  with its numbers: the freshness gate for #155 does NOT hold over TLS -- 4-53 of 1,000 GET + 302
  hops doubled against a `tls.createServer` that answers then `end()`s, where node's client
  doubles none -- so the test is the contract for that fix. The Linux-only thread-count e2e for
  `--v8-pool-size` is compiled but was not run on the Windows box that wrote it.

- **The node-differential cases now fit their budgets (#211, remaining items).** Case 122 ran
  its refused-host-spellings lookups -- the slowest section and the one whose cost varies most
  between hosts -- before the 25-round "socket up at 'response'" check, so a slow host's
  watchdog cut the regression the case was written for; the lookups now run last. Cases 141,
  154 and 169 armed 50-55 s watchdogs that sat inside oam's measured runtime for them
  (51-90 s on windows-aarch64; node: 26-43 s), so ordinary box load flipped them -- two full
  runs failed on 154, and 141 and 169 once each; their budgets now clear the worst measured
  (80 s; 154: 120 s, with the harness ceiling at 150 s). New case 384 deliberately fires its
  own watchdog under both runtimes, pinning the `watchdog` scoring end to end: if it ever
  scores `pass`, `verdict()` is being read as just another stdout line again.
- **A request written onto a pooled connection whose server's FIN is in flight now waits it
  out instead of racing it (#155).** A server that answers and FINs in one callback (a 3xx
  then `end()`, a keep-alive timeout) leaves its FIN in flight while the next request is
  written; a `POST` -- never resent (RFC 9110 s9.2.2) -- failed outright, and an idempotent
  request's first copy was read into a close and sent again, so the server saw it twice where
  node's server sees it once. `pool::reuse_h1` now pops the idle entry first (no concurrent
  checkout can swap a younger one in mid-wait), sleeps until it is 1 ms old -- which parks the
  send task so the connection's dispatcher reads the FIN -- and drops the entry if it closed
  during the wait, dialing fresh instead of writing into the close. Measured against node on
  Windows arm64, release builds, 8 concurrent chains, gate off vs on: `GET` + `302` hop
  double-deliveries 7-59 per 1,000 -> 0, `POST` after a 200-then-FIN 6-31 failures ->
  0, `GET` after the same 0-26 double-deliveries -> 0, with the `POST` + `307` rows (already
  fixed by #271) unchanged at node's numbers. The cost: every checkout of a connection
  parked within 1 ms waits out the window -- 1,000 sequential fetches went 0.5 s -> 2.7 s
  (+2.2 ms per just-parked reuse), still under node's 4.3 s for the same run. Pinned by e2e
  `a_post_written_after_a_just_pooled_connections_fin_is_not_lost`; gate-off vs gate-on tables
  in `docs/node-divergences.md` entry 38.
- **Name resolution passes `AI_ADDRCONFIG` off Windows, as node's `net` does** (#165, closes
  divergence 37). `net.connect`, `tls.connect`, `http.request`, `fetch` and `dns.lookup` resolve
  through `getaddrinfo` with the hints node's would get -- the connect's default
  (`dns.ADDRCONFIG` off Windows, nothing on it) or the caller's `hints`, `ADDRCONFIG` included
  -- and the family, through the `dns-lookup` crate (no new `unsafe`). On a Linux or macOS
  host with no routable IPv6 address `localhost` resolves to `127.0.0.1` alone, as in node, so
  a refused connect there is one plain error, not an `AggregateError` over `::1` as well.
  `net.connect` and `http.request` validate `hints` and `family` as `dns.lookup` does, throwing
  `ERR_INVALID_ARG_TYPE` / `ERR_INVALID_ARG_VALUE` out of `connect()` or `http.request()`, and
  `dns.lookup` now validates `family` (`0`, `4`, `6`, `'IPv4'`, `'IPv6'`); an `http.request` with
  `hints` or `family` resolves with them, where it ignored both (`family: 6` to `localhost` tried
  `127.0.0.1` too); a resolver failure carries the code
  `getaddrinfo` returned (`EAI_AGAIN` for a temporary failure, libuv's `-3007` for
  `EAI_NODATA`) where `dns.lookup` reported every failure as `ENOTFOUND`. Conformance case 110
  prints the full `localhost` shape on every platform.
- **`oam mcp` answers `initialize` with a protocol version it supports.** It echoed whatever
  the client asked for, so a client asking for `2026-07-28` (or `1999-01-01`) was told oam
  speaks it. Now a supported request (`2025-11-25`, `2025-06-18`, `2025-03-26`, `2024-11-05`)
  is answered with itself and anything else, or no version at all, with `2025-11-25`, as the
  2025-11-25 lifecycle requires ("the server MUST respond with another protocol version it
  supports"). `server/discover` stays a plain `-32601` with the id echoed, the legacy signal a
  dual-era client falls back on. Unit tests pin each case; the `oam mcp` e2e test asks the
  built binary for `2026-07-28` and gets `2025-11-25`.
- **The N-API test addon no longer dereferences the pointer `napi_unwrap` hands back.**
  `counterGet` / `counterInc` in `crates/oam_napi_test_addon` cast that untyped pointer to
  `*mut i64` and read or wrote through it, so an object wrapped by another addon (or a pointer
  already reclaimed by the finalizer) would have been a type confusion or use-after-free. The
  counters now live in an addon-owned table keyed by the wrapped address; the pointer is only a
  lookup key, an unknown or finalized one yields null, and a failed `napi_wrap` no longer leaks
  the allocation. Clears CodeQL `rust/access-invalid-pointer` alerts #7 and #8.

## [0.18.0] - 2026-10-04

Two batches of node-compat work since 0.17.1 (0.17.2 was prepared but never released, so its
entries ship here, under "Prepared as 0.17.2" below): fs and Windows paths, permissions, fetch,
undici and its mocks, child processes, net over a pipe, web streams, zlib and http2. Each change
below is held to node v22.22.2 by a conformance case or an e2e test.

### Release signing

- **Every release from this one on is signed.** A release carries `RELEASE-MANIFEST` (the tag
  and the `SHA256SUMS` of its binaries) and `RELEASE-MANIFEST.sig`, an SSH signature by a
  committed release key. `release-keys/allowed_signers` names the keys and
  `release-keys/ranges` says which tags each may sign; a key is retired by closing its range,
  never by removing it, so the tags it signed keep verifying. By hand:
  `ssh-keygen -Y verify -f release-keys/allowed_signers -I oam-release-k1 -n oam-release -s RELEASE-MANIFEST.sig < RELEASE-MANIFEST`.
  There is no knob that skips the manifest signature: while key lines exist, a release that
  cannot sign does not ship. (#266, #267, #270, #272, #273, #277)
- **The installers verify the release before they download the binary.** `install.sh` and
  `install.ps1` embed the key list and ranges, fetch every asset from the resolved tag's own
  `/download/<tag>/`, and refuse a signature that does not verify, a manifest signed for
  another tag, a key outside its range, a missing manifest, and a binary whose SHA-256 is not
  the signed one -- the checksum comes from the manifest, not from an unsigned `SHA256SUMS`.
  Releases before 0.18.0 are checked against `release-keys/presigning-sums`, a committed table
  of the SHA-256 of each published `SHA256SUMS`; a pre-signing tag that is not in it is
  refused. Verifying needs `ssh-keygen` 8.1 or later (macOS and Linux ship it; on Windows the
  inbox OpenSSH client, which `install.ps1` finds in Sysnative, System32, then PATH). Without
  it the install fails and names the fix, unless `OAM_INSECURE_SKIP_SIGNATURE=1`, which
  installs with a loud warning and still never excuses a bad signature or a missing manifest.
  `OAM_INSTALL_BASE` now requires `OAM_VERSION`. (#267)
- **`oam self-update` verifies the same manifest natively**, with the trust root compiled in,
  instead of piping the installer into a shell: ed25519 and sk-ed25519 keys, namespace
  `oam-release`, the signed tag equal to the requested one and inside the key's range, and
  pre-signing tags against the pinned table. Without `--version` it refuses a release older
  than the running binary. The new binary is written to a temp file beside the old one, hashed
  against the manifest, renamed into place and smoked with `--version`; a failed smoke puts
  the old binary back. There is no override flag. `OAM_SELF_UPDATE_URL` is now an asset-base
  override that needs `--version` and still requires a valid signature. (#266)
- **The Windows binaries are Authenticode-signed** (Azure Artifact Signing, timestamped), and
  each is verified from disk twice before it ships: `signtool verify /pa`, then an independent
  PowerShell check of the signer, the timestamp and the chain. Binary signing that is not
  possible fails the release rather than shipping unsigned (`OAM_SIGN_REQUIRED=1` is the
  default); `OAM_SKIP_WIN_SIGN=1` and `OAM_SKIP_MAC_SIGN=1` ship a leg unsigned deliberately,
  with a warning. (#270, #273, #277)
- **The mac binaries are codesigned**: hardened runtime, identifier `org.oamjs.oam` and
  exactly the three entitlements V8's JIT needs, verified against a pinned identity and
  JIT-smoked on both architectures before they ship. The identity is oam's own certificate,
  not a Developer ID, so Gatekeeper still treats a download as it did; Developer ID plus
  notarization is the next step and changes nothing in the verify rules. (#272)

### Permissions

- **A child process started under `--permission` inherits the permission flags in
  NODE_OPTIONS, as node's does**, across spawn / exec / execFile (sync and async) and
  cluster.fork: process.execArgv's `--permission` / `--allow-*` entries are appended to the
  child's NODE_OPTIONS (an explicit `env` or process.env alike, for any program), unless the
  child's argv holds `--permission` or its NODE_OPTIONS already names it; fork() passes them
  on the command line. oam now reads those flags from NODE_OPTIONS, so an oam child runs
  under its parent's grants. Up to 0.17.1 a child started with none of them.
- **A port-scoped `--allow-net` entry now admits `fetch`, `http.request` / `https.request`,
  `undici.request` and `WebSocket` to that port**, as it already admitted `net.connect` /
  `tls.connect`: `--allow-net=example.com:443` admits `https://example.com/` and refuses
  `http://example.com/` and a redirect to `example.com:8443`. Up to 0.17.1 a port-scoped entry
  admitted no HTTP request at all. Bare-host entries are unchanged (any port). The
  `ERR_ACCESS_DENIED` `resource` for these requests -- including a refused redirect hop or
  `connect.lookup` answer -- now reads `host:port` (`"example.com:80"`) instead of the bare
  host, the same resource `net.connect` reports. (#188)
- **A pipe is a net resource named by its path.** Under `--permission`, `net.connect(path)`
  and a net server's `listen(path)` need unrestricted `--allow-net` or an absolute entry equal
  to the path -- never a host entry, a prefix or a relative entry -- and a pipe path that is a
  file (every Unix socket path; on Windows every path outside `\\<server>\pipe\`, and every
  path with a component made only of dots and spaces, such as `.` or `..`: Win32 opens
  `\\.\pipe\..\C:\x` as `\\.\C:\x`) needs `--allow-fs-read` and `--allow-fs-write` for it
  too, so a dial cannot report what the fs grant hides. A list fs grant in drive form
  (`C:\x`) never matches such a `\\`-prefixed spelling, so in practice only unrestricted
  `--allow-fs-read` and `--allow-fs-write` admit one. A relative path is resolved against the
  cwd of the moment, and that resolved path is what is dialled or bound. Refused with
  `ERR_ACCESS_DENIED` from the call.
  `http.request({ socketPath })` needs only the pipe's grant; a `fetch`, `undici.request` or
  `WebSocket` through undici's `Agent({ connect: { socketPath } })` (or any custom `connect`)
  is checked against its URL's `host:port` too, so it needs that host's grant as well. Node 22
  does not gate pipes; see docs/node-divergences.md, entry 50. (#219)
- **Permission matching on Windows now follows node's resolve.** An fs op is checked on the
  path it hands the OS -- resolved against the cwd and `\\?\`-prefixed, as node's binding
  computes it -- and the `ERR_ACCESS_DENIED` `resource` names that path (`\\?\C:\work\x`), as
  node's does. Names compare case-sensitively, as node's do (`c:\work\x` is not under a grant
  of `C:\work`); a trailing dot or space is part of a name (`allowed.\x` is not under
  `allowed`); a UNC path `\\srv\sh\x` and the rooted path `\srv\sh\x` are different paths; a
  grant of `\` or `/` is the cwd drive's root; and a `\\.\` device path, a `\\?\` path in
  neither drive nor UNC form, or a path judged as given that is spelt with the NT prefix
  `\??\` (the `mkdtemp` template, a pipe path, the child, worker and addon lists) matches no
  grant. `oam.readTextFile` is checked the same way. A scoped `permissions.query` of a
  child-process, worker or addon list grant matches the path as that permission's check does
  (a path under a granted directory is granted), where it used to compare the strings. (#275)

### Added

- **`net` over a pipe.** `net.connect({ path })`, `net.connect(path)`,
  `net.createConnection(path)`, `socket.connect(path)` and a net server's `listen(path)` /
  `listen({ path })` work over a Windows named pipe or a Unix domain socket, with node's
  events, `address()` shapes and errors (`connect ENOENT <path>`, `listen EADDRINUSE` with
  port -1, `EINVAL` for a name with a NUL byte in it), and `http.request({ socketPath })`
  rides on them, so `@playwright/mcp --isolated` now works on oam. On Windows a server keeps
  four instances waiting and a dial to a busy pipe waits with `WaitNamedPipeW`, as libuv's do
  (200 clients at once connect in tens of ms), and a write is done once the pipe has taken all
  but its last 64 KiB. TLS over a pipe, and `tls`, `http`, `https` and `http2` servers on one,
  are still refused with `ERR_FEATURE_UNAVAILABLE_ON_PLATFORM`; what else differs is in
  docs/node-divergences.md, entry 50. (#219)
- **http2 trailers work both ways, as in node.** A client stream emits `'trailers'` and
  supports `waitForTrailers`, `'wantTrailers'`, `sendTrailers()` and `sentTrailers`. Server
  streams, secure and cleartext, send trailers and receive a request's trailer section as
  `'trailers'` and as `req.trailers` / `req.rawTrailers`; the compatibility response's
  `setTrailer()` / `addTrailers()` are sent.
- **Buffer has node's `*Slice` and `*Write` codecs**: `asciiSlice`, `latin1Slice`,
  `utf8Slice`, `hexSlice`, `base64Slice`, `base64urlSlice`, `ucs2Slice`, `hexWrite`,
  `base64Write`, `base64urlWrite` and `ucs2Write`, with `asciiWrite`, `latin1Write` and
  `utf8Write` corrected to node's defaults and errors.
- **zlib streams have `params()`**, which changes a deflate or deflateRaw stream's level
  after a sync flush, and a one-shot given `info: true` returns `{ buffer, engine }`.
- **undici's `allowH2` opts a dispatcher into HTTP/2**: an `Agent`, `Pool` or `Client` with
  `allowH2` (or `connect.allowH2`, which wins over it) offers ALPN `http/1.1, h2` and speaks
  HTTP/2 to an origin that picks it, printing undici's `[UNDICI-H2]` warning once. (#176)
- **`http2.createSecureServer` with `allowHTTP1` has `closeIdleConnections()`**, and its
  `close()` closes idle HTTP/1.1 connections before it stops listening, as node's does, so a
  keep-alive client no longer holds `close()` open. (#176)
- **A `http-keepalive-latency` benchmark case**, sequential requests over one kept-alive
  connection. (#183)
- **undici's `MockAgent`, `MockPool` and `MockClient` work** (#206): interceptors answer
  `fetch`, `undici.fetch`, `undici.request`, a dispatcher's `request()` and `WebSocket` from
  memory -- `reply()` (object, callback, data callback, trailers), `replyWithError()`,
  `times()`, `persist()`, `delay()`, the path / method / body / header / query matchers,
  `enableNetConnect()` / `disableNetConnect()`, `pendingInterceptors()`,
  `assertNoPendingInterceptors()` and `mockErrors` -- for http and https origins and across
  redirect hops, as undici 6.29.0 does. They fail closed: nothing reaches the network unless no
  interceptor matches and net connect allows the origin.
- **`node:_http_common` and node's other legacy `_http_*` / `_tls_*` modules** (#207), with
  node's `HTTPParser`, so nock 14 loads and intercepts `http.request`, `https.request`,
  `new http.ClientRequest()` and `fetch` as under node.

### Changed

- **An explicit `env` replaces the child's environment, as node's does.** `spawn`,
  `spawnSync`, `exec`, `execSync`, `execFile`, `execFileSync` and `fork` start the child with
  exactly the given pairs; on Windows, as libuv does, `HOMEDRIVE`, `HOMEPATH`, `LOGONSERVER`,
  `PATH`, `SYSTEMDRIVE`, `SYSTEMROOT`, `TEMP`, `USERDOMAIN`, `USERNAME`, `USERPROFILE` and
  `WINDIR` are added from the parent when the given env has no variable of that name in any
  case. Without `env` the child gets `process.env` as it stands at the call, so a variable
  deleted from `process.env` is no longer inherited, and `cluster.fork(env)` gives the worker
  `{ ...process.env, ...env }`. Previously the pairs were laid over the environment oam
  started with. The pairs are built as node builds them: inherited keys count, an `undefined`
  value is left out, of names differing only in case on Windows the first in sort order is
  kept, and `NODE_V8_COVERAGE` is carried over. Under `--permission`, a child's environment
  holds only what `--allow-env` shows in `process.env` (docs/node-divergences.md).
- **`net.createServer({ allowHalfOpen: true })` hands the option to the sockets it accepts**,
  as node's does, and such a socket whose `'end'` listener writes and ends emits that write's
  callback and `'error'` before `'close'`. (#219)
- **A server's listen error has node's key order** (`code`, `errno`, `syscall`, `address`,
  `port`); it was built `errno` first, like a connect error. (#219)
- **`fetch`, `undici.request` and `https.request` speak HTTP/1.1 to an https origin, as
  node's do.** undici's connector offers ALPN `http/1.1` alone and `https.request` offers no
  ALPN, so an h2-capable server answers them over HTTP/1.1; up to 0.17.1 every origin was
  offered `h2, http/1.1`, and `fetch` (and `https.request`, whose `res.httpVersion` still said
  `1.1`) was served over HTTP/2. A dispatcher with `allowH2` opts back in. (#176)
- **`http2.createServer` serves through the same stream implementation as
  `createSecureServer`**, so it sends and receives trailers and an h2c request body streams
  as a secure one does. Its streams still have no `session`.
- **`undici.request` sends the caller's headers and returns the body undecoded**, as undici's
  `request()` does: no `accept`, `user-agent` or `accept-encoding` is added, and a gzip
  response comes back as gzip bytes with its `content-encoding` and `content-length`. (#206)
- **`undici.request` and `undici.fetch` never go through a replaced `globalThis.fetch`**, as
  node's undici sends its requests itself. (#206)
- **A `Pool` or `Client`, mocked or not, sends every request and every redirect hop to its own
  origin**, with that origin as `host`, as undici's do. (#206)
- **`WebSocket` sends its handshake through the undici dispatcher** (`WebSocketInit.dispatcher`,
  else the global one), so a MockAgent, an Agent's connector or a Pool's origin applies to it, and
  the init's `protocols` and `headers` are honoured. (#206)

### Fixed

- **An http2 body of a window or more, left unread and then resumed, reaches its end off
  Windows.** Node's default stream highWaterMark is 64 KiB everywhere but Windows, more than the
  65535-byte stream window oam fills while JS does not read, so `resume()` asked for more with a
  window's worth still buffered and oam's held-back bytes were not pushed: the stream stayed
  `reading` and was never asked again, and the body never ended (nor its trailers came). The
  held bytes now go in whenever the stream asks.
- **`fs.readdir` lists entries in node's order on macOS and Linux: sorted by name.** Node's
  readdir is libuv's scandir, which sorts on unix; oam handed back the file system's own order,
  which APFS and ext4 do not keep sorted. `opendir`'s Dir still reads in the file system's order,
  as node's does through uv_fs_readdir. Windows is unchanged. `fs.cp` and `cpSync` walk a
  directory in the file system's order, as node's do through opendir and std::filesystem.
- **`dns.lookup` hands its `hints` to getaddrinfo.** `V4MAPPED` and `ALL` were emulated over an
  unflagged lookup, so the answer was not always the platform resolver's: glibc answers a name
  with both `::1` and `127.0.0.1` in /etc/hosts under `V4MAPPED | ALL` with the mapped address
  twice, and node reports both. `ADDRCONFIG` is still not applied.
- **`net.Socket`'s write highWaterMark is node's default for the platform: 16 KiB on Windows,
  64 KiB elsewhere.** It was 16 KiB everywhere, so on macOS and Linux a socket's `write()`
  returned false, and 'drain' followed, four times earlier than node's, and `writableNeedDrain`
  read true where node's reads false.
- **`fs.cpSync` of a directory without `recursive` names the directory as node's message does
  off Windows: with a trailing `/` unless it already ends in one.**
- **The type-check daemon's tsgo runs without a console window on Windows.** The daemon has
  no console (it is spawned detached), so each tsgo it ran — the version probe and every
  check — got a new console with a visible window, which flashed on the desktop and, under
  load, could fail to come up at all: a console process whose console cannot be set up exits
  with STATUS_DLL_INIT_FAILED (0xC0000142) before it runs, which is how this release's own
  gate lost a probe and read the empty `--version` as an impostor tsgo. tsgo and the taskkill
  that ends it are now spawned with CREATE_NO_WINDOW from the daemon. A one-shot check from a
  terminal still shares that terminal's console, and with it its Ctrl+C.
- **A `worker_threads` Worker's `env` option is applied, as node's is.** Without it (or
  with `null` or `process.env`) the worker starts with a copy of its creator's `process.env`
  as it stands, assignments and deletions included; with an object, exactly that object's
  own entries, each stringified; with `SHARE_ENV`, its creator's environment, shared both
  ways. Any other value throws `ERR_INVALID_ARG_TYPE`. A worker's own copy is
  case-sensitive, as node's is. Previously every worker started from the environment oam
  started with, whatever the option said.
- **A `fork()`ed child's messages sent just before `process.disconnect()` reach the parent**,
  as node's do; when the channel was still opening, disconnecting dropped them.
- **A `fork()`ed child has its IPC channel under any `--allow-env`**, and takes the channel's
  variable out of its environment as node's child does with `NODE_CHANNEL_FD`. It read the
  port through `process.env`, so under a list `--allow-env` that did not name it
  `process.send` was undefined; and the variable stayed in `process.env`, so the child's own
  children inherited it.
- **A NUL in a child's `env` throws `ERR_INVALID_ARG_VALUE` synchronously**, as node's
  does: a name, or a string value, holding one is refused by every `child_process` entry
  point before anything starts ("The property 'options.env['FOO']' must be a string without
  null bytes"); it reached the spawn and failed `EINVAL`. A value that is not a string is
  stringified and cut at its first NUL, as the C string node hands libuv is.
- **`process.execve(file)` defaults `args` to `[]` and `env` to `process.env`**, as node's
  does (`process.execve.length` is 1); it threw `ERR_INVALID_ARG_TYPE` for the missing `args`.
- **A zone-id host or `lookup` answer is matched against `--allow-net` as an address and a
  zone, never as text,** by `fetch`, `http.request`, `net.connect` and `tls.connect` alike.
  The zone is all of the host's text after `%`, as node's `net.isIP` reads it
  (`fe80::1%1:8080` is the address `fe80::1` with the zone `1:8080`), and an entry ending in
  `:` and digits is always port-scoped: `--allow-net=fe80::1%1:8080` admits `fe80::1%1` (or
  any spelling of that address) on port 8080. A host-only entry (`fe80::1%1`) admits its
  zone on any port, for a raw socket as for a fetch, and text with a `%` that is not a
  zone-id address matches no entry.
- **`process.loadEnvFile()` with no path named the resolved `.env` on Windows**
  (`open 'C:\cwd\.env'`); node's binding opens its own `.env` untouched and says `open '.env'`.
  A path given to it is still checked and named as fs names it: `loadEnvFile(42)` is
  `ERR_INVALID_ARG_TYPE` instead of a read of descriptor 42, `loadEnvFile("")` fails on `''`
  instead of reading `.env`, any failure to open is node's `ENOENT`, and a directory -- given,
  or a `.env` that is one -- is node's `Contents of '<path>' should be a valid string.` on
  Windows, Linux and macOS alike (refs #167)
- **On Linux and macOS, `fs.readFile` / `readFileSync` / `fs.promises.readFile` of a directory
  failed `EISDIR: ..., open '<path>'`**; open(2) admits a directory there, so the failure is the
  read's, and it is node's `EISDIR: illegal operation on a directory, read` with no path, as it
  already was on Windows.
- **`fs.readFile` / `writeFile` / `appendFile` (sync, callback and promise) reported a failed
  read or write as a failed open**: `EBUSY: resource busy or locked, open '<path>'` for a file
  another process has a region of locked, where node says `EBUSY: resource busy or locked, read`
  (or `write`) with no path. Only a failed open now names `open` and the path, as in node -- and
  `process.loadEnvFile()` of such a file is node's `Contents of '<path>' should be a valid
  string.` instead of a false `ENOENT`.
- **`fs.readFile` (sync, utf8 sync, callback and promise) read a file in growing chunks** after the
  open / read split above: 9 read calls for 1 MiB, 15 for 64 MiB. It reads into the room
  reserved from its fstat again, as `std::fs::read` does: one read of the whole file plus one
  short EOF probe, whatever the size.
- **Over HTTP/2, a `fetch` response header value kept the whitespace around it**; it is trimmed
  as it is over HTTP/1, and the trimming is recorded as a divergence from node's `fetch`, which
  keeps trailing whitespace. (#182)
- **`http2.connect` reported a server's GOAWAY as an EOF.** The session emits `'goaway'` with
  the frame's code, last stream id and debug data, as node does; a stream above the last
  stream id closes with `NGHTTP2_REFUSED_STREAM`, and a stream the server answered reads to
  its end. (#185)
- **A closed `http2.connect` session sent its GOAWAY only once its streams were done.** It
  sends it as soon as it is closed, as node's does, so a session closed by a server's GOAWAY
  now closes, and lets the process exit, when the server keeps the connection open. (#185)
- **A `fetch` redirect hop that cannot be resent went out on the connection its 3xx came
  on.** A `POST` after a `307` / `308` (or any non-idempotent hop) dials a connection of its
  own, so it no longer fails when the server closes the connection behind the redirect. (#155)
- **undici accepted a non-boolean `allowH2`.** A dispatcher refuses one with
  `InvalidArgumentError` (`allowH2 must be a valid boolean value`), as undici's `Client`
  does; `allowH2: 'yes'` used to turn HTTP/2 on. (#176)
- **undici from npm hung** on `await WebAssembly.compile()`. V8's foreground tasks (async
  WebAssembly compile and instantiate, `Atomics.waitAsync`, `FinalizationRegistry` cleanup,
  GC idle tasks) now run on the isolate's event loop, on the main thread and in workers, so
  undici from npm works. A worker isolate created at a just-freed isolate's address no
  longer inherits that isolate's closed task queue.
- **Buffer hex decoding read whole UTF-16 code units**; it reads each one's low byte and
  stops at the first non-hex pair, as node does, so `Buffer.from('١٢', 'hex')` is
  `<Buffer ab>`.
- **`fs.mkdtemp`, `mkdtempSync` and `fs.promises.mkdtemp` made a timestamped name under the
  temp directory.** They make node's names -- the prefix as given, relative to the cwd, plus
  six random `[A-Za-z0-9]` characters -- honor the `encoding` option, check their arguments,
  warn once on a template ending in X, and name node's path when they fail. On macOS the
  template's whole run of trailing X's is replaced, as Darwin's `mkdtemp(3)` does under node,
  and an empty prefix is accepted.
- **Under `--permission`, a relative fs path is resolved against the cwd before it is
  matched against a grant**, and a relative `--allow-fs-read` / `--allow-fs-write` entry is
  resolved at startup, as node does. `writeFileSync("out.txt")`, `mkdirSync` and
  `mkdtempSync` on a relative path were refused under a grant of the cwd.
- **A `ReadableStream` pulled before `start()` settled, and `WritableStream` /
  `TransformStream` ignored their strategies.** The initial pull waits for `start()`, the
  writable side honors `desiredSize`, `ready` and backpressure, and a transform waits for a
  read, all in node's order. `type: 'bytes'` streams default to a high-water mark of 0 and
  count bytes, so fetch, `Response` and `Blob` bodies no longer read ahead.
- **Web streams refused, released and piped differently from node's.** A byte stream refuses
  a chunk that is not a view without erroring the stream and hands readers `Uint8Array`s;
  the constructors validate `type` and `size` in node's order; `reader.releaseLock()`
  rejects `reader.closed` and pending reads with node's coded errors; and `pipeTo()` fills
  the destination's high-water mark and honors `options.signal`, so an idle source with an
  erroring destination no longer hangs.
- **zlib accepted options node refuses.** Every constructor and one-shot validates `level`,
  `memLevel`, `strategy`, `windowBits`, `chunkSize`, `dictionary` and the brotli params as
  node does (`deflateSync('x', { level: 99 })` throws `ERR_OUT_OF_RANGE`). The streams take
  node's Transform options (`highWaterMark`, `autoDestroy`, `emitClose`, `allowHalfOpen`,
  `signal`), and the one-shot forms check them and honor a signal. `DeflateRaw` turns
  `windowBits` 8 into 9, and a zlib class called without `new` returns a stream.
- **A zlib header differed from node's at some levels**; it matches at every level, so a
  level-0 stream raised by `params()` inflates under node with options. A callback form
  given `null` or `undefined` runs on empty input, and a brotli stream cut short fails with
  `Z_BUF_ERROR`.
- **http2 trailer values could hang a response.** They reach the peer as node's do (one byte
  per UTF-16 unit, a field the receiving nghttp2 would drop left out, an empty section for
  one with a NUL byte). `'trailers'` fires whether or not the body ahead of it is read, a
  server stream that has responded stays open for the rest of the request, and a client's
  `'wantTrailers'` / `'finish'` order matches node's.
- **A `connect.lookup` dispatcher opened and closed a connection for every fetch** (#179),
  calling the hook each time, so a sustained hooked loop could use up the ephemeral port
  range (`EADDRINUSE`). Each `Agent` now pools its connections across its fetches, as
  undici's does: the hook is called once per connection opened, not once per fetch; a
  pooled connection carries requests only for the origin it was opened to, and never for
  another `Agent`; an idle HTTP/1.1 connection closes 90 s after its last response, and all
  of them close on `close()`, `destroy()` (in the same tick as a fetch, too) or the
  `Agent`'s collection. A redirect to the same origin reuses the 3xx's connection every
  time, and each request dials with its own happy-eyeballs attempt timeout rather than one
  another request had set.
- **A `connect.lookup` hook's second callback was ignored** (#169). An error, a throw or an
  answer node's address rules refuse, arriving after the hook answered, fails the fetch
  with that error as the `cause` while the connection is still being made, as node's
  `net` does; once it is made, later callbacks are ignored. A second answer that passes
  the rules is still ignored, where node fails the socket with a platform error.
- **A closed or destroyed undici dispatcher refuses every request** with
  `ClientDestroyedError` instead of sending it. (#206)
- **Any dispatcher another undici copy put in the global slot fails oam's `fetch`** with
  `NotSupportedError` instead of being bypassed; the plain `Agent` every copy installs at load is
  recognised by identity, so a terser-minified undici no longer fails every fetch. (#206)
- **A mock reply's own `content-length` or `transfer-encoding` no longer frames its body**, and a
  request with a large head or a method llhttp does not know is matched, as undici's mock does. (#206)
- **A builtin oam does not implement** (`_stream_wrap`, `wasi`, `node:sqlite`) says so, instead
  of "cannot find package ... is it installed?". (#207)
- **A standalone `ServerResponse`** (built over a request object, given a socket with
  `assignSocket()`) writes the whole HTTP/1.1 message to its socket, as node's does;
  `new IncomingMessage(socket)` keeps that socket. (#207)
- **An `http.request` whose agent hands back a socket with its own `write()`** is written while
  that socket is still connecting, as in node; a handle-less `net.Socket`'s `resume()` no longer
  fails with "read handle 0 is gone". (#207)
- **A `ClientRequest` is an `http.OutgoingMessage`**, `ClientRequest.apply(this, args)` builds
  the caller's object, and `http.METHODS` lists every method node's parser takes. (#207)
- **A fetch over a `connect` function's socket destroyed before it answered hung**; it fails with
  the socket's error. (#206)
- **The npm undici's `fetch` never delivered a MockAgent reply's body**: `stream.finished()` on a
  web stream threw and `performance.markResourceTiming()` was missing. (#206)
- **`console.table`** draws node's table, and a `new Console()` has `table()`.
- **On Windows, fs paths reach the OS namespaced, as node's do.** Every path-taking fs op,
  the module loader (`require`, `import`, the main entry), `oam.readTextFile` and native addon
  loading hand the OS `path.toNamespacedPath(p)` -- resolved against the cwd and prefixed
  `\\?\` -- so Win32 path normalisation no longer applies: `readFileSync("sub/")` fails
  `EISDIR` `read`; `NUL`, `COM1` and a name with a trailing dot or space (`.env.`, `.env `)
  are files that do not exist (`ENOENT`) rather than the device or `.env`;
  `writeFileSync("g.txt.")` creates `g.txt.`; `require("./mod.js.")` fails
  `MODULE_NOT_FOUND`. A symlink's target is stored as node stores it, and whether it is a
  directory link is decided by the target beside the link, not in the cwd. Errors name the
  path with the prefix taken off and never resolved again (`mkdirSync("C:\\")` says `'C:\'`,
  not `'C:'`), a patched `process.cwd` no longer changes any fs error, `realpath` and
  `readlink` show a UNC result as `\\srv\sh\x` (and `realpathSync` / callback `realpath` a
  share root as `\\srv\sh\`, as node's JS realpath does), and an ESM specifier gets the URL
  parser's clean-up (`import("./x.mjs ")` loads `x.mjs`, as on node). A script that relied on that
  normalisation now fails as it does under node. `process.chdir` records the new cwd in its
  drive's `=X:` variable, as libuv's `uv_chdir` does, so a drive-relative `C:name` resolves
  against the directory the process moved to, not the one it was launched in. A drive or
  share root (`C:\`, `\`, `/`, `\\srv\sh`) fails as a directory, not `ENOENT`:
  `readFileSync` fails `EISDIR` `read` and `writeFileSync`, `appendFileSync` and a write
  `openSync` fail `EPERM` naming the root. `fs.symlink`, `fs.symlinkSync` and
  `fs.promises.symlink` honour the type argument: only a missing (non-string) type probes the
  target, so `'file'` makes a file link even to a directory, `'dir'` a directory link to a
  target not made yet, `'junction'` stores the target resolved against the link's parent, and
  a type outside the three fails `ERR_FS_INVALID_SYMLINK_TYPE`. `new Worker(path)` tests that
  its script exists on the namespaced path its loader opens, so `w.js.` is not found when only
  `w.js` exists, and a file named `x.js.` is. (#275)
- **`fs.copyFile`, `copyFileSync` and `fs.promises.copyFile` honour their mode.**
  `COPYFILE_EXCL` fails `EEXIST` instead of overwriting the destination; a mode that is not
  a number, not finite or outside 0..7 fails `ERR_INVALID_ARG_TYPE` / `ERR_OUT_OF_RANGE`
  before any path is touched; on Windows `COPYFILE_FICLONE_FORCE` fails `ENOSYS`, as node's
  does.
- **`fs.cpSync`, `fs.cp` and `fs.promises.cp` refuse a copy onto itself or into itself**
  with node's `ERR_FS_CP_EINVAL` ("src and dest cannot be the same", "... to a subdirectory
  of self ..."), before anything is made. A directory copied into its own subdirectory used to
  be copied until the process was killed, and a file copied onto itself failed `EBUSY`.
- **`fs.readdirSync`, `fs.readdir` and `fs.promises.readdir` honour `recursive`**: every entry
  below the directory, named relative to it (or as Dirents with their `parentPath`), in node's
  order -- breadth first for the sync and callback forms, the last directory found first for
  the promise one. They used to list the top level only.
- **`fs.watch` of a path that is not there throws** `ENOENT: no such file or directory, watch
  '<path>'` at the call, with `path` and `filename` set, as node's does, instead of handing
  back a watcher that never fires.
- **`OAM-TEST0003` carries `"origin": "test"`**, the origin of its code family; it was emitted
  with `"origin": "runtime"`. Every `OAM-RT*` code keeps `runtime`.
- **The MCP server's `oam_explain` knows every code oam emits.** `OAM-TS0002`, `OAM-TS0005`
  through `OAM-TS0007`, `OAM-PKG0000` through `OAM-PKG0009` and `OAM-NATIVE0001` /
  `OAM-NATIVE0002` were answered "unknown code", and the unknown-code text called
  `OAM-TEST*` / `OAM-PKG*` "reserved" although both are emitted. A test now fails if any
  code under `crates/*/src` has no explanation. The `OAM-MOD0002` and `OAM-MOD0006` explanations
  no longer say the installer is unshipped or that `http` and `child_process` are missing; they
  now describe every case each code covers. `OAM-RT0001` is no longer explained as an uncaught
  exception only (it is the catch-all, engine failures included), and `OAM-RT0004` names its
  second case, an inspector that could not start.
- **The README no longer describes typed repair plans, sandboxed-by-default execution or
  checkpoint/fork as shipped.** The ODIF `repairs` field is reserved and populated by nothing
  yet, the permission model is opt-in (`--permission`; the default is all-granted, as in
  node), and `oam.fork()` is a pre-warmed isolate pool. The ODIF origin list now includes
  `resolve`.

### Performance

- **The web streams' queues dequeue in O(1)**, so a producer that runs ahead no longer goes
  quadratic: 300k unawaited writes take 0.2 s instead of 143 s.

### Prepared as 0.17.2

Node-compat depth across fetch, the http client and server, net, dns, undici, zlib, fs and
node's coded errors: each change below is held to node v22.22.2 by a conformance case or an
e2e test.

#### Added

- **`undici` exports `ProxyAgent` and `EnvHttpProxyAgent`** (#208). The dispatch-only names
  (`RetryAgent`, `connect()`, `pipeline()`, ...) now export and refuse with
  `NotSupportedError`, where they were missing.
- **`socket.resetAndDestroy()` closes a connection with a reset, as node's does**, on a
  `net.Socket`, on an http server's `req.socket` and on an `http.request`'s `req.socket`; a
  `tls.TLSSocket` throws node's `ERR_INVALID_HANDLE_TYPE`.
- **An http server response has `setHeaders()` and `addTrailers()`**, and `appendHeader()`
  works where it used to write into the headers object's properties and lose them;
  `http.validateHeaderName` / `validateHeaderValue` throw node's coded errors.
- **A fetched `Response` has `blob()`, and `Request` is undici's constructor** (#154, #180):
  every attribute and check node's has, and `fetch(request)` sends the `Request` itself.
- **An http server's `req.httpVersion`, `httpVersionMajor` and `httpVersionMinor`** report
  the request's version, and an HTTP/1.0 request's response head goes out as node's does.
- **`net.Socket` has `writableEnded` and `writableFinished`**, and `fs.realpath.native` exists.
- **The MCP sidecar gate hosts the yaw-mcp broker itself**, as `oam run --no-check` (#221).

#### Changed

- **`listen()` without a host binds dual-stack `::`, as node's does** (#172). An http, https
  or http2 server started without a host used to bind `127.0.0.1` and was unreachable from
  any other machine; net and tls bound `0.0.0.0`. `::` now takes IPv4 clients unless
  `ipv6Only`, `address()` reports the family bound, and listen errors have node's shape.
  Under `--permission`, such a listen is checked as `0.0.0.0:<port>` on every server kind.

#### Fixed

- **fetch, `Request` and `Response` stringified a `Blob`, `File`, `FormData`,
  `URLSearchParams` or `ReadableStream` body** (#154). They send it as itself with node's
  content-type; streamed uploads, a failing upload source and a redirected streamed body
  behave as in node.
- **fetch ignored a `Request` passed as its input** (#180); its body, signal and redirect
  mode now apply, with `init` winning, as in node.
- **A request header value went out as UTF-8** (#174). fetch and `http.request` send one
  byte per code point and refuse, with node's errors, the values node refuses; oam's
  servers read a request header value the same way.
- **`Headers` iterated in insertion order** (#175). It iterates sorted by name, as node's
  does; `oam.serve` still writes headers in the order the handler set them.
- **fetch did not send undici's default request headers** (#178): `connection`,
  `accept-language`, `sec-fetch-mode`, its `accept-encoding`, `content-length: 0` on an
  empty POST/PUT/PATCH, and the cache mode's `pragma` / `cache-control`.
- **`response.type` was undefined, and an unparseable `Location` failed with a plain
  error** (#149). It is `'basic'`, and the cause is node's `ERR_INVALID_URL` TypeError.
- **A fetch undici refuses to dispatch rejected with an uncoded cause** (#177). The cause is
  an undici error class with its `code` and brands, shared with the `undici` shim, so
  `instanceof undici.errors.X` holds.
- **A failed body read rejected with `fetch: body read failed: error decoding response
  body`** (#168). It rejects with `TypeError: terminated` and a cause naming what failed:
  `SocketError`, `ResponseContentLengthMismatchError`, `HTTPParserError`, a reset or a
  decoder's error.
- **fetch had no connect timeout** (#157). A connect over 10 s fails with undici's
  `ConnectTimeoutError`, or at the dispatcher's own `connectTimeout`, through an Agent
  `factory` too.
- **An abort before the response head left the request on the wire** (#158). The connection
  is closed at the abort, for fetch and for a destroyed `http.request`; an abort while fetch
  reads a Blob body is honoured at once too. An `http.request` destroyed while its upload
  waits on a full channel reaches the server aborted, where the server read a complete
  request with a truncated body.
- **`statusText` and `statusMessage` were the canonical reason phrase** (#160), whatever the
  server sent; they are the phrase on the wire.
- **`http.request` on oam's own transport added `accept`, `user-agent` and
  `accept-encoding`, and decoded a compressed body behind the caller's back** (#148). It
  sends the caller's headers and hands the body over undecoded, as node's does.
- **Over an agent's socket a `write()` callback ran before the socket wrote the chunk**
  (#191), a request destroyed on `'connect'` emitted no `'finish'` (#192), and the
  keep-alive hand-back could wait on the request's size (#190).
- **`http.request` emitted `'finish'` for a request that never had a connection** (#193).
- **The request's `'close'` came before the response's on a connection that is not kept**
  (#194). A response left before its `'end'` still closes its request, nothing finishes
  after a failure, and a late `destroy(err)` is silent.
- **An http server response took any header** and sent a CR/LF value as a 500 `oam: bad
  response spec`. It refuses what node refuses, with node's coded errors, and writes a
  header value's bytes as node does; a second `writeHead()` throws `ERR_HTTP_HEADERS_SENT`
  where it could crash the server's IO thread.
- **A port that is not a port was dialled or bound as another one** (#163); it throws
  `ERR_SOCKET_BAD_PORT`.
- **`socket.destroy()` emitted `'error'` and `'close'` inside the call** (#189); they come
  on a later tick.
- **A socket `'error'` nobody listened for was an unhandled rejection** (#164); it is an
  uncaught exception, and a write after the peer's FIN fails with node's EPIPE.
- **`socket.end()` right after `socket.write()` did not ask for the FIN in the same turn**
  (#156); it is queued behind the write, and `end()` and `write()` before and after
  `destroy()` call back with node's errors.
- **A WebSocket's refused loopback connect took about 2 s per address on Windows** (#161),
  and a failed connect dispatches node's `ErrorEvent`.
- **An IPv6 address with a zone id was refused or lost its zone** (#162). From a lookup
  hook, undici's `connect.lookup` or a literal host it is dialled with its scope, and errors
  name it with the zone.
- **`dns.ADDRCONFIG`, `dns.V4MAPPED` and `dns.ALL` were `0`** (refs #165). They are the
  platform's `AI_*` values, `hints` is validated, and `V4MAPPED` applies to a family-6
  lookup; `AI_ADDRCONFIG` is still not passed to the resolver.
- **undici `request()` ignored `headersTimeout` and `bodyTimeout`** (#218). It raises
  `UND_ERR_HEADERS_TIMEOUT` / `UND_ERR_BODY_TIMEOUT`, starting the headers timer once a
  connection has the request, and reads an Agent factory's dispatcher's own limits. Both
  lapse on undici's 499 ms FastTimer clock, as node's do (anything up to 998 ms after about
  1 s), and their errors carry `message` as an own key.
- **`undici.request` rejected with `TypeError: fetch failed`**; it rejects with the error
  itself, and its body fails with undici's error rather than fetch's `terminated`.
- **Coded errors had the wrong shape** (#170, #171): `code` and `message` are in node's order
  on a per-code prototype, the stack header is node's `Name [CODE]: message`, `new URL()`
  throws `ERR_INVALID_URL`, and an unhandled `emit('error')` throws `ERR_UNHANDLED_ERROR`.
- **`AbortSignal.timeout()` kept the process alive** (#181); it is unref'd, uses node's
  reason and validates its delay.
- **Web streams ran `start()` late** (#222), so the MCP SDK's streamable-HTTP server
  transport hung on `initialize`; `start()` runs synchronously in the constructor.
- **`OAM_MAX_HEAP_MB=0` or an unusable value removed the heap cap** (#223); it keeps the
  default cap and warns once.
- **`zlib.createUnzip()` misread gzip split across writes** (#195), and **inflate decoded a
  reference before the output's start to zeros and stopped at the first gzip member**
  (#166). Errors carry node's `code` / `errno` and zlib's message, and a truncated stream is
  `Z_BUF_ERROR` `unexpected end of file`.
- **fs path arguments were stringified instead of type-checked** (refs #167):
  `fs.writeFileSync(fd, data)` created a file named after the descriptor. Paths are checked
  as node's are, descriptors and FileHandles are accepted, Windows errors name the resolved
  path, and two-path errors carry `dest`.
- **A bad file descriptor was `EBADF` from the native side**; it is node's
  `ERR_OUT_OF_RANGE` / `ERR_INVALID_ARG_TYPE`, checked where node checks it.
- **A closed `fs.watchFile` / `fs.watch` poller could fire once more** from a stat already in
  flight.
- **`oam daemon status` gave no reason for a spawn the client gave up on** (#209).
- **The conformance harness compared a case both runtimes cut short with their own
  watchdog** (#211); it is scored `watchdog` and warned about, never `pass`.
- **The linux release leg skipped its disk-headroom check in silence** (#210), and **an
  incomplete sidecar matrix did not say which rows it skipped** (#220); both warn by name.
- **Concurrent fs operations on one descriptor failed `EBADF` for all but the first**; they all
  reach it. Descriptors 0-2 are the process's stdin, stdout and stderr for every fd call, on
  unix closing stdout or stderr closes it for oam's own writes too, and `fs.close` of a
  descriptor that is not open calls back (or throws) `EBADF`.
- **`writeFile` ignored its `flag`** (`{ flag: 'wx' }` overwrote an existing file); every open
  checks its flags as node's `stringToFlags` does, every open that can write (`'r+'`
  included) is checked as a write, and `fs/promises.open` maps numeric flags.
- **fs checked a call's other arguments after its path or descriptor, or not at all**:
  `writeFile` / `appendFile` options, `FileHandle` `write` / `chmod` / `chown` / `truncate`,
  and the path forms of `truncate`, `chmod`, `chown` and `utimes` now check theirs first, as
  node's do. `rm` refuses a directory without `recursive` (`ERR_FS_EISDIR`) and validates its
  options, a negative write or `readv` position is what libuv makes of it, an operation with
  no result calls back with `null` alone, and a string write in an encoding node's binding
  does not know writes UTF-8.
- **`fs.cp` / `cpSync` of a directory onto a file, or a file onto a directory, started
  copying** and failed on the way with `copyfile`'s `ENOENT` or `EPERM`; they fail first, with
  nothing copied, with node's `ERR_FS_CP_DIR_TO_NON_DIR` / `ERR_FS_CP_NON_DIR_TO_DIR` -- a
  `SystemError` from `cp` and `fs.promises.cp` -- and a directory copied without `recursive`
  is node's `ERR_FS_EISDIR`, where oam said `ERR_FS_CP_DIR_TO_NON_DIR` "-r not specified".
- **An http server's connection socket closed before the request was aborted** (it emitted
  `'close'` a tick after `destroy()`, ahead of `'aborted'` and the response's `'close'`); it
  closes when the connection has, and that `'close'` drives the abort in node's order.
  `req.destroy()` closes the connection once the response is under way, a socket's
  `destroy(err)` reaches the server's `'clientError'`, a request body the connection fails on
  is the socket's error, and a client's reset is the socket's `read ECONNRESET`, reported
  before it closes with `true`; a write to a response whose connection closed calls back
  `ERR_STREAM_DESTROYED`.
- **A fetch whose server closed the connection before the head failed with an uncoded
  cause**; it is undici's `SocketError` (`UND_ERR_SOCKET`, with the socket's facts), a failure
  mid-body is `terminated` (a malformed chunk with undici's `HTTPParserError`), and on oam's
  own transport a malformed chunk is the parser's error on an `http.request`. An
  `https.get`'s `req.socket.destroy()` closes its kept-alive TLS connection.
- **`writeHead()` did not build the response head**: an http server response's status,
  fields and framing are fixed there, as node's are, so `writeHead()` then `end('text')` is
  chunked. The status line carries the status message, trailers go out after the last chunk,
  header names keep the case they were set in, an HTTP/1.0 request's response is framed and
  kept alive as node's, and a 204's or 304's `content-length` goes out as set.
- **An `http.request`'s head went out one byte per code point** where node writes it as UTF-8
  (joined to a UTF-8 string body), and its `end()` with a `Trailer` header or no
  `content-length` writes node's head bytes.
- **A `net.Socket` resumed with a full buffer stopped reading**; it reads again. A write on a
  socket with no connection fails with `ERR_SOCKET_CLOSED`, `end()` and a held write before
  `destroy()` call back as node's do, `destroy()` closes a parked read at once, and the socket
  has node's `closed`, `errored`, `readableEnded` and `writableNeedDrain`, with node's
  `writableLength` accounting and `end()` timing.
- **A pending callback queued from a timer or an immediate ran inside that phase**; it waits
  for the phase to finish, as node's does. `url`, `fs.Dir` and credential errors come from
  the coded-error registry, the URL ones as `TypeError`s.
- **fetch ignored its dispatcher's `headersTimeout` and `bodyTimeout`**; it runs under them
  (undici's 300 s by default), restarting the body timer with every frame. A streamed upload
  sends nothing before its first non-empty chunk (an empty stream is `content-length: 0`), an
  abort stops reading it without cancelling the source, and an async iterable's values go
  through `Buffer.from`, as undici's do.
- **`undici.request()` stringified stream, iterable and `Blob` bodies**; it frames them as
  undici does when it dispatches the request, starts `headersTimeout` at a streamed body's
  end, stops the body once the response is over, and every class in the shim's `errors` has
  its own name.
- **zlib ignored the `dictionary` option**. Inflate and deflate (and their raw forms) use it:
  a zlib stream carries `FDICT` and the dictionary's `DICTID`, a wrong dictionary is node's
  `Bad dictionary`, and the option is validated for every zlib class.
- **A malformed response head on oam's own transport was `socket hang up`** (and fetch's
  cause a code-less `error sending request`); it is the parser's `HPE_INVALID_STATUS` /
  `HPE_INVALID_CONSTANT`, undici's `HTTPParserError` for fetch.
- **A write after `end()` on an http message was silent** -- `true` with a null callback on
  a client request, `false` with nothing on a server response; both now return `false` and
  report `ERR_STREAM_WRITE_AFTER_END` to the callback and as `'error'`. A chunk is checked
  before anything else, `end()` on a response whose connection closed neither builds a head
  nor calls back, and `flushHeaders()` on a destroyed request renders its head.
- **An `http.request` response had no `trailers` or `rawTrailers`**; they start as `{}` and
  `[]` and fill from a chunked body's trailer section.
- **`undici.request()` ignored `throwOnError`, and a body destroyed early just closed**; a
  status of 400 or more rejects with `ResponseStatusCodeError` (its body parsed by content
  type), and the body errors with `RequestAbortedError`. A buffered body follows a 301 or
  302 keeping its method and body, as undici's RedirectHandler does, and a FormData body is
  sent as `multipart/form-data`.
- **A failed `fs.read` called back with the error alone**; it calls back with `(err, 0,
  buffer)`, as node's does.

## [0.17.1] - 2026-09-29

Release tooling only; no runtime behavior change.

### Fixed

- **The linux release leg died at 03:00, when its builder VM's cost-backstop stop schedule
  fired mid-build** (#244). The run now detaches the VM's stop schedules for its duration and
  re-attaches them on exit, a failed run included; `OAM_KEEP_VM_SCHEDULE=1` leaves them alone.
- **The linux release leg reached its builder only through an IAP tunnel that took 11-57 s a
  call and lost most of its probes** (#245). It now connects over direct ssh first, and falls
  back to the tunnel, with a warning, when that fails.
- **The mac build host's `target/` grew without bound, to 93 GB** (#246). The mac release leg
  now reclaims space the way the linux leg does, and `gc-target.sh` prunes `deps/` on macOS
  too, where BSD `find` and `awk` had silently disabled it. Off Windows, killing a release job
  now kills its descendants too, instead of orphaning them.
- **The MCP sidecar gate's fetch row had not exercised oam's HTTP stack since
  `@yawlabs/fetch-mcp` 0.7.1** (#247). That release put private-host fetches behind an
  operator opt-in that the gate scrubbed from the sidecar's environment, so the call was
  refused on both runtimes and filed as a broken sidecar. The gate now sets
  `FETCH_MCP_ALLOW_PRIVATE_HOSTS=1` for its own loopback fixture.
- **The sidecar gate's own verdicts were checked by nothing that ran** (#248, #249, #250). Its
  offline self-test now runs in `scripts/ci-local.sh` step 13 and holds each verdict, the run
  loop's decisions included. An oam hang or crash mid-call is no longer excused as upstream by
  a node control that never booted: the verdict compares how far each runtime got.
- **A node control that cannot run a sidecar on the release box's node no longer exonerates
  oam** (#251, #252, #253). An oam failure beside such a control was filed as upstream and
  shipped on a warning. The gate now recognizes the refusal from the declared `engines.node` of
  the sidecar and of every package in its installed dependency tree, and from the refusal text
  fetch-mcp, tailscale-mcp and playwright print, and holds the failure against oam.
- **The sidecar gate probed a damaged install without noticing** (#256, #258). npm can leave a
  required package as an empty folder that later installs keep: the gate's shared stage held
  15, and every sidecar still passed only because none of them loaded one. A sidecar that did
  would have failed on both runtimes and been filed as broken upstream. After installing, the
  gate now checks each sidecar's installed tree for a package npm left hollow or a required one
  it left out, rebuilds the stage from scratch once when it finds one, and reports what is
  still missing as a SKIP that names it. Runs also take a lock on the shared stage, so two at
  once -- one way the damage happens -- now wait for each other.
- **An npm install that ran out of time kept running** (#257, #258). The gate's install timeout
  killed only the process it spawned: on Windows the shell around npm, so npm itself ran on,
  installing into the stage while the gate retried the install and probed the sidecars. A
  timeout now kills npm and every process still under it, and moves the half-written
  `node_modules` aside, so the next install starts clean.
- **A Ctrl-C of the sidecar gate left npm installing into its stage** (#258). The gate died at
  once, and npm took the interrupt as the cue to finish its current step and roll back: in one
  measured run it was still going 40 seconds later. The gate now kills npm's process tree
  first, moves what it half-wrote aside, releases its stage lock, and then dies of the
  interrupt. `release-local.sh` also now stops on a gate that was killed by a signal, ended by
  `Stop-Process`, or crashed (a status above 128, or 127), where it used to warn and go on to
  publish.
- **A Ctrl-Break of the sidecar gate left a half-written install, and a killed gate was
  reported as a failing sidecar** (#259). npm has no Ctrl-Break handler, so Ctrl-Break ended npm
  and the gate on the spot, mid-install; it now gets the same cleanup as Ctrl-C.
  `release-local.sh` read a gate ended by `taskkill /F`, or by an uncaught error, as "a sidecar
  failed", which sends the operator looking for an oam regression; it now says so only for a
  gate that wrote its verdict, and still stops the release either way.
- **A process a sidecar's install script started could outlive the sidecar gate's install**
  (#260). A lifecycle script can start a daemon whose parent then exits; no kill of npm's tree
  reaches it, and it went on running in the gate's stage. The gate now installs with
  `--ignore-scripts`, `--allow-git=none`, and a script shell and git that do not exist, so an
  install starts nothing but npm, and a git dependency is refused with its reason.
  The sidecars' installed trees are byte-identical either way: their one install script,
  puppeteer's browser download, was already skipped. A sidecar whose tree gains an install
  script nobody has reviewed is reported as not answered, naming the script. The install also
  no longer fails when the Windows user folder's name has a space.
- **The mac release leg reported a build host that was not on the release box's tailnet as a
  DNS failure, after the release had already been tagged** (#261). Its host check ran
  `nslookup`, which reverse-resolves an IP address and, on Windows, skips the name-resolution
  policy rules Tailscale can install MagicDNS as. It had passed for the build host's address on
  earlier releases; on the tailnet the release box is on now it failed every tailnet address
  and name, the box's own included, and a run given a tailnet IP was told to use "the tailnet
  IP". The leg now asks ssh alone and says what failed -- the name does not resolve, nothing
  answers, nothing listens on port 22, the host key changed, or key authentication was
  refused -- and when nothing answers it prints what `tailscale status` lists, since a device
  that joins a tailnet again gets a new address. `release-local.sh` runs that check at the
  start of its preflight, before it bumps or tags; it used to reach the Air only after the
  local gate and both Windows builds.
- **The linux release leg gave up after five minutes when its builder VM's zone had no
  capacity for the VM's machine type, and could only guess why** (#262). Six starts of the
  VM a minute apart were each refused for want of e2-highmem-4 in us-west1-b, with gcloud's
  reason sent to `/dev/null`, and the zone was still out twenty minutes later. The leg now
  walks a list of same-zone fallback machine types (`OAM_GCP_FALLBACK_MACHINE_TYPES`;
  types on separate hardware pools that boot the VM's disk and NIC as they are), setting the
  stopped VM to each before starting it, a minute between passes, for
  `OAM_VM_START_BUDGET_S` seconds; the VM's own type is put back when the run stops it, a
  failed run included. Every refusal is classified from gcloud's own text: no capacity
  moves to the next type, a quota or a type the API rejects drops that type for the run, a
  missing permission or an expired credential ends the run at once, and a Ctrl-C, which
  gcloud on Windows turns into an ordinary exit, ends it too. A builder moved to another
  zone is found by name. The final message names every type tried, gcloud's last words,
  and the zone move.

## [0.17.0] - 2026-09-24

### Added

- **`tls.setDefaultCACertificates(certs)` (Node 22.15+) replaces the process default trust
  store** (#199). oam had the reading half (`tls.getCACertificates`) but not the writing
  half, so a program that pins the process to its own roots threw `TypeError:
  tls.setDefaultCACertificates is not a function`. It now takes an array of PEM strings or
  `ArrayBufferView`s, validated as Node validates it (`ERR_INVALID_ARG_TYPE` for a non-array
  or a bad element, `ERR_CRYPTO_OPERATION_FAILED` when a non-empty array has nothing
  parseable, an empty array accepted and trusting nothing, duplicates dropped); a connection
  made after it with no `ca` of its own verifies against the override, and
  `tls.getCACertificates('default')` reads it back while `'bundled'` / `'system'` / `'extra'`
  stay put. Conformance case 183 holds it to node v22.22.2.

### Fixed

- **`fetch`, and an `https.request` / `https.get` with no TLS options of its own, refused a
  private CA's long-lived certificate on macOS, though `NODE_EXTRA_CA_CERTS` trusted its
  root.** Those requests run on the shared transport, whose platform verifier -- given the
  bundle as extra roots -- applies the operating system's TLS policy to the bundle's chains
  too, and Apple's holds a rule node's OpenSSL does not: a server certificate valid for more
  than 825 days is refused even under a root the user added (measured on macOS 27 with
  `security verify-cert -p ssl`: 826 days refused, 825 accepted). So a certificate node
  accepted -- a ten-year internal certificate, or the 100-year test leaves -- failed oam's
  `fetch` on macOS alone. The refusal is opaque, so it was named off the chain the server
  sent: `SELF_SIGNED_CERT_IN_CHAIN` when the server sent its root (as oam's own servers do
  with `NODE_EXTRA_CA_CERTS` set), `UNABLE_TO_VERIFY_LEAF_SIGNATURE` for a leaf sent alone. On
  macOS a chain Apple's TLS policy refuses now gets a second verdict: it is accepted when
  Apple's basic X.509 evaluation trusts it against the `NODE_EXTRA_CA_CERTS` bundle alone
  (signatures, validity periods and CA constraints, the root's included) and node's TLS rules
  accept it too (the extended key usage of every certificate in the path, the leaf's validity
  period and purpose, the host name), and refused with node's code when that evaluation
  trusts it and node's rules do not (`ERR_TLS_CERT_ALTNAME_INVALID`, `INVALID_PURPOSE`).
  Anything else keeps the platform's refusal, and a revocation the platform found is final. Windows and Linux
  are unchanged: their platform verifiers accepted the 100-year test leaves in every release
  since the transport shipped. Three e2e tests that had skipped macOS for this run there
  again.
- **`oam mcp`'s `oam_run` answered long after its deadline when the script's output was still
  held open.** On Windows, `oam run` type-checks a TypeScript file that has no tsconfig by
  spawning tsgo directly, and tsgo inherited `oam run`'s own stdout and stderr as extra
  handles; when the deadline killed the script, tsgo kept the pipes `oam mcp` reads open and
  the tool answered only when tsgo exited (a 25-second tsgo held a 1.5-second deadline to 26
  seconds, and the e2e deadline test failed on a loaded machine). tsgo no longer inherits
  them. Separately, a process the script started that kept its stdio and outlived it -- on
  Windows, a detached one -- held the answer until that process exited; the tool now
  answers by the deadline plus half a second with the output that arrived, and drops what
  such a process writes afterwards.
- **On Windows, a `child_process` spawn with more than three stdio entries, `'inherit'` among
  them, threw `spawn EINVAL` once the script's type-check had started.** oam clears the
  inherit flag on its own std handles before it starts a type-checker (so the checker cannot
  hold them open), and the spawn path for extra stdio entries passed the std handle itself in
  the child's explicit inherit list, which Windows refuses for a handle that is not
  inheritable. It now passes an inheritable duplicate, as libuv does. Every `.ts` run whose
  type-check starts a checker process was exposed -- through the type-check daemon for a
  project with a tsconfig since the daemon shipped, and with this release's tsgo fix above,
  for a file without one too.
- **A `fetch` aborted before it reached its dispatcher's `connect.lookup` hook (or its
  `connect` function) stayed parked until the hook answered, forever if it never did.** Such a
  fetch parks before dialling, and an abort drops the parked fetch, releasing a streamed
  request body and every write blocked on it. The abort listener was attached only once the
  fetch had parked, so an abort that landed first -- in the same tick as the call, or before a
  busy machine got the fetch that far -- never fired it. The fetch now drops itself when it
  parks already aborted; the hook is still asked, as node asks it.
- **An `https` server never fired `'upgrade'` or `'connect'`, so a WebSocket handshake reached
  the ordinary `'request'` handler and a CONNECT was closed** (#205). The https connection was
  built with `Upgrades::CloseConnect` -- an upgrade served as an ordinary request, a CONNECT
  closed -- where the `http` path hands the connection to JS. So `ws`, `socket.io`, and
  anything on `server.on('upgrade')` could not serve over TLS, and an https server could not
  act as a CONNECT proxy. The https connection now routes like http when the server is
  JS-driven: on an upgrade with a listener, or a CONNECT, it takes the TLS connection out of
  hyper, registers it as a TLS handle, and hands the listener a `tls.TLSSocket` with the bytes
  behind the head -- the encrypted mirror of the http `net.Socket` handover, sharing its rules
  (an upgrade needs a listener; a CONNECT with no listener is destroyed). Conformance case 189
  holds the four cases byte-identical to node v22.22.2. (The HTTP/1 side of
  `http2.createServer` is unchanged -- a separate concern.)
- **`node:https` exported nine names node's `https` does not have** (#204). The module was
  built by copying every export of `node:http` and overriding six, so it carried
  `STATUS_CODES`, `METHODS`, `ClientRequest`, `IncomingMessage`, `OutgoingMessage`,
  `ServerResponse`, `maxHeaderSize`, `validateHeaderName` and `validateHeaderValue` -- names
  node keeps on `http` alone. A builtin's ESM named exports are its module object's own keys,
  so `import { STATUS_CODES } from "node:https"` linked on oam and threw a `SyntaxError` at
  link time on node, and `if (https.maxHeaderSize)` read the opposite way on each. `https`
  now exports exactly node's six names -- `Agent`, `globalAgent`, `Server`, `createServer`,
  `get`, `request` -- in node's order; a program that wants the rest imports them from `http`.
  Conformance case 188 holds the export set to node v22.22.2.
- **An `https` server ran the request handler only after the whole request body had arrived,
  so it could not answer or cut an upload early** (#203). The https connection was built with
  the buffered-body path, where the `http` server already streams: the handler was dispatched
  only once the body ended, so a `res.writeHead(413); req.destroy()` took effect only after
  the client had finished sending (up to the 100 MB per-request cap), and a body the parser
  refused as malformed reached no handler. The https connection now uses the same streaming
  path as `http` -- the handler is dispatched on the head and the body is delivered as it
  arrives, with the same caps and drain accounting -- so an https handler answers (and cuts)
  an upload before it finishes, as node's does. Conformance case 187 holds both halves
  (dispatch-on-head and early-cut) byte-identical to node v22.22.2 for `http` and `https`.
- **`fetch`'s connection pool opened a spare connection that carried no request and held a
  `node:http` server's `close()` open for 90 seconds** (#216). hyper-util's legacy client
  raced a fresh connect against a pooled checkout on a cache-miss; when the pooled connection
  won, the freshly opened one was parked idle having sent nothing, so a server saw one more
  connection than its requests explained and a `fetch`-then-`server.close()` in the same
  process hung until the spare's 90 s idle timeout. oam now owns its connection pool: a
  request either reuses an idle connection or opens exactly one it will send on, never both,
  the way undici does, so no spare is ever created and `close()` fires at once. The pool is
  built on hyper's low-level `client::conn` dispatchers over oam's existing connector, keeps
  the same origin-keyed reuse, keep-alive, HTTP/2 multiplexing, `Connection: close` handling
  and stale-connection resend, and adds real idle eviction. Conformance case 186 holds the
  no-spare property and the prompt `close()` to node v22.22.2. (The owned pool also makes
  `agent.destroy()` promptly close its sockets fixable -- divergence entry 38 -- but that
  wiring, which needs a per-agent pool, is a follow-up.)
- **An http/https server refused a request with more than 100 header fields (`431`), and
  `server.maxHeadersCount` was ignored** (#202). The vendored parser's default cap refused
  any head past 100 fields, so a request a proxy chain had piled `x-forwarded-*` / tracing
  headers onto -- one Node serves with a `200` -- got a `431`; and `maxHeadersCount`, Node's
  knob for limiting header count, was stored and never read. A head is now refused only on
  its byte size (`maxHeaderSize` -> `431`), never its field count, and the handler is given
  the first `maxHeadersCount` header fields with the rest dropped (`null`, the default,
  keeps Node's 1000; `0` is no limit) -- on `http` and `https`, and with `maxHeaderSize`
  raised. The vendored parser grows its header buffer only when a head needs it, so the
  common few-header request keeps its allocation-free fast path. Conformance case 185 holds
  it to node v22.22.2.
- **The cleartext `http2.createServer` had no compatibility API, so a `'request'` listener
  never fired and a `(req, res)` server never answered** (#200). `createServer(handler)` put
  the handler on `'stream'` and lacked the `Http2ServerRequest` / `Http2ServerResponse`
  machinery the secure server got in 0.16.3, so the way most HTTP/2 code is written --
  `http2.createServer()` plus `server.on('request', (req, res) => res.end(...))` -- hung with
  no response. The cleartext server now shares the secure server's wiring: `createServer`
  registers the handler on `'request'`, and a `'request'` listener installs the `'stream'`
  bridge that builds the request and response objects (`req.url`, `req.method`,
  `res.writeHead`, `res.end`); the raw `'stream'` API keeps working alongside it, as on Node.
  Conformance case 184 holds it to node v22.22.2.
- **A refused server name failed `tls.connect` with `ERR_TLS_CERT_ALTNAME_INVALID` whose
  `cert` was `{}`, where Node hands over the peer certificate** (#198). Node reports the
  certificate the name check refused as `err.cert` -- the same object
  `getPeerCertificate(true)` returns, its subject, issuer, altnames, fingerprints, validity
  and linked `issuerCertificate` -- which is what diagnostics print. oam's verifier refused
  the name inside the handshake, so the chain never reached JS and `err.cert` was empty. The
  verifier now carries the chain it refused out through the verdict, and `tls.connect`'s
  error path builds `err.cert` from it with the routine `getPeerCertificate()` uses, so a
  caught `ERR_TLS_CERT_ALTNAME_INVALID` reports the same certificate on both runtimes. A
  chain-build failure (`UNABLE_TO_VERIFY_LEAF_SIGNATURE`) leaves `err.cert` undefined (no
  `cert` key), as Node does. Measured on node v22.22.2.
- **An `http2.connect` session ended by a server's fatal TLS alert emitted `'error'` and
  `'close'`, crashing a program that had no session `'error'` listener** (#197). A TLS 1.3
  server that requires a client certificate answers a client that sent none with a fatal
  `certificate_required` alert after the handshake; Node carries it on the pending stream
  (`ERR_SSL_TLSV13_ALERT_CERTIFICATE_REQUIRED`, #196) and destroys the session silently, so
  a program written for Node -- handling the request's error, with no reason to listen on
  the session -- survives. oam re-surfaced the alert on the session as an unhandled
  `'error'`, taking the process down. It now leaves the session silent, as Node does, while
  a connection-level failure -- a refused connection, a reset or EOF during the handshake --
  still reaches the session. Conformance case 181 and an e2e test pin it; measured on node
  v22.22.2.
- **A pinned TLS 1.2 handshake between two oam peers negotiated
  `ECDHE-RSA-AES256-GCM-SHA384`, where two node peers negotiate
  `ECDHE-RSA-AES128-GCM-SHA256`; a server's `honorCipherOrder` was ignored;
  `tls.DEFAULT_MIN_VERSION` / `DEFAULT_MAX_VERSION` were inert constants; and
  `--tls-min-v1.x` / `--tls-max-v1.x` were rejected as unknown arguments** (#144, the
  residue of 0.16.1's fix). oam's rustls now offers its cipher suites in
  `tls.DEFAULT_CIPHERS`' order -- under TLS 1.2 the ECDHE AES-128-GCM suites before the
  AES-256-GCM ones and CHACHA20 last, under TLS 1.3 AES-256, CHACHA20, AES-128 -- on every
  client (`tls.connect`, `https.request`, `fetch`) and every server, and a server picks a
  suite by its own list unless `honorCipherOrder` is given falsy, as node's does. A
  `minVersion` / `maxVersion` left null is the module's live `DEFAULT_MIN_VERSION` /
  `DEFAULT_MAX_VERSION`, read when the connection or server is made and validated like an
  explicit value (`ERR_TLS_INVALID_PROTOCOL_VERSION`, the minimum checked first and both
  before a method name); `TLS_method` ignores the defaults and `SSLv23_method` keeps the
  default floor, as in node. They reach `fetch()` and an option-less `https.get()` too --
  node's undici and https agent connect through `tls.connect`, which reads them for every
  connection -- where oam's shared transport was built once with every version: a request
  now handshakes in the range the defaults name, an empty one fails with
  `ERR_SSL_NO_PROTOCOLS_AVAILABLE` (a fetch's cause) and a default that is not a version
  fails a fetch with `ERR_TLS_INVALID_PROTOCOL_VERSION` as its cause, as in node.
  `new tls.TLSSocket(socket, options)` validates the version options (and the defaults they
  fall back to) at construction, as node's constructor does, unless given a `secureContext`;
  the value in these messages is rendered as node's `%j` renders it (a function or symbol
  `undefined`, a circular object `[Circular]`, a BigInt JSON's own refusal). The six flags
  set the initial defaults, from argv or `NODE_OPTIONS`, with node's precedence when
  several are given (and node's refusal of `--tls-min-v1.3` with `--tls-max-v1.2`: exit 9
  before anything runs), and come back through `process.execArgv`. Conformance case 178
  holds all of it to node v22.22.2, the negotiated cipher names included, which case 109
  had to leave out. `tls.getCiphers()` now lists the nine suites oam offers, in node's
  lowercase spelling, where it listed three TLS 1.3 names. The `ciphers` option is still
  ignored (docs/node-divergences.md, entry 42).
- **A fatal alert from the server failed the `tls.connect`-based clients with `EIO`** --
  `tls.connect`, `https.request` and an `http2.connect` session -- **where node names the
  alert**, and left an option-less `https.get` or `fetch` with a bare `socket hang up`
  (only `protocol_version` was named, #146) (#196). Every alert a server can send is now node's code:
  `ERR_SSL_` and OpenSSL 3's reason for it, uppercased
  (`ERR_SSL_SSL/TLS_ALERT_HANDSHAKE_FAILURE`, `ERR_SSL_TLSV1_ALERT_NO_APPLICATION_PROTOCOL`,
  `ERR_SSL_TLSV13_ALERT_CERTIFICATE_REQUIRED` from a TLS 1.3 server requiring a client
  certificate, which arrives after `'secureConnect'`), with `library` and `reason` ahead of
  `code`; the `write EPROTO` rule of #146 holds for every alert answering the handshake on
  `tls.connect` and `https.request` (an option-less `https.get` reports it the same way,
  where `fetch` keeps the alert's code as its `cause`); a description node cannot name is node's
  disconnect (`ECONNRESET`, "Client network socket disconnected before secure TLS
  connection was established", carrying `path`, `host`, `port` and `localAddress`) on a
  socket with nothing queued and that EPROTO on one with a write queued, and the transport
  closing during the handshake -- or after a warning-level alert -- is that disconnect on
  every client. A write queued behind a handshake that ends otherwise gets node's error
  on its callback: `write ECANCELED Canceled because of SSL destruction` when the transport
  closes, `write EBADF` when the verifier refuses the certificate, a detail-less `write
  EPROTO` when the version range offers nothing -- where every one got
  `ERR_SOCKET_CLOSED_BEFORE_CONNECTION` -- and `authorizationError` stays null after an
  alert, as in node. Measured for every alert description on node v22.22.2 (OpenSSL 3.5.5);
  conformance case 180 pins the table on five clients and case 145 now compares the
  refused client's code, which it had to leave out. The same table names the alert a
  client sends on a server's `tlsClientError`, in OpenSSL 3's spelling
  (`ERR_SSL_SSL/TLS_ALERT_*` where 0.16.4 said `ERR_SSL_SSLV3_ALERT_*`). The messages stay
  rustls's (docs/node-divergences.md, entry 34).
- **A handshake the server refuses with the `protocol_version` alert failed an `https`
  request with the alert's own code, `ERR_SSL_TLSV1_ALERT_PROTOCOL_VERSION`, where node's
  fails with `write EPROTO`** (#146). Node's rule, measured: a socket with nothing queued
  gets the alert's code; one with a write queued behind the handshake -- `tls.connect(o);
  s.write(x)`, an https request's head once `end()`, `write()` or `flushHeaders()` ran, any
  request on the shared transport -- gets that write's `write EPROTO` (errno, code, syscall)
  on the socket's error and every queued write's callback; `end()` with no data queues no
  write. oam now follows it. The rest of #146 -- a verifying `https.request`'s `ca`,
  `minVersion` / `maxVersion` / `secureProtocol`, `cert` / `key`, `servername`,
  `checkServerIdentity` and `secureContext`, in its own options or its agent's -- has held
  since 0.16.3, when such a request began to go over `tls.connect` (entry 43); conformance
  case 179 now pins it, the negotiated protocol read from the server.
- **`process.execArgv` listed the flags `NODE_OPTIONS` carried** (`NODE_OPTIONS=--no-warnings`
  made it `['--no-warnings']`), where node lists what the command line gave and nothing
  else: a child re-spawned from it got every environment flag twice. `NODE_OPTIONS` is now
  read into flags of its own and merged under argv's -- an explicit flag still wins, lists
  apply the environment's entries first -- and `execArgv` reflects argv alone. Found by
  case 178, which spawns children under `NODE_OPTIONS`.
### Security

- **zlib's one-shot functions ignored `maxOutputLength`.** `gunzipSync`, `inflateSync`,
  `inflateRawSync`, `unzipSync`, the encoders and all their callback forms read `level`
  and dropped every other option, so `gunzipSync(buf, { maxOutputLength: 1000 })`
  returned the whole inflated output where node throws `RangeError
  [ERR_BUFFER_TOO_LARGE]: Cannot create a Buffer larger than 1000 bytes` -- and node
  stops inflating at the cap, where oam had already inflated everything. The option is
  the one defence a program has against a decompression bomb it did not write the
  decoder for: a 200 KB gzip of 200 MiB of spaces, handed to `@yawlabs/fetch-mcp`'s
  sitemap tool with a 1 MiB cap, inflated all 200 MiB under oam and ended the server at
  the 4 GB heap cap (found 2026-09-21; that server now counts the bytes itself). The cap
  is now enforced while inflating -- measured on that bomb, oam grows by 0.5 MiB and
  fails in 9 ms, node by 1 MiB in 2 ms -- and on the finished buffer for the encoders,
  as node's is. The option is validated as node validates it: `undefined` and `NaN` mean
  no cap, a non-number is `ERR_INVALID_ARG_TYPE`, `Infinity` is "a finite number",
  outside 1..`kMaxLength` is `ERR_OUT_OF_RANGE`, and a fraction is compared as written.
  Case 177 holds all of it to node v22.22.2, the 64 MiB bomb under a 64 KiB cap included.
  The other one-shot options (`chunkSize`, `windowBits`, `finishFlush`, `info`,
  `dictionary`, `params`) are still not read; `brotliCompressSync` /
  `brotliDecompressSync` remain unsupported (divergences table).

- **`require.main` was never set, so `if (require.main === module)` never ran.** A CommonJS
  script uses that guard to tell being run from being required, and in oam it was always
  false: the script loaded, did nothing and exited 0. A hook script whose job is to refuse a
  command answered with silence, which the harness running it reads as consent.
  `require.main` is now the entry's `module` in the entry and in everything it requires, and
  `process.mainModule` is the same object -- for a program's CommonJS entry, a worker's, a
  `child_process.fork()` script, each file `oam test` runs and a compiled executable's
  embedded script. Like node, each new `require` takes `require.main` from
  `process.mainModule`, and the main module stays set when the entry throws. `-e` and `-p`
  source and an ES module entry have no main module, as in node, and `require.main` is
  `undefined` there.
- **A CommonJS entry named by a relative path could run as an ES module entry.** The
  package.json `"type"` lookup started from the path as typed, so `oam gate.js` run from a
  subdirectory of a `"type": "commonjs"` package never found that package.json. The file still
  ran as CommonJS, but without a main module, so the guard above stayed false. An entry's kind
  is now decided on its real path, as node resolves its main entry -- for `oam <file>`,
  `oam run`, `oam test` and a worker's entry.
- **A CommonJS `module` now has node's `require`, `path` and `paths`.** Code that loads
  relative to the application's entry with `require.main.require(...)`, or reads
  `require.main.paths`, threw a TypeError once `require.main` was set. `children`, `parent`
  and the main module's `id` of `'.'` still differ; see docs/node-divergences.md, entry 45.

## [0.16.4] - 2026-09-21

The events a server announces a connection with. `'connection'` and
`'secureConnection'` now reach an application before anything on the connection is
served, so a listener that filters clients -- an allow list, or the mutual-TLS pattern
node documents -- runs and is obeyed; they are also where graceful-shutdown wrappers
(`stoppable`, `http-terminator`, `server-destroy`) learn which sockets a server holds.
The socket an `http` or `https` request carries is the connection's own, as node's is,
a listener that throws no longer takes a server down, and `server.close()` lets the
connections a server had accepted finish before it reports itself closed.

### Security

- **A server emitted no `'connection'` or `'secureConnection'`, so an application's own
  client check never ran.** An application decides for itself which clients it will serve in
  those listeners: an allow list that destroys the sockets it refuses, or the mutual-TLS
  pattern node documents, where the server is created with `requestCert: true` and
  `rejectUnauthorized: false` -- admitting every handshake -- and a `'secureConnection'`
  listener reads `socket.authorized`, `socket.authorizationError` and
  `socket.getPeerCertificate()`. oam's servers went straight from the accept to serving, and
  its https server terminated TLS natively and went straight from the handshake to serving
  HTTP: neither event was emitted, so those listeners never ran and a client the application
  would have refused was served instead. `'connection'` was missing on `http.createServer`,
  `https.createServer`, `tls.createServer` and `http2.createSecureServer`;
  `'secureConnection'` on `https.createServer` (the other two already emitted it with a real
  `TLSSocket`). A connection now announces itself before a byte is read off it -- and an
  https connection again once its handshake is done, before anything on it is parsed as
  HTTP -- and nothing happens on it until the listeners have run; one that destroys the
  socket stops the client being served, with no answer on the wire. `requestCert` with
  `rejectUnauthorized: true` -- the server refusing on its own -- was already enforced in
  0.16.3 and is unchanged. Conformance cases 168 and 169 hold it to node v22.22.2 on the
  `http`, `https` and `tls` servers, and case 174 on `http2.createSecureServer`.
  A connection that goes before `http2.createSecureServer` can serve it -- a client that
  leaves right after its handshake, or a `'secureConnection'` listener put in front of the
  server's own that destroys the socket -- still gets its `'session'` and the session's
  `'close'`, as node builds the session over the dead socket; oam dropped it without a
  word, so a server counting sessions missed one under load.

- **A listener that threw took a server down.** In 0.16.3 a `'request'`
  handler, an `'upgrade'` listener or a `'connect'` listener that threw ended the process with
  an unhandled promise rejection (`OAM-RT0004`), even when the application had installed
  `process.on('uncaughtException')` to log the error and go on serving: one request that
  reached a bug in a handler stopped the server for every client. In node the throw is raised
  as `'uncaughtException'`, so with such a handler the server keeps serving (without one, the
  process exits on both runtimes). oam now does the same for every listener an `http` or
  `https` server calls while it serves or closes: those three, the `'connection'` and
  `'secureConnection'` listeners this release adds -- a mutual-TLS check reading a field off
  an empty certificate, say -- and a `'close'` listener on the socket `'connection'` handed
  out. The other servers had the same fault: in 0.16.3 a `'connection'` listener on
  `net.createServer`, or a `'secureConnection'` listener on `tls.createServer` or
  `http2.createSecureServer`, that threw ended the process despite the handler. Those are
  raised as node raises them too, and the connection whose listener threw is still served.
  Case 173 holds the `http` server's `'request'`, `'upgrade'`, `'connect'` and `'close'`
  listeners to node v22.22.2, and case 176 the `net`, `tls` and `http2` servers' listeners
  and a socket `'close'` listener that throws when `server.close()` ends its connection.

### Changed

- **An http or https server's `req.socket` is the connection's socket**, as node's is: the
  object `'connection'` -- and on an https server `'secureConnection'` -- handed out. Up to
  0.16.3 an http server made a new one per request, so two keep-alive requests saw two
  objects where node shows one; they now see one, it emits `'close'` when the connection
  ends, and `res.socket` / `res.connection` / `req.client` are that same object. It also
  answers `instanceof net.Socket`, and on an https server `instanceof tls.TLSSocket`, where
  both were `false` before -- by brand, as oam's own `TLSSocket` answers `instanceof
  net.Socket` (0.15.3). The object is still not a stream: it has the addresses,
  `address()`, `setTimeout`, `destroy` and `end`, and none of `write`, `pause`, `resume`,
  `setNoDelay`, `setKeepAlive`, `ref` or `unref`, so code that reads an `instanceof` test as
  a promise of the stream API will now reach a missing method where it used to take its
  non-socket path. It is branded because a check that filters clients in a `'connection'` or
  `'secureConnection'` listener is commonly written behind exactly that test, and a check
  that silently skipped itself would be the weakness the Security entry above is about.
  Divergence 39 lists what the object has.

### Fixed

- **One `process.stdout.write()` reached the terminal as two writes.** It went through Rust's
  line-buffered stdout, which sends a payload through its last newline at once and holds the
  rest until the flush. So a TUI frame -- hide the cursor, rewrite the rows, restore the
  cursor -- arrived in two pieces a few milliseconds apart, and the terminal drew the
  half-frame in between: flicker on every keystroke. Measured through a real ConPTY at
  100x30, node delivered 12 frames of 12 whole and oam none. Each write now goes out whole,
  as node's does: a console gets it as UTF-16 through `WriteConsoleW`, in chunks of at most
  8192 units as libuv hands them, and a pipe or a file gets the bytes in one write. What a
  pipe or file receives is byte-for-byte what node writes, binary data and a UTF-8
  character cut across two writes included.

- **A write to stdout or stderr that failed was dropped without a word.** node reports it: a
  stdout that is a read-only file, say, or a full disk (`ENOSPC`), gives the write's
  callback the error and emits `'error'` on `process.stdout` -- which ends the program when
  nothing listens for it -- and `fs.writeSync(1, ...)` throws. oam discarded the error and
  ran on as though the output had been written. It now reports it as node does, with
  node's `code`, `errno` and message (`EBADF: bad file descriptor, write`). A reader that
  goes away still ends the program quietly, as before, and that now includes a Windows pipe
  server that disconnects, which oam used to go on writing into. `process.stdout.destroy()`
  and `end()` leave the stream writable, as node's do, where oam's refused every later
  write; `fs.write` on a descriptor that fails calls back `(err, 0, data)`, as node's does;
  and on Linux and macOS a stdout pipe in non-blocking mode no longer loses the tail of a
  large write -- it waits for the reader and delivers all of it. What still differs is in
  the divergences table (`process.stdout` / `process.stderr` rows).

- **A server was not `instanceof net.Server`, and had no `getConnections()`.** In node every
  server in this family is one -- `http.Server extends net.Server`, `tls.Server extends
  net.Server`, `https.Server extends tls.Server` -- so code written for node can test any of
  them with `instanceof net.Server` and ask any of them `getConnections()`. oam's `http`,
  `https` and `tls` servers answered `false` and carried no such method, and `net.Server`'s
  own was a stub that answered 0 whatever was connected -- the worse half of the two, because
  a drain loop written against it finished at once rather than failing in a way its caller
  would notice. All four now answer the check, through the same brand `net.Socket` uses, and
  report the connections the server is holding, on a later tick as node's do.
  `http2.createSecureServer` is a `tls.Server` and gets both; `http2.createServer`'s h2c
  server is not covered. A connection an upgrade or CONNECT takes over is counted until its
  socket closes, as node counts a websocket, and a socket leaves the count in its own
  teardown rather than through a `'close'` listener user code could remove. Case 170 holds
  the shape to node v22.22.2, net and tls connections included, down to zero after they
  close -- all but one ending, which it leaves out: on an `http` server, the count after a
  client's keep-alive `Agent` is destroyed. oam's client keeps that pooled connection open
  until the server's keep-alive timeout closes it, where node's closes it at once -- a gap
  in the client, not in the count (divergence 38).

- **`server.close()` did not wait for the connections a server had accepted.** node's
  `http` and `https` servers stop listening at `close()`, close the idle keep-alive
  connections, and let every other connection finish: a request in flight is answered, its
  connection keeps counting in `getConnections()` until it ends, and `'close'` -- with the
  `close(cb)` callback -- comes after the last one has gone. oam let go of every connection
  at `close()`. The count read 0 at once with a request still in flight, so a drain loop
  polling it finished early; `'close'` and the callback fired about a millisecond after
  `close()`, so the common `server.close(() => process.exit(0))` cut off the request it was
  meant to let finish; a request already on its way to the handler was dropped, its client
  left waiting; and a connection whose own `'connection'` listener called `close()` was
  reset. Each now behaves as node's does. An upgraded socket -- a websocket -- holds
  `'close'` back until it ends; a second `close(cb)` made during the drain is answered
  `ERR_SERVER_NOT_RUNNING` when the drain ends; the listening socket is closed before
  `close()` returns, so a connection made after it is refused; and a connection accepted
  before it is served, its TLS handshake included. `closeIdleConnections()` and
  `closeAllConnections()`, empty until now, close what node's close. A `net` or `tls` server
  likewise emits `'close'` only once its last connection has ended, where 0.16.3 emitted it
  at `close()`. Case 175 holds it to node v22.22.2. Two differences remain (divergence 42):
  a connection with a request in flight at `close()` is answered with `Connection: close`
  and ends after that response, where node keeps it open until its keep-alive timeout; and
  requests pipelined behind that one are not read. `oam.serve`'s `close()` finishes the
  requests in flight and closes every other connection, one that connected and never sent a
  request included: a client pool opens such a connection (`fetch`'s spare, raced against a
  pooled connection that won), and since `close()` stops the check that would have timed it
  out, as node's does, the drain would have held `close()` -- and the process -- for ever
  (it never shipped: the drain and this are both new in this release). The HTTP/1
  connections `http2.createServer` also takes are served the same way. A `node:http` server
  keeps such a connection until the client goes, as node's does.

- **`http.request` sent no `Connection` header, so a server kept the connection open.** node's
  client puts one on every request -- `close` when the socket is not to be kept alive,
  `keep-alive` when it is, nothing when the caller removed it -- and what the peer does with
  the connection follows from it. oam computed the value and then wrote it only on its
  raw-socket path; over its own transport, which is where `http.request` goes, it was dropped
  and every request went out as an ordinary HTTP/1.1 keep-alive one. So a request node has the
  server let go of as soon as the response is read (`agent: false`) instead left the
  connection held until the server's keep-alive timeout expired -- 2007 ms against node's own
  server, where node's client measured 7 ms -- and the connection's socket, its `'close'`, the
  `getConnections()` count and a `maxConnections` slot went with it. The server was never the
  problem: handed the same request, node's server holds it exactly as long. What the caller
  sees of its own headers is unchanged, since the value goes on a copy: `getHeader(
  'connection')` and `getHeaders()` still report only what the caller set. A connection a request asked
  to close is never given another request, whether or not the response said `close` back
  (RFC 9112 s9.6), as node destroys the socket. Case 171 holds the table -- eight request
  shapes, and pooling -- to node v22.22.2, and case 172 holds that rule against a server
  that never closes a connection and never says `close`.

## [0.16.3] - 2026-09-20

A security release over both ends of the HTTP stack. On the client, checks an application installs
were not being called: `tls.checkServerIdentity`, a `secureContext`, a `lookup`
function, an `http.Agent`'s own `createConnection`, an undici dispatcher's `connect`.
Requests could also leave by a route the caller had not asked for -- a followed
redirect, an environment proxy, a rewritten host. On the server, every client was
reported as `127.0.0.1`, request heads Node refuses were accepted, neither a head's
size nor a connection's life was bounded, and a TLS server neither asked for a client
certificate nor, over HTTP/2, encrypted at all. Alongside those, the correctness fixes
that came out of running real clients over the new transport: keep-alive pooling,
`setImmediate`, and a heap that grew with every callback the loop ran.

### Security

- **`tls.checkServerIdentity` accepted every certificate.** It answered `undefined`
  whatever the host name and the certificate, so code that checks the name itself -- after
  `rejectUnauthorized: false`, or around a certificate pin -- accepted a certificate issued
  for another host. It is now node's own check (`lib/tls.js`): the subjectAltName's DNS
  names and IP addresses, the subject CN when it has neither, node's wildcard rules, and its
  `ERR_TLS_CERT_ALTNAME_INVALID` carrying `reason`, `host` and `cert`. A connection's own
  `checkServerIdentity` now decides the name, as in node -- oam checked the name itself and
  never called the function on a mismatch, so a function written to accept a known mismatch
  (an address, a pinned certificate) could not -- and a function that refuses a peer does so
  before anything written while connecting is sent to it. A certificate's names are also
  printed as node prints them: a name holding a comma, a quote, a backslash or a control
  character is a JSON string literal in `subjectaltname` / `subjectAltName` / `infoAccess`,
  so no DNS name can be read out of a URI, an e-mail address, a directory name or an
  otherName in that list (the shape of CVE-2021-44532).

- **`tls.createSecureContext` checked nothing, and `secureContext` was ignored.**
  `createSecureContext(options)` copied the options and read no key: a wrong or missing
  passphrase, a key that is not a key or not its certificate's, and a PKCS#12 bundle that
  does not open were all reported as a context. And `tls.connect`, `https.request` and
  `http2.connect` ignored a `secureContext` they were given, so a context built to trust one
  private CA was replaced by the default trust store -- a certificate any public CA issued
  for the name then passed -- and a client certificate it carried was never sent. Both now
  follow node: a context reads its `key`, `cert` and `pfx` when it is built and throws
  node's errors there (`ERR_OSSL_BAD_DECRYPT`, `ERR_OSSL_UNSUPPORTED`,
  `ERR_OSSL_X509_KEY_VALUES_MISMATCH`, `mac verify failure`), at `createSecureContext()` and
  synchronously at `tls.connect()`; and a connection given a context is made with that
  context's trust, certificate and version range, whatever the connect options say about
  them. A client certificate may now come as a passphrase-protected key
  (`key: [{ pem, passphrase }]` included) or a `pfx`, which `tls.connect` ignored.

- **The `lookup` connect option was ignored.** `net.connect`, `tls.connect`,
  `http.request` and `https.request` -- the request's own `lookup` and an `http.Agent`'s
  -- never called it and resolved the host through the system resolver, so a host check
  an application put in its lookup function never ran; a replaced `dns.lookup` was not
  consulted either. Both are now honoured as node honours them: the hook is called with
  node's arguments before anything is dialled, a refusal fails the connection with the
  hook's own error and never falls back to system DNS, every answered address is emitted
  as the socket's `'lookup'` event first (a listener that destroys the socket stops the
  connection), and only the answered addresses are dialled. `fetch` also resolves
  through a replaced `dns.lookup`. Under `--permission --allow-net`, each address a hook
  answers is checked against the grant as a connection to that address would be.

- **An `http.Agent` whose `createConnection` was overridden was not used.**
  `http.request` and `https.request` sent every request through oam's own HTTP client,
  so a custom or patched agent -- the way request-filtering-agent, ssrf-req-filter and
  similar packages vet a destination -- was never called, and neither were
  `options.createConnection`, a wrapped `net.createConnection` / `tls.connect`, or
  listeners on `req.socket`. Proxy agents were skipped the same way -- http-proxy-agent,
  https-proxy-agent, proxy-agent, global-agent, hpagent and `tunnel` (which
  @actions/http-client uses) -- so their requests went straight to the destination
  instead of through the proxy they name. A request that carries such connection policy
  now goes over the socket the agent returns, as in node, and a proxy agent's requests
  go through its proxy. So does `https.request` with
  `rejectUnauthorized: false`, which ignored the agent too, and an upgrade request. The
  agent pools these connections as node's does. Their response heads are held to node's
  `maxHeaderSize`, and `http.request` now takes node's per-request `maxHeaderSize` and
  `insecureHTTPParser` options, validated as node validates them; an oversized head
  fails the request with node's own `HPE_HEADER_OVERFLOW` error.

- **`http.request` followed redirects.** node's `http.request` returns a `3xx` as the
  response; oam's followed it, so a request whose URL an application had vetted could
  end at a host it never named. It now returns the `3xx`, as node does.

- **`fetch` ignored `redirect: 'manual'` and `redirect: 'error'`.** Every redirect was
  followed, so an application that asks for `'manual'` to vet each hop before following
  it got the target's response instead. `'manual'` now returns the `3xx` and `'error'`
  rejects with node's `unexpected redirect` cause, and a value outside the enum is
  refused, as in node.

- **`http.request` dialled a rewritten host.** On oam's own transport a request's
  `host` went through the URL parser, which turns spellings node's resolver refuses --
  percent-escapes, octal or zero-padded IPv4, a trailing dot, a tab, fullwidth digits --
  into an address, so a host an application had checked as a string reached an address
  node never dials. Such a host now goes to the resolver as written, as in node, and a
  Host header no header may carry throws node's `ERR_INVALID_CHAR`. `net.isIP` also
  accepts an IPv6 zone id, and `dns.lookup` answers an IP literal as written, as node's do.
  The resolver behind `dns.lookup`, `net.connect` and `tls.connect` is handed the name's
  UTS #46 ToASCII form, as node's is (a soft hyphen vanishes, a fullwidth digit is a digit,
  a name ToASCII refuses is `getaddrinfo EINVAL`).

- **`http.request` went through the environment proxy.** oam sent every `http.request` /
  `https.request` through `HTTP_PROXY` / `HTTPS_PROXY` / `ALL_PROXY`, which node v22 applies
  only under `NODE_USE_ENV_PROXY=1`; behind a proxy `res.socket.remoteAddress` was the
  proxy's, so a check of the address a response came from passed for any destination the
  proxy would fetch. `http.request` now dials the destination itself unless
  `NODE_USE_ENV_PROXY=1` (or `--use-env-proxy` in `NODE_OPTIONS`) is set, and then only
  over node's own global agents, as node does. `fetch` still honours the environment
  proxy.

- **A `socketPath` or `path` connected to `host:port`.** node connects `http.request`'s
  `socketPath` and `net.connect` / `tls.connect`'s `path` to that Unix domain socket or
  named pipe; oam ignored them and connected to `host:port` (by default `localhost:80`),
  sending the request to whatever listened there. oam has no client for either, so these
  now fail with `ERR_FEATURE_UNAVAILABLE_ON_PLATFORM` and nothing is dialled.

- **The `localAddress` and `localPort` connect options were ignored.** `net.connect`,
  `tls.connect` and `http.request` validated `localAddress` and then connected from the
  default address and an ephemeral port, so a connection an application meant to leave
  from one address or port -- the one a firewall rule or an egress policy is written
  for -- left from another. The socket is now bound to them before it dials, as in node,
  and a bind that fails is the connection's error (`bind EADDRNOTAVAIL 192.0.2.1`); a
  non-number `localPort` throws node's `ERR_INVALID_ARG_TYPE`.

- **`Object.prototype.toString.call(process)` was `[object Object]`.** node's is
  `[object process]`, and axios checks exactly that to choose its node http adapter: on
  oam it chose its fetch adapter instead, which ignores `httpAgent` / `httpsAgent` -- the
  agents guard packages such as request-filtering-agent hand it. `process` now carries
  node's `Symbol.toStringTag`.

- **A refused certificate was reported as `socket hang up`.** On oam's own transport an
  `https.request` whose server certificate did not verify failed with `ECONNRESET`
  `socket hang up`, and `fetch`'s cause carried no code, where the same request over
  `tls.connect` had node's: retry logic that retries `ECONNRESET` retried a refused
  certificate. Both now report node's code and message (`UNABLE_TO_VERIFY_LEAF_SIGNATURE`,
  `DEPTH_ZERO_SELF_SIGNED_CERT`, `CERT_HAS_EXPIRED`, ...).

- **TLS options of `https.request` were not applied.** A verifying `https.request` went
  through one shared client that ignored the request's `ca`, client certificate,
  `servername` and `checkServerIdentity`, and `tls.connect` never called a
  `checkServerIdentity` either, so a certificate pin or a private CA an application set
  was not enforced. `tls.connect` now calls it after the chain check and fails the
  connection with its error, and an `https.request` carrying any of these options goes
  over `tls.connect`.

- **`req.socket` did not name the connection.** A `ClientRequest`'s socket reported the
  host as written, `localAddress` `127.0.0.1` and `localPort` `0`, so a check of
  `req.socket.remoteAddress` / `res.socket.remoteAddress` against a list of internal
  addresses after connecting saw a host name. It now reports the dialled peer's address,
  port and family and the local end (by `'response'`, and on `'connect'` for a request
  sent over an agent's socket); `req.socket` is `null` until `'socket'`, and an https
  socket carries the verified session (`getPeerCertificate()`, `authorized`).

- **`http2.connect` ignored its options.** Every stream went out on oam's shared HTTP
  client, so the session's `lookup`, `createConnection`, `ca`, `servername`,
  `checkServerIdentity` and `rejectUnauthorized` were never applied and
  `session.socket` reported no addresses. A session now runs over one socket, as in
  node: the one `createConnection` returns, else `net.connect` (http:) or `tls.connect`
  offering h2 by ALPN (https:), so those options, a replaced `dns.lookup` and the
  socket's `'lookup'` / `'connect'` listeners apply as they do to that socket, a refusal
  fails the session with its own error, and `session.socket` is node's proxy of the
  real socket. `tls.connect({ socket })` also passes `ALPNProtocols` on.

- **An undici dispatcher's connection policy was ignored.** `import 'undici'` is oam's
  shim even when the package is installed, and the shim honoured only `connect.lookup`: a
  `connect` function (`new Agent|Pool|Client({ connect(opts, cb) })`), the TLS options of
  a `connect` object (`ca`, `checkServerIdentity`, `rejectUnauthorized`, ...), an Agent's
  `factory`, a dispatcher that overrides `dispatch()`, `interceptors`, and a dispatcher
  that is not one of the shim's were all skipped, and oam connected by itself. Now the
  `connect` function is called before every connection -- redirect hops included, on
  `fetch`, the global dispatcher, `undici.fetch`, `undici.request` and `agent.request` --
  and the request goes over the socket it returns and nowhere else; a `connect` object's
  socket and TLS options apply through undici's `buildConnector`, which the shim now
  exports; a factory's dispatchers decide their origins' connections. A dispatcher oam
  cannot run as undici would (an overridden `dispatch()`, `interceptors`, a foreign
  object) fails the request with `NotSupportedError` instead of being skipped.

- **`http` and `https` servers reported every client as `127.0.0.1`.** `req.socket`
  carried a fixed `remoteAddress` of `127.0.0.1` and no port or family, whatever address
  the client connected from, so anything that decides on the peer address (a
  loopback-only route, a loopback `trust proxy` setting, per-IP allow lists and rate
  limits) treated every client as local. `req.socket` now carries the connection's own
  `remoteAddress`, `remotePort`, `remoteFamily`, `localAddress`, `localPort` and
  `localFamily`, spelled as Node spells them, `address()` returns the local end, and
  `req.connection` is the same object. The socket an `'upgrade'` listener receives now
  reports the client's real family (it said `IPv4` for every client) and its local end.

- **The `http` server accepted request heads that Node refuses.** A request carrying both
  `Content-Length` and `Transfer-Encoding` (in either order) reached the handler with
  both headers, and so did a repeated `Content-Length`, a `Transfer-Encoding` with a
  coding after `chunked`, and header lines ending in a bare LF; an upgrade request was
  not checked at all (obs-fold and control characters got through too). A proxy in
  front of the server that frames such a request differently disagrees with it about
  where the request ends. These heads are now answered `400` and the connection is
  closed, as in Node, for `http`, `https` and the HTTP/1 side of `http2.createServer`;
  `insecureHTTPParser` and `--insecure-http-parser` relax Node's framing rules
  (`Content-Length` with `Transfer-Encoding`, bare LF, codings after `chunked`) as Node's
  do, while obs-fold and control characters stay refused.

- **`maxHeaderSize` was not enforced.** Request heads of hundreds of KiB were accepted,
  and the server's `maxHeaderSize` option, `--max-http-header-size` and
  `http.maxHeaderSize` had no effect. Heads are now counted as Node counts them and
  answered `431` at the limit (16 KiB by default), and a head that never ends is refused
  once it outgrows four times the limit (at least 64 KiB) instead of being buffered on.
  `--max-http-header-size` and `--insecure-http-parser` are accepted on the command line
  and in `NODE_OPTIONS`.

- **The `http` server routed upgrade and CONNECT requests differently from Node.** An
  ordinary request could be treated as an upgrade and its connection left open, an
  upgrade could reach the `'request'` handler, and CONNECT never reached a `'connect'`
  listener. Requests are now routed as Node routes them, on any request of a keep-alive
  connection: a request with an `Upgrade` header and `upgrade` in `Connection` goes to
  `'upgrade'` while the server has an `'upgrade'` listener and is an ordinary request
  otherwise, and every CONNECT goes to `'connect'` -- with the tunnel's first bytes as
  `head` -- or, with no listener, has its socket destroyed. `https` servers now close a
  CONNECT rather than hand it to the `'request'` handler.

- **A bare LF in a chunked body's trailers was not refused.** hyper's trailer reader and
  its trailer parser disagreed about where the trailers end, so part of what followed
  was read and discarded while the connection stayed open. Such a body is now answered
  `400` and the connection is closed, as in Node. The same applies to chunked responses
  read by `fetch` and `http.request`, which now fail.

- **Whitespace after a chunk size, and malformed chunk extensions, were accepted.** A
  chunked request body whose size line had spaces or tabs after the size was read as if
  they were not there, and a chunk extension was skipped unread whatever it held, where
  Node, and other parsers, refuse such lines; a proxy in front of the server can frame
  such a body differently. They are now answered `400` and the connection is closed, as
  in Node -- whitespace after the size even under `insecureHTTPParser`, where Node
  accepts it. Chunk extensions are read to Node's grammar in responses too, where `fetch`
  and `http.request` now fail as Node's do. Any other chunked body the
  parser refuses is now answered with Node's status too -- `400`, or `413` for chunk
  extensions over the limit -- where the connection used to close without one, and the
  handler sees its request abort with `ECONNRESET`. `https` and `http2.createServer`
  servers no longer hand a handler a body that failed part way as if it were complete.

- **Framing fields in a chunked body's trailers were accepted.** A `Content-Length` or
  `Transfer-Encoding` field in the trailer section of a chunked request was read as an
  ordinary field and the connection went on to its next request, where Node refuses the
  body; a front end that acts on such a field frames the connection differently. Such a
  request is now answered `400` and the connection is closed, as in Node, and `fetch` and
  `http.request` fail a response whose trailers carry `Content-Length`, as Node's do.

- **Response heads had no size limit either.** `fetch`, `http.request`, `https.request`
  and `undici.request` accepted response heads of hundreds of KiB. They now refuse a
  head at Node's limit (16 KiB, or `--max-http-header-size`), counted as Node counts it
  for each API, on every hop including redirects: `fetch` rejects with `fetch failed`
  and a cause coded `UND_ERR_HEADERS_OVERFLOW`, `http.request` and `https.request` fail
  with Node's own `HPE_HEADER_OVERFLOW` error (`Parse Error: Header overflow`), and
  `undici.request` fails with a cause coded `HPE_HEADER_OVERFLOW`.

- **`http` and `https` servers applied none of Node's connection timeouts.**
  `headersTimeout`, `requestTimeout`, `keepAliveTimeout`, `server.timeout` and
  `setTimeout` were stored and ignored, and TLS handshakes had no time limit, so a
  connection that sent nothing, stopped part way through a request, or sat idle between
  requests stayed open for good. They are now enforced as Node enforces them, with
  Node's defaults (60 s for the headers, 300 s for a request, 5 s plus a 1 s buffer
  between requests, 120 s for a TLS handshake): a late request is answered `408` and
  closed, an idle connection is closed, and the socket timeout emits `'timeout'` on the
  request, response and server, destroying the connection when nobody listens.
  `connectionsCheckingInterval`, `keepAliveTimeoutBuffer`, `handshakeTimeout`,
  `req.setTimeout` and `res.setTimeout` are supported too, and a response whose
  connection is lost before it is sent now emits `'close'`, as in Node.

- **`http`, `https` and `http2` servers stopped taking connections at 256.** Each server
  dropped every new connection once 256 were open, so clients holding that many open,
  idle or busy, kept everyone else out -- for good on `http2.createServer`, whose
  connections had no timeouts. That limit is gone: as in Node, a server takes
  connections for as long as the OS gives them. `server.maxConnections` is supported on
  `http` and `https` servers, with Node's `'drop'` event, and the HTTP/1 connections of
  `http2.createServer` are held to the `http` server's default timeouts.

- **One idle connection stopped an `http` server from accepting.** The server waited
  for a new connection's first bytes before accepting the next one, so a connection
  that sent nothing, such as a browser preconnect, kept every later client waiting. Each
  connection is now read on its own task.

- **The `h2` crate is updated from 0.4.14 to 0.4.19**, which bounds the number of empty
  HTTP/2 DATA frames a peer can have queued (RUSTSEC-2026-0258, GHSA-q83h-524g-xf6h: a
  low-severity denial of service against a stream that is not being read). oam's
  HTTP/2 server (`http2.createServer`) and the `fetch` transport's HTTP/2 connections
  both use it.

- **`http2.createSecureServer` served cleartext.** It ignored `key`, `cert` and every
  other TLS option and returned an `http2.createServer`, so its port spoke HTTP/2 without
  TLS (h2c) and plain HTTP/1.1: a server meant to be reached only over TLS answered
  cleartext clients, and TLS clients could not connect to it. Present since 0.6.0. It is
  now Node's `Http2SecureServer`, a `tls.Server` that offers `h2` by ALPN: a client that
  does not complete a TLS handshake gets no response, only a `'tlsClientError'` on the
  server. A connection that negotiates `h2` is served as an HTTP/2 session (`'session'`,
  `'stream'`, and the `(req, res)` compatibility API for the `'request'` handler); one
  that negotiates `http/1.1` or nothing is served as HTTP/1.1 under `allowHTTP1`, handed
  to an `'unknownProtocol'` listener, or answered with Node's `403` and closed. The TLS
  options below apply to it.

- **`tls.createServer` never asked for a client certificate.** It ignored
  `requestCert`, `rejectUnauthorized` and `ca`, so a server configured to admit only
  clients with a certificate its CA signed admitted every client, with or without one.
  Present since 0.6.0. `requestCert` now asks for a certificate, and it is judged as
  Node judges it: `socket.authorized`, or `socket.authorizationError` with Node's code
  (`UNABLE_TO_GET_ISSUER_CERT` when there is none, `DEPTH_ZERO_SELF_SIGNED_CERT`,
  `UNABLE_TO_VERIFY_LEAF_SIGNATURE`, ...), against `ca`, or the default store without it.
  Under `rejectUnauthorized` (the default) a client with no certificate fails the
  handshake, and one whose certificate does not verify is dropped before
  `'secureConnection'` and never reaches the application.

- **One client could stall a TLS server's handshakes.** `tls.createServer` completed each
  handshake before accepting the next connection, with no time limit, so a client that
  connected and sent nothing held up every client after it. Each connection is now
  handshaken on its own, bounded by `handshakeTimeout` (120 s by default; the connection
  is closed with `'tlsClientError'` `ERR_TLS_HANDSHAKE_TIMEOUT`).

- **`https.createServer` never asked for a client certificate either.** It ignored
  `requestCert`, `rejectUnauthorized` and `ca`, so an https server configured to admit
  only clients with a certificate its CA signed served every client, with or without
  one, and `req.socket` had no `authorized` or `getPeerCertificate()` to check. Present
  since 0.4.0. Each connection now runs the `tls.createServer` handshake above with the
  server's options: under `rejectUnauthorized` a client with no certificate, or one that
  does not verify against `ca`, never reaches the `'request'` handler, and without it
  `req.socket.authorized` / `authorizationError` carry Node's verdict. A failed handshake
  is `'tlsClientError'`, passed on as `'clientError'` as in Node.

- **undici's `MockAgent`, `MockPool` and `MockClient` intercepted nothing.** They were
  constructible stubs, and `disableNetConnect()` did nothing, so a test suite that installed
  a `MockAgent` and expected canned answers sent real requests to the hosts its tests name
  and read the real answers as its mocks -- with no sign that the mock had not been used.
  Present since the undici shim landed. oam's `fetch` owns its transport and cannot be
  intercepted from JS, so the three now refuse at construction with `NotSupportedError`
  (`UND_ERR_NOT_SUPPORTED`), as a dispatcher oam cannot run does. They stay exported, so the
  import resolves and the failure names itself.

### Fixed

- **An http or https server's `req.socket` had no `readable` or `writable`.** on-finished
  reads `!req.socket.readable` as "this request has already finished", so body-parser 2
  skipped the body: every express 5 `express.json()` and `express.urlencoded()` POST left
  `req.body` undefined, and clients of such an app read back `{}`. Both flags are now
  Node's -- true while the connection is up, false with `destroyed` once it is gone -- and
  the response carries the same socket object (`res.socket`, `res.connection`) plus Node's
  deprecated `res.finished`, which on-finished needs to tell a response from a request.

- **`string_decoder.StringDecoder` could not be inherited the ES5 way.** It was a class, so
  `StringDecoder.call(this, encoding)` threw "Class constructor StringDecoder cannot be
  invoked without 'new'". That is iconv-lite 0.4's utf8 decoder, under raw-body 2 ->
  body-parser 1 -> express 4, so every express 4 `express.json()` /
  `express.urlencoded()` request answered a 500. It is a function constructor now, as
  node's is, with its three methods on the prototype.

- **The web classes carried no `Symbol.toStringTag`.** `Object.prototype.toString.call(new
  URL(...))` read `[object Object]`, and so did `URLSearchParams`, `Headers`, `Response`,
  `AbortSignal`, `AbortController`, `Event`, `EventTarget`, `MessageEvent`, `DOMException`,
  `TextEncoder`, `TextDecoder` and the stream classes. Libraries brand-check on that
  string: @sindresorhus/is refused the URL got 14 follows a redirect to, so no got 14
  redirect completed. Each class now carries node's descriptor (a data property on the
  prototype, not writable, not enumerable, configurable), including the four that had a
  getter instead; `BroadcastChannel` reads as the `EventTarget` it extends, as node's does.

- **`tls.rootCertificates` was an empty array and `tls.getCACertificates` was missing.**
  `ca: [...tls.rootCertificates, privateCA]` -- node's usual way to add a private CA to the
  public roots, which `https.request` has honoured since #144 -- therefore trusted the
  private CA alone and every public host failed with `UNABLE_TO_GET_ISSUER_CERT_LOCALLY`.
  `tls.rootCertificates` is now the Mozilla root store oam's TLS client trusts, as PEM
  strings behind node's getter, and `tls.getCACertificates([type])` answers `'default'`
  (the bundled roots plus `NODE_EXTRA_CA_CERTS`), `'bundled'`, `'extra'` and `'system'`
  (the operating system's store), with node's caching, freezing and argument errors.
  `tls.SecureContext` is exported too.

- **A TLS endpoint sent only the certificates in `cert`.** node's OpenSSL completes a
  certificate given on its own from the context's store, so `{ cert: leaf, ca: intermediate }`
  -- a common server configuration -- serves the intermediate, and a client with
  `{ cert, key, ca: [intermediate, root] }` is authorized by a server that trusts the root.
  oam sent the leaf alone, so such a server was `UNABLE_TO_VERIFY_LEAF_SIGNATURE` for every
  client that did not already hold the intermediate, and such a client was refused. It now
  builds the same chain as OpenSSL does, on `tls.createServer`, `https.createServer`,
  `http2.createSecureServer` and the client side alike.

- **`getPeerCertificate(true)` stopped at the certificates the peer sent.** node goes on
  from the last of them through the issuers the connection's store holds, so a server that
  asks for a client certificate reports the CA that signed it, and a client reports the root
  behind a chain the server did not send. oam now does the same on both sides.

- **A truncated encrypted PEM key was `ERR_OSSL_BAD_DECRYPT`** where node reports
  `ERR_OSSL_WRONG_FINAL_BLOCK_LENGTH` (its ciphertext is not whole cipher blocks).

- **The JS heap grew with every callback the event loop ran.** Whatever a loop turn
  touched -- the promise an async op settled and its result, a timer's or immediate's
  callback and arguments -- stayed reachable for the life of the process, so every
  `fs` callback, socket read, timer and immediate kept about half a KiB, even after
  `gc()`, and a server's heap grew with every request (about 650 bytes a request on
  0.16.2) where Node's stays flat. Each turn now releases what it touched, and the heap
  stays flat.

- **`https.createServer` takes node:tls's server options.** An https server is now a
  `tls.Server`, as in Node: its secure context is built at `createServer()` (a key it
  cannot read, one that is not its certificate's, or a wrong `passphrase` throws there
  instead of failing at `listen()`), `passphrase` and `pfx` are read,
  `server.setSecureContext()` and a changed `requestCert` / `rejectUnauthorized` /
  `ALPNProtocols` apply to the connections accepted after them, and `ALPNProtocols`
  defaults to `['http/1.1']` unless `ALPNProtocols` or `ALPNCallback` is given (a client
  offering only `h2` gets `no_application_protocol`, as from Node). `req.socket` reports
  the handshake as Node's `TLSSocket` does (`authorized`, `authorizationError`,
  `alpnProtocol`, `servername`, `getPeerCertificate([detailed])`,
  `getPeerX509Certificate()`, `getProtocol()`, `getCipher()`), and `req.client` is
  `req.socket`, as in Node, on every server. A client that does not speak TLS gets no
  answer and a `'clientError'` (`ERR_SSL_HTTP_REQUEST`, ...), and a TLS 1.3 client whose
  certificate a server refuses after it has sent its request now sees the connection end
  rather than reset, as with Node.

- **TLS servers now negotiate ALPN and report the handshake as Node does.**
  `tls.createServer` honours `ALPNProtocols` (the server's order among what the client
  offers; a client offering only protocols the server lacks gets
  `no_application_protocol`), validates it and `ALPNCallback` / `handshakeTimeout` /
  `SNICallback` as Node does, and reports `socket.servername`. Its secure context is built
  at `createServer()`, which throws Node's errors for a key it cannot read or one that is
  not its certificate's (`ERR_OSSL_UNSUPPORTED`, `ERR_OSSL_X509_KEY_VALUES_MISMATCH`,
  `ERR_OSSL_PEM_NO_START_LINE`); `server.setSecureContext()` replaces it. A failed
  handshake is `'tlsClientError'` with the connection's socket and Node's code, and a
  client that does not speak TLS is refused on OpenSSL's rules for its first bytes
  (`ERR_SSL_HTTP_REQUEST`, `ERR_SSL_WRONG_VERSION_NUMBER`, ...) without an answer it
  could read.

- **TLS servers read encrypted keys and PKCS#12 bundles.** `key` may be an encrypted
  PKCS#8 key (PBES2 with PBKDF2 or scrypt and AES-CBC or triple-DES, or PKCS#12's
  triple-DES PBEs, as `openssl pkcs8 -topk8 -v1 PBE-SHA1-3DES` writes them) or a legacy
  encrypted PEM key (AES-CBC, or `DES-EDE3-CBC` as `openssl rsa -des3` writes it), opened
  with `passphrase` or a `{ pem, passphrase }` entry's own; `pfx` is opened as Node opens
  it, its MAC checked (`mac verify failure`), its bags read whether PBES2-protected,
  protected with PKCS#12's triple-DES PBEs (OpenSSL 1.x's default) or not at all, and its
  other certificates served as the chain and trusted as CAs. The errors are Node's
  (`ERR_OSSL_BAD_DECRYPT`, `bad decrypt` for a bundle without a MAC). What Node 22 no
  longer reads -- single DES, RC2, RC4, Blowfish -- is refused as Node refuses it:
  `ERR_OSSL_EVP_UNSUPPORTED` for a key, `Unsupported PKCS12 PFX data` for a bundle.
  Triple DES comes from the RustCrypto `des` crate, new in the dependency graph.

- **`http2.Http2ServerRequest` and `http2.Http2ServerResponse` are exported**, and an
  HTTP/2 request's headers include `:authority` and `:scheme` on every oam HTTP/2 server.

- **`req.trailers` and `req.rawTrailers` were `undefined` on server requests.** A chunked
  request body's trailer fields were dropped. They are now there once the body has
  ended (empty before, and for a body without trailers), combined as Node combines
  repeated fields.

- **`setImmediate` waited a whole OS timer tick.** It was a 1 ms timer, so an idle loop
  slept to the next timer tick for it -- about 15 ms on Windows, 1 ms elsewhere; 200
  awaited immediates took about 1.8 s on 0.16.2 where node takes 1 ms. An immediate is now
  due at once, and the same 200 take under a millisecond. `http.get` / `http.request` on
  oam's own transport also no longer wait an immediate after `'socket'` unless something
  listens for `'socket'`; 200 sequential
  requests to a local server were never slowed by it (about 75 ms on 0.16.2, about 48 ms
  now, Node about 42 ms).

- **`http.Agent` keeps its sockets alive, as node's does.** A request sent over an
  agent's socket (a custom agent, such as the agentkeepalive agent openai v4 passes to
  node-fetch, or a socket got watches) opened a new connection and TLS handshake
  per request and said `Connection: close`. The agent now pools them with node's rules:
  `keepAlive`, `maxSockets` (requests queue), `maxFreeSockets`, `maxTotalSockets`,
  `scheduling`, the `'free'` event, `freeSockets` keyed by `agent.getName()`, the
  response's `Connection` / `Keep-Alive: timeout=` and framing, `reusedSocket`, and
  node's `Connection` header on the request. A pooled socket is unref'd, and a socket's
  idle timeout no longer keeps the process alive. A request destroyed while it waits
  for a socket hands that socket on and reports `socket hang up`, as in node.
  `agent.destroy()` destroys every socket the agent is holding, and a socket goes back
  into the pool on its response's end whenever the peer has read the whole request --
  node's `req.writableFinished` rule -- so the next request reuses the connection even
  when the write oam sent it has yet to be acknowledged.

- **`req.end(callback)` called the callback with the response.** node calls it on
  `'finish'`, with no arguments; got treated the response as the request's error, so
  every got request failed once it went over a socket.

- **A request on oam's own HTTP transport never timed out.** `req.setTimeout()`, the
  `timeout` option and an agent's `timeout` (the global agents' 5 s included) fired no
  `'timeout'` unless the request went over an agent's socket, so a client that gives up
  on a stalled server waited for it forever. They now fire as node's do: on the request,
  once, after that long without activity -- before the response head, or while its body
  stalls -- and on the response while it is still being read; nothing fires once the
  response has ended, and the value is validated as node validates it. `req.destroy()`
  and `req.abort()` before the response now fail the request with node's `ECONNRESET`
  `socket hang up` (they were silent), on either path; as in node, that `'error'` ends
  the process unless something listens for it.

- **`'finish'` came before the socket connected.** A request sent over an agent's socket
  emitted `'finish'` on the tick after `end()`, before the socket's `'lookup'`,
  `'connect'` or `'secureConnect'`, and even when the connection was then refused; got's
  request timing (`timings.phases.request`) came out `NaN`. It now fires once the socket
  has written the whole request, as node's does, and `req.writableFinished` stays `false`
  until then.

- **`tls.connect({ socket })` works.** TLS over a socket oam did not open -- a CONNECT
  tunnel, the STARTTLS shape (`pg`, `mysql2`, `nodemailer`, `ldapjs`), TLS in TLS, or
  any JS Duplex -- failed with `ERR_FEATURE_UNAVAILABLE_ON_PLATFORM`. It now runs as in
  node, with node's events, the wrapped socket's addresses and the certificate checks of
  any other `tls.connect`. https-proxy-agent (5 and 7) tunnels to https targets through
  it, a refusing proxy's answer included, and got 14 loads (http2-wrapper reaches node's
  `JSStreamSocket` through `new tls.TLSSocket(stream)._handle._parentWrap`).

- **`net.Socket` had no paused mode.** A `'readable'` listener and `socket.read()` --
  how https-proxy-agent reads a proxy's answer -- threw `socket.read is not a function`;
  `push()` into a socket without a handle was missing too. Both now behave as in node.

- **A CONNECT request never emitted `'connect'`.** `http.request({ method: 'CONNECT' })`
  delivered the proxy's answer as an ordinary `'response'`, so an agent that waits for
  `'connect'` -- `tunnel` (under @actions/http-client), hpagent -- never got its tunnel.
  As in node, the answer to a CONNECT is now emitted as `'connect'` with the socket and
  the bytes that came behind the head, whatever its status (a `407` included), and with
  no `'connect'` listener the socket is destroyed. The socket a `'connect'` or
  `'upgrade'` listener receives is handed over unflowing, as node's is, so what the peer
  sends before the new owner reads it waits in the socket instead of being lost, and
  `net.Socket` has node's `unshift()`: the ws client puts back a server's first frame
  that arrived with the `101` that way, and failed with `socket.unshift is not a
  function`. These
  answers' heads are read as node's parser reads them: a malformed status line, a header
  line without a colon, obs-fold, control characters, a repeated `Content-Length` or
  `Content-Length` with `Transfer-Encoding` fail the request with node's `HPE_*` code
  and reason (they were taken as a head, a garbage status line as status `0`).

- **`http.request` rewrote a request target that was not a path.** A `path` in absolute
  form -- how axios's `proxy` option and other forward-proxy clients address the proxy --
  went out as `GET /http://host/p`, `OPTIONS *` as `OPTIONS /*` and a CONNECT's
  `host:port` as `/host:port`. node writes `path` as written, and so does oam now; the
  host dialled is still `host` / `port`, never one named in `path`. The Host header is
  set in the constructor as node sets it, so `req.getHeader('host')` reads it back and
  `req.removeHeader('host')` drops it, and `req._implicitHeader()`, `req._header` and
  `req.outputData` exist: http-proxy-agent (7 to 9, under proxy-agent) builds its
  absolute-form target from them and failed with `req._implicitHeader is not a
  function`.

- **An `http` server rewrote `req.url` and took request targets node refuses.**
  `req.url` came from hyper's URI type, which lowercases an absolute form's scheme, adds
  a `/` after a bare authority, drops a fragment (`/p#f` was `/p`) and turned `*x` into
  `""`; it is now the target byte for byte as sent, as in node, so a forward proxy
  written on oam reads the absolute-form target a proxy client sends. A target that is
  neither a path, `*...` nor absolute form with a scheme of letters (`abc`, `host:443`,
  `1http://x/`) reached the handler with a `req.url` of `""`; it is now answered `400`,
  as by node, on `http`, `https` and the HTTP/1 side of `http2.createServer`.

## [0.16.2] - 2026-09-18

The release that moved `fetch`, `http.request` and `https.request` off reqwest and onto
oam's own HTTP transport, with node's connect algorithm. Alongside it, three ways
`--allow-net` could be got round -- a grant that was not re-checked when a redirect moved
the request, a bracketed IPv6 grant that matched host
names by prefix, and a UDP datagram whose destination was never checked at all -- plus
the stale-connection bug that could leave a `fetch` waiting forever.

### Security

- **`--allow-net` could be bypassed through an HTTP redirect.** The grant was checked
  only against the URL a script passed to `fetch`, `http.request`, `https.request` or
  `undici.request`; the redirects those follow were not checked at all. So under
  `oam --permission --allow-net=<host>`, any granted host -- or anything able to answer
  on its behalf -- could send `302 Location: http://<any other host>/` and the script
  received the response from a host it was never granted: loopback, a cloud metadata
  address, an internal service. A 307 re-sent the request body there too. Measured on
  0.16.1, where every spelling of an ungranted host tried (`localhost`, `LOCALHOST`,
  `localhost.`, `%6c%6fcalhost`, `[::1]`) was reached. Every release since
  `--allow-net` was added in 0.8.3 checked only the initial URL, so all of them are
  affected; a run without `--permission`, or with a bare `--allow-net`, is not. Each
  hop's host is now checked against the grant before it is dialled -- before a
  `connect.lookup` hook is asked about it, and whatever route the request takes, an
  environment proxy included (the destination is checked, not the proxy). A refused hop
  is never contacted, and the request fails with the same `ERR_ACCESS_DENIED` a direct
  request to that host gets (`permission` `Net`, `resource` the host). The host checked
  is the URL parser's normalisation (case, percent-encoding, IDNA and non-canonical IP
  forms folded; a trailing dot kept), the same string the connection dials, so no
  spelling of the `Location` reaches a different host than the one checked. How the
  grant matches a request is otherwise unchanged and is now documented in
  `docs/node-divergences.md` entry 4: on the host alone, so a port-scoped entry
  (`--allow-net=127.0.0.1:8080`) admits `net.connect` to that port but no HTTP request.
  (#143, #151)

- **A bracketed IPv6 grant admitted any host name that began with it.** Under
  `--allow-net=[::1]`, the grant matcher read a target such as
  `[::1].127.0.0.1.nip.io:443` as `[::1]` (it stopped at the first `]`), while
  `net.connect`, `tls.connect` and `https.request` with `rejectUnauthorized: false` handed
  the whole name to the system resolver, so a wildcard DNS name starting with the granted
  literal reached any address it resolved to (measured on macOS, 0.16.1: a connection to
  127.0.0.1, which the same grant refuses by name). `fetch`, `http.request` and WebSocket
  were not affected: they check the URL parser's hostname, which can never start with `[`.
  Present since 0.15.0, when net grants became exact matches; before that the raw prefix
  match admitted the same names. A bracketed entry now matches only the literal itself,
  alone or followed by `:<port>`. (#151)

- **A UDP datagram's destination was never checked against `--allow-net`.** Only
  `dgram`'s `bind` was, and it names the local address, so a script granted any address
  to bind could `send()` to any host and port: with a loopback grant to every other
  loopback address and port, with a `0.0.0.0` grant to any host (a DNS or UDP exfil
  endpoint). Measured on 0.16.1: under `--allow-net=127.0.0.1`, a datagram sent to
  127.0.0.2 was delivered. Every release since `--allow-net` was added in 0.8.3 is
  affected. The destination is now checked by the same rule as `net.connect`
  (`host:port`), and a refused send fails with `ERR_ACCESS_DENIED` through the send
  callback, or `'error'` without one, and is never sent. (#151)

### Changed

- **`fetch`, `http.request` and `https.request` run on oam's own HTTP transport** (#143).
  They went through reqwest, which offers no say in how a connection is made, so node's
  connect behaviour could not be matched. Every outbound connection now follows node
  v22.22.2's `lookupAndConnect` / `lookupAndConnectMultiple`: an IP literal skips DNS, the
  addresses a name resolves to are grouped by family and interleaved, each attempt but the
  last races the attempt timeout, and a failure carries node's system-error shape --
  `hostname`, `address` and `port`, and an `AggregateError` with one error per attempt when
  several addresses were tried.

- **The conformance oracle is now one pinned Node on every build leg.** oam claims
  parity with Node v22.22.2 -- the vendored node-suite corpus is a snapshot of that
  tag, and the 111 node-differential cases and the builtin export-parity ratchet were
  measured against it -- but each leg compared against whatever `node` its PATH found,
  and nothing checked which. The Windows dev box happened to carry v22.22.2; the
  tailnet Mac ran a hand-copied `/usr/local/bin/node` v22.23.1 and the GCP Linux
  builder its image's v22.23.1, so two of the three legs had never once run the
  differential against the version their receipts claimed, and
  `conformance/surface-gaps.json` recorded both their sections as
  `generatedAgainst: v22.23.1`. `.node-version` at the repo root is now the single
  source of truth: the remote legs provision exactly that Node from nodejs.org (the
  official tarball, sha256-verified against the release's `SHASUMS256.txt`, cached per
  version under `~/.cache/oam-node`) and put it first on PATH for the conformance,
  surface-gaps and bench dispatches; `xtask conformance` and the `ci-local.sh`
  preflight refuse any other version before doing any work; `xtask node-suite` refuses
  a vendored corpus whose manifest names a different Node and stamps its receipts from
  the pin rather than a hard-coded string; and `gen-surface-gaps.mjs` refuses to record
  a ratchet section against another node. `OAM_ALLOW_NODE_MISMATCH=1` downgrades each
  refusal to a warning for an ad-hoc local run, and a conformance receipt produced that
  way says on its own line that it is not a parity receipt. Measured after the change:
  linux-x64 and macos-arm64 are each 111/111 on the differential and 0 new / 0 stale on
  the export ratchet against v22.22.2, so the swap changed no result on either -- only
  the honesty of the receipt. The linux and darwin ratchet sections are re-recorded
  against the pin (their name lists are unchanged -- pinning exposed no export
  difference the newer Node had hidden; their stored counts had drifted from the list
  they summarize).

### Fixed

- **A `fetch` could hang forever when the server closed a keep-alive
  connection just as the next request went out on it.** This also affected
  `http.request`, `https.request` and `undici.request`, which ride the same
  op. A typical case is a keep-alive idle timeout, or a `302` followed by a
  FIN with the redirect hop sent at once.

  The cause was in hyper 1.10.1. The request was pushed into the pooled
  connection's dispatch channel while, on the other I/O worker, that
  connection read the FIN, finished and dropped its receiver. tokio's
  close-time drain misses a message that is still being published, so the
  request stayed in the channel. The only thing that would ever answer it is
  the channel's last sender, and hyper-util holds that sender while it
  waits for the answer. There was no socket, no timer and no error: the
  promise never settled, and nothing else could make it settle.

  The fix: oam now builds hyper 1.10.1 with one patch. The dispatch
  receiver's drop closes the channel and drains it until tokio reports no
  send in flight, so the request is handed back unsent. hyper-util then
  sends it again through its pool (an idle connection, or a new one) when
  the closed connection had been reused; on a fresh connection it fails
  with "connection closed", much as node's fails with "other side closed".
  The patch is in `vendor/hyper-1.10.1/`: `OAM-PATCH.diff` is the whole of
  it, `OAM-PATCH.md` has the reproduction and the upstream status
  (hyperium/hyper#4122 and #4150, still open, and they do not cover this
  path), and `scripts/check-vendor.sh` (`ci-local.sh` step 11) fails unless
  the directory is the checksummed crates.io release plus that diff and
  builds warning-free in every client/server x http1/http2 feature set.

  Measured on Windows arm64 with a loop of 20 redirects answered `302` then
  FIN, 500 processes, 6 at a time:
  - 0.16.1 hung 3 processes;
  - `main` before the fix hung 14 and 16 in two passes;
  - the fix hung none in either pass.

  A single process sending 20,000 such fetches hung 2 of 6 runs on 0.16.1
  and 6 of 6 on `main` before the fix. With the fix, 0 of 6 runs hung.

  This did ship. 0.16.1's `fetch` runs on reqwest over the same hyper 1.10.1,
  and releases back to 0.13.2 pin that same hyper; releases before 0.13.2
  were not checked. Pinned by
  `crates/oam_core/tests/http_client_stale_pool.rs`. On stock hyper its
  in-memory race test failed 10 of 10 runs, 5 on Windows and 5 on macOS.
  (#151 follow-up)

- **Requests were written onto keep-alive connections the server had already
  closed, so a `POST` failed where node's succeeded and a `GET` reached the
  server twice.** A pooled connection answered reads from tokio's readiness
  cache, which learns of the server's FIN only when an I/O worker next polls
  for events. With both workers busy -- a redirect loop sends its hop with no
  event-loop tick after the 3xx -- a FIN the kernel already held went unseen,
  and the next request was written into the dead connection. node's event
  loop reads the FIN first and opens a new socket.

  A read that tokio reports pending is now checked against the kernel (a
  one-byte peek, no copy), so the idle connection reads the EOF before it
  takes the request and hands the request back unsent. Measured on Windows
  arm64 against a node server that sends a 3xx with keep-alive and then FINs
  at once (320 processes of 50 fetches, 8 at a time):
  - `POST` + `307`: 12,065 of 16,000 fetches failed before; 595 and 1,137 in
    two runs after. node v22.22.2 failed none.
  - `GET` + `302`: the server received the hop twice for 12,739 of 16,000
    fetches before; 1,177 and 1,383 after. node: none.

  What remains is a FIN still in flight when the hop is written. node sends
  its hop late enough to miss that race in this shape; when the FIN comes 0-5
  ms after the 3xx, node loses it too (2,587 of 16,000 such `POST`s failed in
  node, 1,948 in oam). A pooled connection that dies before any part of a
  response arrives costs an idempotent request one resend.

  That resend now happens **at most once per hop**, and only when **not a
  byte** of a response arrived. An earlier cut of this change resent up to
  three times, which delivered one `GET` four times and reported success
  where node delivers it once and rejects (RFC 9110 s9.2.2: no automatic
  retry of a failed automatic retry). And hyper reports a connection that
  closed halfway through a response head with the same error as one that
  closed before answering; each connection now counts the response bytes it
  reads, so a server that had started to answer is never sent the request
  again. The resend is otherwise as before: idempotent methods, a body that
  can be sent again, a connection an earlier request had used.
  (#151 follow-up)

## [0.16.1] - 2026-09-14

TLS protocol-version pinning.

### Fixed

- **`minVersion` / `maxVersion` / `secureProtocol` were ignored, so a TLS handshake could
  not be pinned to a protocol version** (#144). They are now honoured by `tls.connect`,
  `tls.createServer`, `https.createServer` and `https.request`, with Node's synchronous
  `TypeError`s and its asynchronous codes (`ERR_SSL_NO_PROTOCOLS_AVAILABLE`,
  `ERR_SSL_TLSV1_ALERT_PROTOCOL_VERSION`), pinned by
  `conformance/cases/109-tls-protocol-version.mjs`. Per-request TLS options on
  `https.request`'s verifying path remain unapplied (#146).

## [0.15.3] - 2026-09-14

What a socket reports, and what `oam check` can read. A TLS socket gained
the `net.Socket` API that ioredis and its neighbours reach for, sockets and servers
learned to release the event loop on `unref()`, a refused connection stopped taking
two seconds on Windows and started carrying Node's code, and `oam check` stopped
losing oam's declarations on the two tsconfig shapes most projects use.

### Fixed

- **`socket.unref()` and `server.unref()` did not release the event loop**
  (#140). They removed the handle from `process.getActiveResourcesInfo()` as
  Node's do, but a connected, reading, unref'd `net.Socket` or `tls.TLSSocket`,
  and an unref'd listening `net.Server` or `tls.Server`, still kept an oam
  process alive where Node exits at once, so a client library that opens a
  keep-alive connection and `unref()`s it (redis clients, loggers, telemetry
  exporters) hung the process. The engine's stdin-only ref accounting is now
  per-handle accounting: a parked read or accept on an unref'd handle stops
  counting toward liveness, `ref()` re-pins it, an unref'd socket still
  receives data while something else keeps the process alive, writes and
  shutdowns keep pinning the loop as libuv's requests do, and `unref()` before
  the handle exists is applied once it does, as Node defers it to
  `'connect'`. Pinned by three conformance cases (a net and a tls client with
  every socket unref'd, and an `unref()` then `ref()` kept alive by an
  unref'd timer) and wall-clock e2e tests.

- **`net.Socket` state before connect and after close.** `socket.address()`
  is `{}` before connect and after close (it always returned an endpoint
  object); `socket.pending` is `!handle || connecting`, true on a fresh socket
  (it read `connecting` alone); and `net.connect(options)` honours
  `allowHalfOpen` and `timeout`, so a half-open client ended by its peer reads
  `writeOnly`, not `closed`. A server-side (accepted) socket also reports its
  own local address, so `socket.address()`, `localAddress`, `localPort` and
  `localFamily` are populated on a `'connection'` socket where they were `{}`
  and `undefined`. Every value measured on Node.

- **`getProtocol()`, `getCipher()` and `getPeerCertificate()` on a TLS socket
  were rustls's Debug names and `{}`** (#138). `getProtocol()` returned
  `TLSv1_3` and `getCipher().name` `TLS13_AES_256_GCM_SHA384`, so code that
  switches on `getProtocol() === 'TLSv1.3'` or logs a cipher name diverged,
  and `getPeerCertificate()` gave a connected socket nothing to inspect. Both
  a `tls.connect()` socket and an accepted one now report OpenSSL's names
  (`TLSv1.3`; `{ name: 'TLS_AES_256_GCM_SHA384', standardName, version }`,
  with the OpenSSL name next to the IANA `standardName` for the TLS 1.2
  suites); `getPeerCertificate([detailed])` returns Node's legacy object
  (`subject` and `issuer` as null-prototype objects, `modulus`/`bits`/
  `exponent`/`pubkey` or `bits`/`pubkey`/`asn1Curve`/`nistCurve`,
  `valid_from`/`valid_to` in OpenSSL's spelling, the three fingerprints,
  `subjectaltname`, `infoAccess`, `ext_key_usage`, `serialNumber`, `raw`, and
  with `detailed` an `issuerCertificate` link through the chain, a self-issued
  last certificate pointing at itself); `getPeerX509Certificate()` and
  `getEphemeralKeyInfo()` (`{}` after TLS 1.3, `{ type, name, size }` after
  TLS 1.2, `null` on a server-side or destroyed socket) are added, and every
  getter is `{}` or `undefined` before the handshake and `null` once the
  socket is destroyed, as measured on Node. `crypto.X509Certificate` gains
  `fingerprint512`, `infoAccess` and a complete `toLegacyObject()`, and four
  of its fields now carry Node's values where they did not: `validFrom`/
  `validTo` print as OpenSSL does (`Jun 15 12:30:07 2026 GMT`), `serialNumber`
  keeps a leading zero nibble, `keyUsage` is the extended-key-usage OID list
  and `subjectAltName` is `undefined` without the extension, and `ca` follows
  `X509_check_ca` (a KeyUsage without keyCertSign is not a CA). Not covered:
  `minVersion`/`maxVersion` are still not honoured, so a TLS 1.2 handshake
  cannot be pinned from JS; the names of its six suites are unit-tested.

- **`oam check` lost oam's declarations on any tsconfig chain that uses
  `${configDir}`**, and on any project with an `outDir` but no `rootDir`. The
  template names the root config's directory, and through the generated
  wrapper the root was the wrapper, so #135 fell back to a bare check
  (TS2307 on `oam:` imports) whenever the template appeared. The wrapper now
  restates every key whose effective value names the template (`files`,
  `include`, `exclude`, `outDir`, `declarationDir`, `rootDir`, `rootDirs`,
  `outFile`, `tsBuildInfoFile`, `baseUrl`, `generateTrace`, `typeRoots` and
  `paths` values) with the project's directory substituted, exactly as
  `tsgo -p tsconfig.json` resolves them, measured against tsgo including its
  start-of-value and case quirks; `types`, `references` and the source-map
  roots are not substituted by tsgo and stay inherited. Separately,
  TypeScript 7 defaults `rootDir` to the config directory and checks it
  eagerly whenever `outDir`, `declarationDir`, `sourceRoot` or `mapRoot` is
  set, so such a project without an explicit `rootDir` failed the wrapper
  run with TS6059 and was silently checked without oam's declarations; the
  wrapper now restates that default too. `OAM_DEBUG=1` names the keys
  restated.

- **A refused TCP connect took about 2 s to fail on Windows** (#137). The
  stack retransmits the SYN of a connect to a closed loopback port before it
  reports `ECONNREFUSED`; libuv tells it not to (`SIO_TCP_INITIAL_RTO`, for
  loopback targets only), so node reports the refusal in milliseconds while
  every `net.connect` and `tls.connect` under oam waited about 2 s, and
  `tls.connect(port)` paid it on every call: its default host, `localhost`,
  resolves to `::1` first on Windows, and an IPv4-only listener refuses that
  before the `127.0.0.1` attempt. oam's connect now does what libuv does, for
  `net` and `tls` alike; the resolved-address loop and the error shape are
  tokio's, byte for byte. `http` and `fetch` go through reqwest's own
  connector, which cannot be told this, and keep the 2 s on Windows
  (`docs/node-divergences.md` #35).

- **`fetch` and `http.request` reported a refused connection as
  `ECONNRESET`, or with no code at all.** reqwest's error text stops at
  "error sending request" and the refusal sits deeper in its source chain,
  so the http client guessed `socket hang up` / `ECONNRESET` from the text
  and `fetch` rejected with that text as its message and no `cause`; retry
  logic keyed on `err.code === 'ECONNREFUSED'` never fired, and a hostname
  that did not resolve looked the same as a dead server. The native op now
  walks to the connector's `io::Error` and reports node's shape: `fetch`
  rejects with the bare `TypeError: fetch failed` and the transport error as
  `cause`, `http.request` emits that error, and both carry `errno`, `code`
  (`ECONNREFUSED`, `ETIMEDOUT`, `ENOTFOUND`, `EAI_AGAIN`, ...), `syscall`
  and the peer (`address` and `port` for `connect`, `hostname` for
  `getaddrinfo`), with node's `connect ECONNREFUSED 127.0.0.1:8080` and
  `getaddrinfo ENOTFOUND host` messages. Pinned by
  `conformance/cases/102-fetch-http-refused-error-shape.mjs`, byte-identical
  with node for an IPv4 and an IPv6 refusal and an unresolvable name.

- **A TLS socket lacked the `net.Socket` API, and ioredis crashed over
  `rediss://`** (#132). In Node `tls.TLSSocket` extends `net.Socket`; oam's
  extended `stream.Duplex` and shared no base with its `net.Socket`, so a
  `tls.connect()` socket had no `setNoDelay`, `setKeepAlive`, `setTimeout`,
  `ref`, `unref`, `address`, `connect`, `readyState` or `pending`, and
  `instanceof net.Socket` was false. ioredis calls `setNoDelay(true)` then
  `setKeepAlive(true, 0)` on every connection, so a `rediss://` client threw
  `TypeError: stream.setNoDelay is not a function` from the connect callback
  and the process died; a database driver's idle `setTimeout`, a background
  connection's `unref()` and an `address()` for logging broke the same way.
  A TLS socket now carries the `net.Socket` surface with Node's semantics,
  every value probed against Node v22.22.2:
  - `setNoDelay` / `setKeepAlive` are chainable no-ops, as on `net.Socket`.
  - `setTimeout(msecs[, callback])` is an idle timer re-armed by every read
    and write, firing `'timeout'` with the socket still open. It has Node's
    contract on both `net.Socket` and `tls.TLSSocket`: `msecs` must be a
    non-negative finite number (`ERR_INVALID_ARG_TYPE` / `ERR_OUT_OF_RANGE`),
    `socket.timeout` mirrors the value, `setTimeout(0, cb)` removes `cb`
    rather than adding it a second time, and a destroyed socket ignores the
    call. `tls.connect({ timeout })` arms it, as in Node.
  - `ref()` / `unref()` drive `process.getActiveResourcesInfo()` and
    `process._getActiveHandles()`, where a TLS socket now appears as a
    `TCPSocketWrap` from the moment `tls.connect()` returns, as in Node.
  - `address()` is `{}` until connected and again after close, then
    `{ address, family, port }` for the local endpoint; `localAddress`,
    `localPort`, `localFamily`, `remoteFamily`, `bufferSize`, `bytesRead` and
    `bytesWritten` are populated (`bytesWritten` counts a queued write at
    once, Node's formula), and `remoteAddress` is the resolved IP rather than
    the host name given (Node reports `127.0.0.1` for `localhost`). Both
    native TLS ops now return the transport's local and peer addresses in
    `tcp_connect`'s shape.
  - `readyState` / `pending` / `connecting` follow Node: `"opening"` / `true`
    / `true` from construction until the transport connects (which on oam is
    the same instant the handshake completes), `"closed"` / `true` after
    destroy.
  - A write or `end()` issued before the connection exists is queued and
    sent on `'connect'`, as Node queues them; a socket that dies first fails
    the write with `ERR_SOCKET_CLOSED_BEFORE_CONNECTION`.
  - `tls.connect(port[, host][, options][, callback])` takes every shape Node
    documents. It used to accept only `(port, host, cb)`: with `(port, host,
    options)` the options object was taken for the listener and the call
    threw, and with `(port, options, cb)` the options were dropped, so
    `rejectUnauthorized`, `servername`, `ca` and `host` were lost.
  - `connect(options[, cb])` and `connect(port[, host][, options][, cb])` work
    on a `new tls.TLSSocket(null, tlsOptions)`, reusing the constructor's TLS
    options, with the callback on `'connect'` as for `net.Socket`. A second
    `connect()` on a connecting or connected socket destroys it with
    `EISCONN`, and `connect()` on a destroyed socket reconnects it, both as
    Node does; the two used to be silent no-ops that dropped the callback.
  - The `socket` option (and constructor argument) is refused with
    `ERR_FEATURE_UNAVAILABLE_ON_PLATFORM` on the next tick: oam cannot wrap an
    existing plain socket in a client-side TLS session, and the call used to
    open a new connection to the default host and port instead, hanging in
    `"opening"`.
  - `'connect'` and `'ready'` fire before `'secureConnect'`, in Node's order.
  - `tlsSocket instanceof net.Socket` is true. The two classes still cannot
    share a base, so `net.Socket` answers by a brand its kin carry rather
    than by prototype; `Object.getPrototypeOf` walks differ from Node
    (divergence 34).
  - A TLS socket is read from the moment it connects, consumer or not, as
    Node reads it: a peer's EOF is seen, `'end'` fires even with nothing
    consuming, the write side is ended after `'end'` (so an `'end'` listener
    still sees the socket writable, as in Node), and once both sides are done
    the socket emits `'close'` with Node's `hadError` boolean, a loop turn
    later, releases its native handle, and leaves
    `getActiveResourcesInfo()`. It used to read only once a consumer
    attached, and ran with stream `autoDestroy` off, so a socket nobody read
    from sat open forever and `'close'` never followed `'end'` + `'finish'`;
    ioredis reconnects on `'close'`.
  - On the server side an accepted socket reports `authorized: false`
    (Node's value without `requestCert`), `timeout: 0`, and the same fields;
    a listening `tls.Server` is a `TCPServerWrap` in the resource views, has
    `ref()` / `unref()`, and `address().family` says `IPv6` for a `::1`
    listener.
  A conformance case walks every public member of the runtime's own
  `net.Socket` (prototype and instance fields) against a `tls.connect()`
  socket, byte-identical with Node, so the next missing member fails the gate
  instead of a library.

- **`oam check` failed every project with `"types": ["node"]` in its
  tsconfig** (#130), reporting an internal `OAM-TS0004` carrying
  `TS2688: Cannot find type definition file for 'node'` where `tsc` and `tsgo`
  both pass. oam checks a project through a generated config that `extends`
  the user's and adds oam's own declarations, and TypeScript resolves a
  `compilerOptions.types` entry from the ROOT config's directory -- the default
  typeRoots walk and the `node_modules` fallback both start there, never at the
  config that declared the entry. With the wrapper under oam's cache dir, the
  lookup for `@types/node` walked up from beside oam's cache and found nothing.
  Two things went wrong on top of that: `TS2688` has no `file(line,col)`
  prefix, so it was dropped rather than reported, and the check's retry against
  the user's own tsconfig -- which exited clean -- was discarded for producing
  no diagnostics, so a project that type-checks came back as an internal error.
  Now:
  - The wrapper is written under `node_modules/.oam/ts-decls/` at the
    project's nearest `node_modules` (the hoisted one of a monorepo root when
    the package has none) -- the directory oam already keeps `--precompile`
    output in, gitignored the same way -- so every lookup walks the same
    directories the user's tsconfig would. A bare `@types` name, a self-typed
    package such as `vitest/globals` and a hoisted install all resolve;
    `--incremental` is unaffected. Nothing is written anywhere else in the
    project. oam's cache dir is the fallback when no `node_modules` exists at
    or above the project or it cannot be written; a project that names a
    package in `types` is then checked without oam's declarations rather than
    through a wrapper that cannot resolve it (from the cache dir a stray
    `~/node_modules/@types` could even resolve where the project's own config
    fails). `OAM_DEBUG=1` reports every such fallback.
  - A relative `types` entry (`"./typings/local"`), which TypeScript resolves
    against the root config whichever config in the chain declared it, is
    restated absolute against the user's tsconfig dir.
  - A `composite` project's default `rootDir` -- also the root config's
    directory -- is restated as the user's tsconfig dir, so every source no
    longer lands "not under rootDir" (TS6059) through the wrapper.
  - `references` is restated too: it is the one top-level key `extends` never
    carries, so the wrapper's program used to check a referenced project's
    sources directly. An import into an unbuilt reference now reports TS6305
    through `oam check` exactly as it does through `tsc -p`.
  - A chain that uses `${configDir}` gets no wrapper. TypeScript substitutes
    the root config's directory, so a base config's
    `"include": ["${configDir}/src"]` matched nothing through the wrapper and
    the check came back clean with a type error present. Such a project is
    checked against its own tsconfig, with TS2307 on `oam:` imports.
  - A span-less `error TSnnnn:` line is a diagnostic in its own right, with its
    elaboration lines attached, instead of an `OAM-TS0004`.
  - A clean retry is a clean check. The retry now runs whenever every
    diagnostic of the wrapper run is attributable to the wrapper (no span, or a
    span inside the wrapper file), and its result is used whenever it exits
    clean or says something -- only a retry that also failed without saying why
    falls through to the wrapper's own output.
  - The daemon's fingerprint covers the files the user's own tsconfig reads
    when the wrapper's `--listFilesOnly` fails, so a cached verdict reached
    through the retry is still invalidated by an `@types` upgrade. It also
    stamps whether a `node_modules` exists at each level above the project:
    a verdict cached while it was missing (a TS2688 for the missing types) is
    no longer served after a reinstall that leaves the lockfile alone.

## [0.15.2] - 2026-09-13

Windows behaviour and the honesty of the sidecar release gate. OS errors
carried Node's codes, a child no longer outlived the process that spawned it, and
`process.stdin` emitted `'close'`. The gate itself had been comparing oam against oam
while reporting "verified against node"; it now runs a real tool call per sidecar,
fails one that leaves a process behind, and records what it actually tested.

### Changed

- **The sidecar release gate reports what it tested.** Each row carries the resolved
  sidecar version, the summary states how many of the advertised tools were actually
  called, `--json=<path>` writes a machine-readable report (release-local.sh keeps it
  beside the conformance stamps, outside the published assets), and progress text is
  only rewritten in place on a terminal, so a captured log no longer runs lines
  together.

### Fixed

- **On Windows, OS errors carried a different code than node reports.** oam
  named an OS error by std's `io::ErrorKind` instead of the raw Win32 code, and
  the kind is a lossy view of the number. A write to a read-only file, an
  `unlink` of a directory, a `setRawMode` on a read-only console and an ACL
  denial all came back `EACCES` / -4092 where node says `EPERM` / -4048; a
  sharing violation came back `EIO` where node says `EBUSY`; a text file spawned
  as a program came back `EIO` where node says `EFTYPE`; and the OS's own
  sentence ("Access is denied. (os error 5)") leaked into the message.
  `node_error_code` now translates a raw code through libuv's own table
  (`uv_translate_sys_error`, src/win/error.c, v1.51.0), and messages use libuv's
  wording, checked entry for entry against `util.getSystemErrorMessage`'s table.
  An error with no OS code -- rustls's, say -- keeps its own text.
  On top of the table, oam now applies the per-operation rules libuv adds:
  - `open(dir, 'w')` and `writeFile(dir)` are `EISDIR` (and `'wx'` is `EEXIST`).
  - `readFile(dir)` is `EISDIR` on `read`, and `appendFile(dir)` is `EISDIR` on
    `write`, neither with a path.
  - `mkdir` of an invalid name is `EINVAL`, and so is `readlink` of a file that
    is not a link.
  - A program named by path is resolved the way libuv's search does: the name
    as given only when it has an extension, then `.com`, then `.exe`, never a
    directory, relative to `cwd`. Spawning a directory or an extensionless
    shell shim is now `ENOENT`, as in node, where oam reported a permission
    error or ran the file.
  - `spawn()` THROWS a failure node does not emit as an event: every code
    except `EACCES`, `EAGAIN`, `EMFILE`, `ENFILE` and `ENOENT`, e.g. `EPERM` or
    `EFTYPE`, with node's `spawn <CODE>` shape. It used to emit an `'error'`.
    `fork()` and an `'ipc'` stdio slot still emit, because they spawn only
    after the channel binds.
  - `spawnSync`'s `result.error` now carries `errno`, `syscall`, `path` and
    `spawnargs`, with node's `spawnSync <file> <CODE>` message where it used to
    carry only the OS text.

  On Linux and macOS a raw errno is now named by its number too: `EPERM`, which
  std folded into `EACCES` while the errno already said -1, and `EMFILE`,
  `ENFILE`, `EXDEV`, `ENOSPC` and the rest std has no kind for, which were `EIO`
  -- so a spawn that runs out of descriptors emits `EMFILE` like node.

  Still divergent on Windows, and known: `fs.open(dir)` for reading succeeds in
  node, which takes directory descriptors oam does not have; `stat` of a locked
  system file such as `pagefile.sys` is `EBUSY` where node falls back to
  `EPERM`; operations on the `NUL` device report `EISDIR` where node treats it
  as a character device; and for a BARE program name, spawn's PATH search still
  differs from libuv's. **This is a behaviour change** for any code that compared
  a Windows error code against `EACCES` or `EIO`. (#134)

- **On Windows, a raw-mode switch on a cold start could echo a stray newline or
  put the cursor back after the next write.** `setRawMode` cancels the stdin read
  in flight and must not flip the console mode until that read has settled.
  libuv waits for it with no timeout; oam gave up after 250 ms, which the first
  run of a freshly written binary -- pages still being faulted in and scanned --
  ran past. The cancelled Enter was then handled under the new mode: going back
  to cooked mode echoed it as a newline, and going raw from a prompt on the last
  row moved the cursor after the program had already written. Measured 2
  failing runs in 5 on a freshly copied binary. The wait now returns when the
  read settles, as before, but its bound is a 5 s backstop against a read that
  can never settle rather than a latency guess. The console e2e now also runs
  against both Windows release assets, win-x64 under emulation included, before
  a release publishes. (#109)

- **The sidecar release gate's "verified against node" rows were oam against oam.**
  Every @yawlabs sidecar's `bin` is a runtime launcher that prefers oam, so the
  control arm's `node <bin>` re-spawned oam -- measured with a process-tree walk --
  and fetch and ctxlint passed a comparison that compared oam with itself. The control
  arm now sets the launcher's own `*_RUNTIME` switch to `node`, read from its source
  rather than listed, and a launcher that names no switch is refused instead of
  trusted.

- **Every sidecar in the release gate now answers a real tool call; six were
  boot-only.** None needs a credential or the internet: tailscale's network-free
  `tailscale_tool_groups`, Lemon Squeezy's webhook sink pointed at the loopback
  server, redis against a Redis wire-protocol fake with fixed replies, postgres
  against the local server with a SELECT that crosses bytea, and puppeteer and
  playwright driving the Chromium-family browser already installed, headless, in a
  profile the harness owns. A dependency that is genuinely missing DEMOTES the row
  with the reason and makes the run incomplete (exit 3) -- before, a loopback bind
  that failed quietly turned fetch into "boot only" and exited 0. Inherited
  credentials and configuration are scrubbed from each sidecar's environment, so
  "needs no credential" holds on a box that has one.

- **The release gate now fails a sidecar that leaves a process behind.** Each probe
  shuts the sidecar down the way a host does (stdin closed, then killed) and checks
  its direct children against the node control. On Windows, node's libuv places
  children in a kill-on-close job object and oam does not, so on oam 0.15.1 both
  browser sidecars leave their browser running where node leaves none -- and the gate
  now says so rather than passing them.

- **puppeteer no longer SKIPs the gate on an interrupted browser download.** Its
  postinstall fetches a Chrome the gate never used, and a half-extracted copy in the
  user cache failed the whole batch install. `PUPPETEER_SKIP_DOWNLOAD=1` is set for
  the install, and a failed install now reports its error or its timeout rather than
  the first deprecation warning npm printed.

- **On Windows, a child outlived the oam process that spawned it when that process
  was killed.** node's libuv puts every non-detached child in a process-global job
  object with `JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE`, and the kernel closes the job's
  only handle however the parent ends -- a clean exit, a crash, `TerminateProcess` --
  which takes the children down with it. oam had no job, so a sidecar killed by its
  host left its browser running, and a script that spawned
  `node -e "setInterval(()=>{},1e9)"` with stdio ignored still had it running 1.5s
  after the script was killed, where under node it is gone. oam now keeps the same
  job, flag for flag (`KILL_ON_JOB_CLOSE`, `BREAKAWAY_OK`, `SILENT_BREAKAWAY_OK`,
  `DIE_ON_UNHANDLED_EXCEPTION` -- so a grandchild a child starts on its own is not a
  member, exactly as under node), on every path behind `child_process` and
  `cluster`: `spawn`, the extra-fd `CreateProcessW` spawn, `execFile` and the shell
  `exec` starts, `fork`, `cluster.fork`, and `spawnSync`, whose child now dies too if
  oam is killed while blocked on it. The extra-fd path creates the child suspended
  and resumes it only once it is in the job; tokio's and std's `Command` cannot
  resume a suspended child, so those paths join it right after the spawn, which is
  where libuv joins every child. `detached: true` children stay out of the job --
  and now also get libuv's `DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP`, where oam
  used to ignore the option on Windows -- as does the `oam_ts` checker daemon. A job
  that cannot be created or joined (oam itself inside a job that forbids nesting)
  degrades to the old behaviour rather than failing the spawn. POSIX is untouched: a
  child there outlives its parent under node as well. A new e2e test kills a real
  `oam run` with `TerminateProcess` and checks a child from each of those seven paths
  is gone and a `detached` one is not; it fails on 0.15.1, where all eight survive.

- **`process.stdin` emitted 'end' but never 'close' when a parent closed the pipe.**
  node builds stdin's class from what fd 0 is: a pipe or socket is a `net.Socket`
  and a terminal a `tty.ReadStream`, both of which destroy themselves after 'end',
  while a file -- a `< input.txt` redirect, or the null device `stdio: 'ignore'`
  attaches -- is an `fs.ReadStream` opened with `autoClose: false` that emits 'end'
  alone. oam made every stdin the file shape, so an MCP server that shuts down on
  stdin 'close' (`process.stdin.on("close", () => server.close())` in
  `@modelcontextprotocol/server-puppeteer`) never did when its host disconnected,
  and leaked the browser it owned -- which the sidecar release gate reported as a
  FAIL. stdin now classifies fd 0 as libuv's `uv_guess_handle` does (TTY, FILE,
  PIPE, UNKNOWN) and destroys itself after 'end' for everything but a FILE.
  Conformance case 98 checks pipe, file and ignored stdin -- data, `readable` plus
  `read()`, a handler that shuts down on 'close', `destroy()` before and after EOF,
  and `for await ... break` -- against node, and differs from node on 0.15.1.

## [0.15.1] - 2026-09-12

Raw mode and signals at the terminal. Going raw right after a prompt could
overwrite the answer line, a program killed by SIGINT or SIGTERM left the terminal raw,
and a signal could be swallowed or land under another isolate's handler.

### Changed

- **A failed `setRawMode` emits Node's error shape.** oam built an error with
  `code` `'ERR_SYSTEM_ERROR'` and `syscall` `'uv_tty_set_mode'`; Node v22.22.2's
  `lib/tty.js` emits `new ErrnoException(err, 'setRawMode')`, whose `code` is
  `util.getSystemErrorName(err)`, message is `setRawMode <code>` and `syscall` is
  `'setRawMode'`, with `"Unknown system error <n>"` for an errno the table does
  not map. **This is a behaviour change**: a program branching on `err.code`
  never matched before. Checked against Node's source only -- no test reaches this
  branch: it needs a console that refuses `SetConsoleMode`, and the one harness
  that has such a console (#109) is `#[ignore]`d. (#125)

- **The Windows console mode oam leaves behind is documented** as divergence 33 in
  `docs/node-divergences.md`. libuv's `uv_tty_set_mode` writes a fixed input mode
  in each direction and only restores the startup mode at a normal exit, while oam
  clears `ENABLE_LINE_INPUT | ENABLE_ECHO_INPUT | ENABLE_PROCESSED_INPUT` from the
  mode it finds, adds `ENABLE_VIRTUAL_TERMINAL_INPUT`, and puts back the mode it
  saved on `setRawMode(false)`. Going by the source the program reads the same
  bytes either way; what differs is the console mode between a raw round trip and
  exit, which shows to anything that queries or reads the console in that window
  -- the program itself, or a child that inherits the console without setting its
  own mode. No behaviour changed here; it is written down. Read out of both
  implementations, not measured side by side. (#125)

### Fixed

- **On Windows, going raw right after a prompt could overwrite the answer line.**
  `setRawMode` flipped the console mode first and cancelled the stdin read in
  flight afterwards, so the synthetic Enter that cancels the read was handled
  under the NEW mode -- and a raw read returns that Enter as one silent byte, a
  bare carriage return with nothing echoed, so no newline scrolled the buffer the
  way libuv's last-row cursor adjustment assumes. With the prompt on the screen
  buffer's last row the cursor came back one row too high and the next output
  landed on top of the answer (reproduced in a real conhost: "name? bob" became
  "MARK? bob"). The switch now runs in libuv's order -- hold the reader, cancel
  while the read's own mode is still in force, flip, release -- and what the Enter
  writes to the screen is derived from that pre-flip mode: a line read writes it
  whether or not it echoes, CRLF with `ENABLE_PROCESSED_INPUT` and a bare CR
  without, while a raw read writes nothing (`readDataCooked.cpp`, measured on
  conhost 10.0.26100.1), so the cursor steps up a row only when a newline actually
  scrolled it. The switch is also serialised process-wide now, so a second
  `setRawMode` -- a Worker's, or the exit hook's -- cannot read the console mode
  or the saved slot mid-switch and save a raw mode as the "original". A
  `setRawMode(false)` whose `SetConsoleMode` fails also keeps the saved original
  mode now, where it used to be taken out of the slot and lost with the error,
  leaving the exit hook nothing to put back. (#125)

- **A raw program killed by SIGINT or SIGTERM left the terminal raw.** oam
  installed a native handler for a signal only when a JS listener asked for one,
  so a program that had called `setRawMode(true)` and was then killed without one
  died at `SIG_DFL` with the exit hook never running -- and a shell left raw does
  not recover by itself. `setRawMode(true)` now arms a process-wide default action
  for SIGINT and SIGTERM (`signal::serve_default_action`), which restores the
  terminal, then restores `SIG_DFL` and re-raises, so the process still dies by
  that signal and the parent sees it; Node does the same from a handler it
  installs at startup whether or not JS listens (`SignalExit` -> `ResetStdio` in
  `src/node.cc` -- read from Node's source). The restore follows
  `uv_tty_reset_mode` rather than the ordinary switch -- `TCSANOW` where the
  switch drains with `TCSADRAIN`, SIGTTOU blocked, retried on `EINTR`, and giving
  up rather than waiting behind a switch on another thread -- so a stalled
  terminal cannot hold a dying process. A stop is not a death: a SIGTSTP with no
  listener leaves raw mode intact, as Node does. **This is a behaviour change** on
  Unix; Windows is untouched. (#125)

- **A signal could be swallowed, or kill the process under another isolate's
  listener.** Each signal handle reproduced the OS default as soon as its own
  listeners were gone, which a second isolate made wrong in both directions: a
  dormant handle in one isolate killed the process while another isolate was
  still listening, and a handle that died with its run -- `oam test` builds a
  runtime per file, and a Worker or `oam.fork` isolate has its own -- left
  tokio's process-global handler installed with nobody receiving, so every later
  delivery was caught and discarded (a SIGINT during the second file of
  `oam test` hung the runner). Whether anyone is listening is now decided for the
  whole process, from a count of watched handles across every isolate, and one
  never-dropped task per signal serves the default. (#125)

- **`scripts/bump-taps.sh` crashed inside its own EXIT trap on an early abort.**
  `cleanup()` guarded the two tap directories but dereferenced `$BREW_FILE` and
  `$SCOOP_FILE` bare, and both are assigned long after the trap is armed -- so
  under `set -u` every failure in that window (no published `SHA256SUMS`, the
  downgrade guard, a missing asset hash) died with `BREW_FILE: unbound variable`
  inside the trap, appending a bash error about the script's own bookkeeping to
  the diagnosis the operator actually needs -- and aborting the rest of `cleanup`
  behind it. Both filenames now carry the same `${:-}` guard the directories had,
  and a test case asserts the crash is absent on that early-abort path: the
  pre-existing downgrade case could not catch it, because `fail` prints its
  message BEFORE the trap runs, so grepping for that message passed either way.
  (#127)

## [0.15.0] - 2026-09-10

A release about the ways into oam and the boundaries around it: two security fixes
reachable from an ordinary run -- the permission matcher and the MCP HTTP transport --
three correctness fixes in `fetch`, `fs` and the heap cap, the first npm packaging,
and a set of release gates that stop a stale or broken artifact reaching a public
channel.

### Added

- **An `oamjs` npm launcher, so `npx` will be able to run oam.** The only install paths
  were the two piped installers -- `curl https://oamjs.org/install.sh | sh` on Linux and
  macOS, `irm https://oamjs.org/install.ps1 | iex` on Windows -- plus two package-manager
  taps nobody was updating (see below), and a piped installer asks someone to pipe a
  script from an unfamiliar domain into their shell before they have run a single line of
  oam. The launcher's five per-platform binary packages are `optionalDependencies`, so npm
  downloads one platform binary rather than five, and there is **no postinstall
  script** -- a postinstall that fetches a binary contradicts what `oam trust` and
  OAM-PKG0007 exist to argue, and breaks behind proxies, in offline CI and in any
  sandbox with no network at install time. The launcher spawns with `stdio: 'inherit'`
  and forwards signals rather than using `spawnSync`, because an MCP host stops a server
  by killing the PID it spawned -- which is the launcher, not oam -- and the default
  SIGTERM disposition would have left oam alive holding the host's pipes. Linux arm64
  has no binary -- the V8 startup snapshot must be generated by a process of the target
  architecture, so it cannot be cross-compiled -- and the launcher refuses it by name,
  pointing at an x86_64 host or a source build, instead of leaving npm's
  skipped-optional-dependency error to blame the user's install. All six manifests are
  generated from the workspace version by `npm/sync-packages.mjs`, whose `--check` exits
  non-zero on drift. Nothing is published to the registry yet -- this release ships the
  packages and the sync gate, not the npm entry point. (#117)
- **oam's own modules now type-check.** `import { McpServer } from "oam:mcp"` runs --
  the loader maps the specifier to a snapshot module -- but tsgo resolved it like any
  other bare specifier and answered TS2307, so the runtime whose pitch is typed
  TypeScript rejected its own flagship module from its own checker. Same for `oam:test`,
  `oam:ai` and `oam:permissions`, and TS2304 for the `oam` global.
  `crates/oam_ts/types/oam.d.ts` declares all four modules and the global, every name
  read off the JS that publishes it, and `oam check` injects it: as one more root file
  for a bare-file check, and through a generated wrapper config that `extends` the
  user's for a project check, since tsgo refuses a file argument next to `-p`. Every
  failure path checks without the declarations rather than refusing to run. `xtask
  conformance` now diffs the declared names against the module objects the runtime
  publishes and fails both ways -- an export with no declaration, and a declaration
  nothing exports -- so hand-written declarations cannot rot inside a release. (#119)
- **A raw control byte in a tracked file is now a gate failure.** A NUL inside a string
  literal is semantically valid, so fmt, clippy, the build and the tests all pass with
  it present, and `git diff` reports the file as "Binary file ... matches" with no
  hunks, which makes it unreviewable rather than merely easy to miss; five literal NULs
  reached main in a sibling repo exactly that way. `scripts/check-control-bytes.sh` runs
  as step 1 of 14 in `ci-local.sh`, first because it is the cheapest step (~1s over the
  whole tracked tree) and because a finding invalidates everything after it. The scanner
  itself had to be fixed before it could be wired in: it was one `git grep -I`, and `-I`
  skips files git considers binary -- which is exactly what a file containing a NUL is
  -- so it reported clean on a planted NUL. It is now a node pass over `git ls-files`
  (or the index under `--staged`, since a pre-commit gate must read what is about to be
  committed) with an explicit binary-extension denylist; it names file, line, byte and
  offset without echoing the matched line, and a missing node exits 2 ("could not run")
  rather than reporting clean. Later rounds closed four more false-clean paths: unmerged
  paths in a merge resolution, tracked files absent from disk, `.snap` files wrongly
  denylisted as binary, and an escape hatch that was a bare substring, so any file
  merely mentioning `control-byte-ok` became permanently unscannable -- it is now a
  declaration on its own line.

### Fixed

- **A granted permission also granted things it did not name.** One
  `target.starts_with(item)` served every category, so `--allow-net=api.github.com` also
  granted `api.github.com.attacker.net`, a name someone else can register;
  `--allow-net=127.0.0.1:5432` also granted port 54321; `--allow-env=API` also granted
  `API_SECRET`; and `--allow-fs-read=/box/allowed` also granted the sibling directory
  `/box/allowed-evil` and `/box/allowed/../../secret.txt`. Each category now has its own
  rule: fs is a path prefix anchored at a separator over a lexically resolved target
  (lexical rather than canonicalised, because the write gate runs on files that do not
  exist yet); net is exact on host:port, where an entry with no port grants any port on
  that host and a bracketed IPv6 literal is split on its bracket rather than at the last
  colon; env is exact. `worker`, `child` and `ffi` route to the path matcher, each
  gating a path-shaped resource. **This is a behaviour change**: a grant that used to
  reach a neighbouring host, port, variable or directory no longer does. Also fixed:
  `query_state` had six arms for seven fields, so `permissions.query({name:'worker'})`
  reported denied on a default all-granted run. Symlink escape is explicitly *not*
  closed -- resolution is lexical, so a symlink inside an allowed subtree still leads
  out of it, and the module docs now say so.
- **A web page you merely visited could invoke your MCP server's tools.** The HTTP
  transport had no `Origin` check, and `detectTransport()` selects HTTP whenever stdin
  is a TTY, so a plain interactive `oam run server.js` listens on 127.0.0.1 -- which is
  not a boundary against a browser, since a CORS-simple POST needs no preflight and
  lands even though the page cannot read the reply. Blind is not harmless when the tools
  have side effects. Requests whose `Origin` falls outside `serve()`'s new
  `allowedOrigins` are refused with 403 before any routing; the list is empty by
  default, and a request with no `Origin` header -- every non-browser client -- is
  allowed. The same gate closes DNS rebinding. Two further holes in the same handler:
  the well-formed body `null` parses to `null`, and `#handleSingle` read `.id` off it
  before validating anything, with the throw escaping an un-awaited `createServer`
  callback, so it was not a failed request but OAM-RT0004 and a dead runtime -- and on
  the SSE path the 202 had already been written, so the client saw success against a
  server that no longer existed; it now answers -32600. And SSE session ids were an
  incrementing integer parsed with `parseInt`, so they were guessable and
  `?sessionId=1abc` resolved to session 1; they are now `crypto.randomUUID()` strings
  compared verbatim.
- **`fetch` handed JavaScript compressed bytes instead of the body.** It advertised no
  `accept-encoding` and decoded nothing, so a server that compressed anyway returned raw
  DEFLATE with `content-encoding: gzip` still on the response -- not an error, just a
  body that is not the body, on the path an MCP sidecar or an HTTP service takes to
  reach an upstream. oam now advertises exactly what Node v22.22.2 advertises, measured
  rather than assumed: gzip and deflate, not brotli, since asking for `br` would trade
  one divergence for another. Both clients get it, including the pinned client used for
  connect-hook fetches. The decoded response no longer carries `content-encoding` or
  `content-length`, where Node keeps both: reqwest strips them as it decodes and the
  pre-strip values are not recoverable above it. Recorded as divergence 32. (#114)
- **`fs` treated a `file:` URL as a filename.** Every entry point coerced its path
  argument with `String(path)`, which yields the href, so
  `writeFileSync(new URL('./data.txt', import.meta.url), 'hello')` asked the OS to open
  a file literally named `file:///C:/...` and failed with ENOENT -- and
  `new URL('./x', import.meta.url)` is the mandated ESM replacement for `__dirname`, so
  this is how modern packages address files next to themselves. One `toPath` helper now
  owns the coercion for string, Buffer and `file:` URL across all 88 call sites,
  covering sync, promises and callback forms and both path positions of `rename` and
  `copyFile`; a non-`file:` URL is refused with `ERR_INVALID_URL_SCHEME` rather than
  stringified. Two follow-on shapes came with it. The promises forms now *reject* on a
  bad path instead of throwing synchronously, matching node -- a synchronous throw
  escapes an already-attached `.catch()` and escapes `Promise.all`, so one bad path took
  down a whole batch a supervisor expected to settle -- while the sync and callback
  forms keep throwing, as node does. And `fs/promises.glob` stays async-iterable: it is
  the one member that returns no promise, and wrapping it broke `for await` loudly but
  broke `await Array.fromAsync(fsp.glob(p))` silently, which read `length === undefined`
  and resolved to `[]`, so a build or deploy step that globs for files found zero and
  carried on. (#114)
- **`brew install oam` served 0.8.1 while the project shipped 0.14.0.** Nothing owned
  the package-manager taps: the Homebrew formula was hand-written once at v0.8.0 and
  never touched again, and the Scoop manifest was pinned to the same version -- eleven
  releases and five weeks stale, and `oam self-update` cannot rescue a brew-managed
  prefix, because it is not the installer's per-user directory. `scripts/bump-taps.sh`
  now rewrites and pushes both on every release, and can repair a drifted tap without
  cutting one. The hashes come from the release's own published SHA256SUMS -- the same
  authority `install.sh` and `install.ps1` verify against -- re-read at that step rather
  than carried from earlier in the run, and the formula rewrite is asset-keyed rather
  than positional, since pairing by position is how a formula ends up serving the mac
  hash for the linux binary. It fails closed on a missing or malformed hash, on a tag
  older than the newest release (unless `OAM_ALLOW_DOWNGRADE=1`), on a missing upstream
  branch, and on anything that would move another session's uncommitted work in these
  shared checkouts; an EXIT trap reverts every un-published rewrite on any abort, so a
  failed run cannot leave the next one blaming the operator for this script's leftovers.
  Verification reads what origin serves and checks the hashes rather than just the
  version string, with a per-run cache key, because a manifest naming the right version
  with a wrong hash fails on every user's machine and raw.githubusercontent caches for
  about five minutes. (#115)
- **`oam run --inspect app.ts` did not run.** clap's `num_args = 0..=1` without
  `require_equals` let the flag take the next argument as its value, so the FILE was
  consumed and the run died with "the following required arguments were not provided:
  <FILE>" -- which is the first line of the inspector documentation. Bare, `=host:port`
  and node's own shape all work now. (#118)
- **Two printed URLs did not resolve, and both had been broken for months.** Every
  `--inspect` / `--inspect-brk` run printed "For help, see:
  https://oamjs.org/docs/inspector", a page that did not exist, so the line a user reads
  when the debugger is misbehaving sent them to a 404; that page has since been written
  and published from the oamjs.org checkout, out of this repo, and the printed line
  itself is unchanged. And every ODIF diagnostic carried
  `"docs":"https://oam.sh/e/<code>"`; oam.sh stopped being the project's domain and now
  redirects elsewhere, so under `--json` oam handed every reader of every diagnostic to
  somebody else's site. Diagnostics now carry a `docs_url` pointing at
  https://oamjs.org/docs/errors anchored at the code, with pass-through TypeScript
  diagnostics (`OAM-TS<n>`, carrying tsgo's own number, an unbounded family) landing on
  the family section rather than on an anchor no page can honour. A gate --
  `docs/published-urls.txt` plus `xtask/tests/published_urls.rs` -- now requires every
  project-host URL printed by `crates/*/src`, `js/` outside the vendored node-streams,
  and `xtask/src` to appear in a checked-in list with a note saying what prints it, in
  both directions so the list cannot rot; retired domains are refused outright and
  cannot be allowlisted. It does not fetch anything, so it passes offline. (#118)
- **`oam trust --help` said script execution "is not yet supported".** It is:
  `run_lifecycle_scripts` executes a trusted package's preinstall, install and
  postinstall through the platform shell. The help therefore described an
  arbitrary-code-execution grant as though it merely suppressed the OAM-PKG0007 warning.
  Both doc comments now say what trusting actually does, and name `OAM_IGNORE_SCRIPTS`
  as the global off. (#118)
- **`oam explain` invented TypeScript codes.** The `OAM-TS` fallback matched zero-padded
  codes too, so `OAM-TS0005` -- oam's own concurrent-check warning -- was answered as
  "TypeScript diagnostic TS0005 ... search the TypeScript docs", a code that does not
  exist. Zero-padded codes now fall through to the family text, which at least admits it
  does not know. (#118)
- **`runToolLoop`'s own documented example was a silent no-op.** The doc comment showed
  `chat: anthropic(key).chat`, but the presets are async generators and awaiting a
  generator returns the generator, so `.content` and `.choices` were both undefined, no
  tool call was ever detected, and the caller got `{ text: '', iterations: 1 }` --
  and because generators are lazy, no HTTP request was made at all. The example is a
  real non-streaming chat now, and an async-iterable response throws a TypeError naming
  the fix rather than failing quietly. `runToolLoop` was also the one `oam:ai` export
  with no behavioural test and now has one. Separately, README.md and docs/why-oam.md
  claimed 429/431 conformance on windows-aarch64 with two deliberate failures, two lines
  below README's own statement that the receipts are never hand-edited; the generated
  scorecard says 439/442 with three. The figures are corrected to the receipt, the macOS
  and Linux numbers are dropped rather than updated (no scorecard for those hosts is
  committed here, so they were presented as though they had one), and a test now
  compares the documented figures against the JSON.
- **`OAM_NPM_ALLOW_UNEXECUTABLE=1` did nothing.** `npm/stage.mjs`'s Windows refusal told
  the operator to set it to override, and the condition never read the variable, so the
  only way to pack a POSIX package locally was to edit the script. Found because a new
  test tried to use it. (#122)
- **A conformance case flipped its verdict about a quarter of the time.**
  `97-stdin-ref-and-destroy` measured elapsed time from the `spawn()` call, so process
  creation and runtime boot -- 550-710ms for a debug-build child on the measuring box --
  sat inside every measurement and pushed children that HAD released stdin past the
  1200ms line. The child now prints a ready marker as its first statement and the clock
  starts there, so only the question the case exists to ask is inside the measurement.
  Six consecutive runs now produce identical output on both runtimes. (#120)

### Changed

- **The heap cap is derived from the container memory limit.** With `OAM_MAX_HEAP_MB`
  unset the cap was a hardcoded 4 GiB and nothing read a cgroup, so a 512Mi pod ran a
  runtime that believed it had 4 GiB: it never reached V8's near-heap-limit callback and
  the deterministic banner oam already owns, it was killed by the kernel -- exit 137, no
  banner, no crash file, no ODIF, and nothing in the logs tying the death to memory. oam
  now reads cgroup v2's `memory.max` and v1's `memory/memory.limit_in_bytes` and derives
  the cap as 75% of the limit, because the heap is not the process: thread stacks,
  ArrayBuffer backing stores and V8's own off-heap bookkeeping sit outside it, and
  handing over the whole limit just moves the kernel kill to a different threshold. A
  derived cap below 128 MB or at or above the 4 GiB default is declined and the built-in
  default stands. **This is a behaviour change** for a containerised deployment that was
  relying on the flat 4 GiB; `OAM_MAX_HEAP_MB` still wins, and the OOM banner names the
  new provenance and the override. Node does not do this -- its
  `--max-old-space-size` default ignores cgroups -- so this is a deliberate divergence
  rather than parity work. The platform split lives in the limit reader, not around the
  policy, so the fraction and floor rules stay compiled and unit-tested on Windows and
  macOS too. (#114)
- **The MCP sidecar release gate now invokes a real tool call.** `tools/list` is answered
  by a sidecar's registration table, which stays intact while everything behind it is
  broken -- so the gate standing between an oam release and every Yaw MCP user (Yaw MCP
  defaults node/npx sidecars to oam on any machine that has it) passed a sidecar whose
  every tool threw on invocation. Each sidecar that has a tool needing no credential, no
  network and no external service now gets it called and the result asserted: memory
  `read_graph`, fetch `http_get` against a loopback server the harness starts, ctxlint
  `ctxlint_token_report` over a fixture it writes. The other six advertise nothing that
  qualifies and are reported boot-only by name, each with its own reason, counted in a
  separate column rather than collapsed into coverage the gate does not have. Every
  invocation also runs on node and the two are adjudicated: a failure reproduced on node
  is upstream and never reddens a release, a failure only on oam holds it, and "the
  control could not run" now yields a fail instead of being read as "the control agrees"
  -- which had been excusing a real oam regression whenever the control host could not
  boot the sidecar. Boot failures consult the control too, and an error reply to
  `initialize` is diagnosed immediately instead of waiting out the 90s boot timeout and
  then reporting the wrong phase. (#116)
- **A release whose CHANGELOG `[Unreleased]` section is empty is refused before the tag
  exists.** RELIABILITY.md's semver policy already promised that every release ships a
  public behaviour-change log; nothing enforced it, and the omission is invisible
  afterwards, because the tag makes the CHANGELOG look complete for every version that
  does have entries. The check also rejects a Keep-a-Changelog skeleton -- bare `###
  Added` / `### Fixed` subheadings with nothing under them, the likeliest shape of
  "forgot to write the changelog" -- and matches the heading whatever its depth or
  bracketing, rather than reporting "the section is empty" for a heading it simply did
  not recognise. It sits beside the dirty-tree guard, having first been placed some 200
  lines later, where failing it left the bump commit pushed and the tag on origin: the
  half-released state a preflight exists to prevent.
- **Attribution drift is caught before the tag, and reconciled in preflight.** v0.15.0's
  own release run died at `ci-local.sh` step 10 with the tag already on origin, because
  `THIRD_PARTY_LICENSES.md` no longer matched the dependency graph -- the change that
  added the dependency had gated with `--fast`, which skipped that step outright.
  `--fast` now skips attribution only when the inputs that feed the generated file
  (Cargo.lock, every workspace manifest, about.toml/about.hbs, and the file itself) are
  provably unchanged against merge-base with origin/main, and no base means run;
  `release-local.sh` regenerates the file after the bump and before the tag, landing it
  through the bump's own guards, with `cargo-about` required rather than optional and
  `OAM_NO_AUTO_ATTRIBUTION=1` hard-failing with the crate delta. The file itself now
  carries the three crates the fetch content-encoding fix pulled into the shipped graph
  -- async-compression 0.4.43, compression-codecs 0.4.38 and compression-core 0.4.32,
  all Apache-2.0, adding no new license family -- moving the count from 254 to 257.
  (#124, #123)
- **The release scripts have tests.** `scripts/bump-taps.sh` was 439 lines running during
  a release and pushing commits to two public repos, and it had no coverage of any kind --
  it was not even in the script suite's parse list, so a syntax error in it would have
  reached a release. Fifteen cases now cover it, one per defect found in review, against
  real repos and real pushes, with every assertion reading what origin serves rather
  than the working tree. Three more units followed: the sidecar matrix's boot
  adjudication, which sat inline in the run loop where nothing could call it, is
  extracted as `classifyBoot` beside `classifyCall`; the container memory-limit parser
  is split into `parse_cgroup_limit`, which compiles everywhere rather than only on the
  platform oam is deployed to, so its malformed shapes and v1's unlimited sentinel (as a
  number it would cap the heap at petabytes and claim a container said so) are tested on
  every host the suite runs on; and npm staging gains ten cases, including the guard
  that stops non-executable POSIX packages reaching a registry that forbids
  re-publishing. (#121, #122)

## [0.14.0] - 2026-09-06

A **tty** release: one fix for raw mode, covering the exits that left a terminal
raw, the Unix restore that put back the wrong cooked state, and a failed mode
switch nobody heard about.

### Fixed

- **A program that enabled raw mode could exit and leave your terminal raw.**
  The restore was only a JS `process.on('exit')` listener, and four in-process
  exits never emit `'exit'` (three on Windows, whose console ctrl handler has no
  equivalent re-raise): the stdout/stderr EPIPE bail, the near-heap-limit OOM
  banner, `main`'s fatal sub-code return, and the Unix SIG_DFL re-raise for a
  signal whose JS listener was removed. The runtime now arms its own cooked-mode
  restore -- once, on the first enable that actually flips the terminal, on both
  Unix and Windows -- and the two paths that drained no exit hooks at all, the
  fatal sub-code returns and the signal re-raise, drain them through a new
  `run_exit_hooks` that deliberately leaves the artifact sweep alone. A hard
  kill (SIGKILL) still cannot be covered.
- **On Unix, turning raw mode off restored the terminal's first-ever cooked
  state rather than the one that enable found.** `setRawMode` saved the pre-raw
  `termios` once for the life of the process, so a later disable undid whatever
  had touched the tty since -- a child's `stty`, an inherited-stdio editor,
  another library's `tcsetattr` -- and a redundant disable re-applied that stale
  snapshot. The saved slot is now the mode itself, `Some` while raw and `None`
  while cooked, so every cooked-to-raw transition re-snapshots and an unchanged
  mode does no ioctl at all, which is what libuv does. The same path also
  swallowed a poisoned lock: the save was skipped while raw mode was applied
  anyway, after which every restore took the "nothing saved" arm and reported
  success with the terminal still raw. The lock is now recovered rather than
  dropped, and the snapshot is stored only once the switch has landed.
- **A failed `setRawMode` was silently ignored.** The native op returned a bare
  boolean and the JS side dropped a failure on the floor, so the program went on
  believing it had a raw terminal. The op now returns `uv_tty_set_mode`'s
  contract -- 0, or the negative libuv errno -- and `setRawMode` emits an error
  on the stream carrying `code: 'ERR_SYSTEM_ERROR'`, `errno`, `syscall:
  'uv_tty_set_mode'` and an `info` object, leaving `isRaw` alone as node does.
  **This is a behaviour change**: a failing switch used to report nothing at
  all, and an unhandled `'error'` on the stream now surfaces. The fields are
  filled from the same libuv table `getSystemErrorName` reads -- a deliberate
  divergence from node, which hands `ERR_SYSTEM_ERROR` the bare integer and so
  prints a message of `undefined`s; the `code` that programs branch on matches.

## [0.13.2] - 2026-09-06

An **interactive terminal** release: `readline` and `process.stdin` now behave as
node's do across the sequence every prompting CLI runs -- prompt, close the
interface, prompt again, then switch to raw mode for a TUI. Alongside it,
emptying the node test-suite exclusion backlog turned up nine real bugs in
`util`, `process`, `Buffer` and `node:inspector` that the exclusions had
been hiding.

### Added

- **`TextDecoder` decodes windows-1252, and labels follow the Encoding
  Standard.** Every label but `utf-8`, `utf8` and `unicode-1-1-utf-8` used to
  throw. Labels are now ASCII-whitespace-trimmed and lowercased before lookup,
  and the standard's full alias set for the two encodings oam implements is
  accepted (`ascii`, `us-ascii`, `latin1`, `cp1252`, `x-cp1252` among them). An
  encoding oam does not implement still throws a `RangeError`, now carrying
  node's `ERR_ENCODING_NOT_SUPPORTED` code so feature-detecting callers can
  branch on it. (#113)
- **`url.domainToUnicode()`, and `url.domainToASCII()` through node's host
  parser.** `domainToUnicode` did not exist at all, and `domainToASCII` went
  through `new URL('http://' + domain)`, which parsed `a:80` as a port instead
  of rejecting it. Both now run the domain through the same host parser node
  uses, so `a/b` gives `a`, `a:80` gives the empty string, and `%41` gives `a`.
  (#113)
- **`process.config.variables.v8_enable_i18n_support` is published.** oam links
  full ICU and said nothing about it, so the standard `hasIntl`-style feature
  test read false and Intl-dependent code took a fallback path it did not need.
  (#113)
- **`--abort-on-uncaught-exception` no longer stops the launch.** The flag was
  unrecognized, so a node-shaped launcher that passes it died at argument
  parsing. oam now accepts it and prints one line of stderr saying it is not
  implemented: oam reports the uncaught exception and exits rather than aborting
  at the throw site, so no core dump or debugger break is produced. (#113)

### Fixed

- **A second `readline` interface over `process.stdin` never received its
  answer.** Created after the first was `close()`d -- a trust prompt followed by
  a picker, say -- the second interface starved: the answer echoed on the
  terminal and nothing ran. `close()` paused the input as node's does, but the
  constructor never resumed it, and a paused `Readable` does not restart for a
  new `'data'` listener. The constructor now ends with `input.resume()` as
  node's does, and a closed interface detaches its own `'data'` / `'end'`
  listeners instead of remaining a consumer of the stream. `readline/promises`
  inherits both halves. (#107)
- **On Windows, a program that turned raw mode on right after a prompt saw
  nothing the user typed until they pressed Enter.** `process.stdin`'s `_read`
  issues a blocking read and node's `Readable` refills the moment a chunk is
  pushed, so right after a readline answer the next read is already blocked in
  `ReadConsoleW` under `ENABLE_LINE_INPUT`. A later `setRawMode(true)` flips the
  console mode, but a read already in flight keeps the cooked semantics it was
  issued with and returns only on Enter. oam now cancels the pending read across
  the flip the way libuv's `uv__cancel_read_console` does -- mark the read for
  discard, inject a synthetic Enter with `WriteConsoleInputW`, wait for it to
  settle, restore the cursor -- and re-issues it under the new mode, so no empty
  chunk or stale line reaches JS. The cursor is only put back when the cancelled
  read was a cooked, echoing one, since a raw read's injected Enter echoes
  nothing. As in libuv, type-ahead sitting in the cooked line buffer is lost
  with the cancelled read. (#107)
- **Raw-mode TUIs stair-stepped on macOS and Linux.** `setRawMode(true)` used
  `cfmakeraw`, which clears `OPOST`; with output processing off a bare `"\n"`
  only moves the cursor down, so a program writing one `"\r"` per frame and
  `"\n"` between rows drew a staircase where node drew it straight. libuv
  reserves `cfmakeraw` for `UV_TTY_MODE_IO`; its raw mode inherits `OPOST` and
  forces `ONLCR`, and oam now applies exactly that flag recipe, through
  `TCSADRAIN` in both directions. Windows is unaffected -- only the stdin console
  mode is touched there. (#107)
- **`readline` diverged from node on line terminators, `crlfDelay`, question
  ownership, closed interfaces and abort.** Lines split on `/\r?\n/`, so a lone
  `"\r"` terminator (what a progress bar writes) never surfaced until the next
  `"\n"` arrived, and `crlfDelay` was stored but never consulted; node's
  terminator rule and the option are now both honoured, clamped up to 100 with
  `Infinity` allowed. A line answering a pending `question()` fanned out to
  every `'line'` listener and to a second concurrent question -- the pending
  callback now owns it and no `'line'` event fires. `question()` on a closed
  interface wrote the prompt and hung; it now throws `ERR_USE_AFTER_CLOSE`
  before writing anything, and `rl.closed` is node's own property (undefined
  until `close()` sets it). And the promises variant rejected a `DOMException`,
  so `if (err.code !== 'ABORT_ERR') throw err` crashed; it now rejects node's
  `AbortError` -- an `Error` subclass with `code` `ABORT_ERR` and
  `cause === signal.reason`. (#107)
- **`process.stdin.unref()` did not exist.** Calling it -- the documented way to
  stop stdin holding a process open -- threw a `TypeError` and killed the
  program, exiting 1 where node exits 0. Both `ref()` and `unref()` are now
  present and return the stream, as node's `net.Socket` and `tty.ReadStream` do.
  (#112)
- **`for await (const chunk of process.stdin) break` hung until the pipe
  closed.** Breaking out of an async iterator destroys the stream, and in node
  destroying stdin closes the handle so nothing waits on it. oam's blocking read
  cannot be cancelled, so destroying stdin now retires it instead: the read stops
  counting toward the event loop and the process is free to exit, while the read
  itself completes harmlessly if data ever arrives. (#112)
- **`util.inspect` fired a proxy's traps.** A plain `console.log` of a two-key
  proxy hit its handler 88 times, so formatting a value was observable to that
  value; a revoked proxy threw out of `inspect` instead of printing
  `<Revoked Proxy>`. The walker now reads V8's proxy target and handler slots
  without touching the proxy, which is how node avoids the same problem. (#113)
- **`util.inspect.defaultOptions` was ignored by direct `inspect()` calls.**
  Every option, while the `format` paths honoured it. In the same area,
  `util.inspect(v, null)` crashed and the legacy positional argument form was
  ignored, and `numericSeparator` was stored and reported back but never
  applied. `defaultOptions` is now node's one live options object, read fresh on
  each call, and assigning a non-object to it is `ERR_INVALID_ARG_TYPE`.
  (#113)
- **`util.styleText` emitted ANSI escapes into a pipe.** It colourized
  unconditionally once the stream shape checked out, and `tty.WriteStream`'s
  `hasColors()` was hardcoded to `true` -- so `oam script.js | cat` produced a
  plain assert diff next to a fully escaped `styleText` string, and
  `hasColors(2 ** 24)` answered true on a four-bit terminal. All three surfaces
  now answer from one colour-capability function that honours `FORCE_COLOR`,
  `NO_COLOR`, `NODE_DISABLE_COLORS`, `TERM=dumb` and `isTTY`. chalk,
  supports-color, ora and cli-table3 all read this path. (#113)
- **`process.hrtime(1)` returned `[NaN, NaN]`.** It validated nothing. A
  previous-tuple argument that is not an array is now `ERR_INVALID_ARG_TYPE` and
  an array whose length is not exactly 2 is `ERR_OUT_OF_RANGE`, both checked
  before the clock is read, as node does. (#113)
- **`buf.fill(value, start, end)` threw whenever `end` was before `start`.**
  node treats an empty range as a no-op and returns the buffer untouched. It is
  a no-op here now too, with the value and encoding validation still running
  afterwards -- `fill('a', 4, 1, 'bogus')` is `ERR_UNKNOWN_ENCODING`, not a
  silent success. (#113)
- **The legacy `url` parser mangled hostnames and `url.format()` under-escaped
  what it produced.** The parser matched hostnames against an ASCII allowlist and
  truncated at the first character outside it, so `x://0.0,1.1/` silently became
  host `0.0` with the remainder pushed into the path, and it ran no IDNA at all,
  disagreeing with `new URL()` on an internationalized domain. `url.format()`
  escaped the auth field with `encodeURIComponent` (which throws on a lone
  surrogate) and its path escape table held nine characters, leaving backslash,
  caret and the brace/pipe set unencoded. The parser now runs UTS #46 ToASCII on
  the hostname and throws rather than repairing a result that comes back empty
  or forbidden; `format()` percent-encodes auth itself, substituting U+FFFD for a
  lone surrogate instead of throwing, carries node's full escape table, honours
  `{unicode: true}` by running the host back through ToUnicode, and routes the
  plain-object and legacy `Url` forms through node's own serializer instead of
  assembling them by hand, while a WHATWG-`URL` is re-serialized the way node's
  `bindingUrl.format` does. (#113)

### Changed

- **On Windows, `setRawMode(false)` on a console raw mode was never enabled on
  is now a no-op.** It used to synthesize a target mode from the console's
  current one by adding line, echo and processed input and clearing VT input --
  which on a console that starts with VT input on is a *different* mode, so a
  stray disable silently flipped the console -- and, with the pending-read
  cancel this release adds, would have dropped the read in flight with it.
  libuv's `uv_tty_set_mode` returns early when the tty is already in the
  requested mode, and this now matches. **This is a behaviour change.** (#107)
- **`node:inspector` stops claiming a session it does not have.**
  `Session.post()` called back `cb(null, {})` -- reporting that a CDP command
  succeeded, and handing back `{}` as the debugger's answer, for a command that
  was never dispatched -- and `url()` returned a hardcoded
  `ws://127.0.0.1:9229/0` once `open()` had been called, for a socket nothing
  had bound. `post()` now calls back an `ERR_INSPECTOR_NOT_AVAILABLE` error on
  the same microtask tick, pointing at `oam run --inspect` / `--inspect-brk`,
  and `url()` answers `undefined`, which is what node returns whenever no
  inspector is active. The module and `Session` still construct and connect so
  capability detection works. **This is a behaviour change**: code that read
  `{}` as a real CDP result now sees a failure. (#113)
- **The node test-suite score is 439 of 442 runnable tests, 92.2% of the full
  476-test corpus, up from 429 of 476 (90.1%).** The rate over runnable tests
  falls from 99.5% to 99.3% because eleven tests moved out of the excluded set
  and into the scored denominator rather than staying hidden. The triage
  backlog is now empty: all three remaining failures are marked deliberate with
  a recorded reason and are still counted. `internal/test/binding` is registered
  behind a proxy that throws for anything oam does not genuinely back, the
  receipts now name every skipped and unrunnable test with its reason instead of
  only counting them, and the Windows pass floor moved 429 -> 439. The Linux and
  macOS floors are unchanged and re-measure at release time. (#113)

## [0.13.1] - 2026-09-02

A **TypeScript pipeline** release. One full pass over the path a `.ts` file
takes from disk to a running program -- module resolution, tsconfig handling,
transpile, the three on-disk caches, the type-check daemon and `oam compile` --
fixed 52 findings at once. The headline for anyone writing TypeScript on oam:
stack traces now point at your source rather than at generated code, a warm run
skips the transpiler entirely, graph loading overlaps its own I/O, and a
dependency's `exports` conditions are matched in the order the package declared
them instead of alphabetically.

### Added

- **Stack traces from TypeScript point at your source, not at generated code.**
  oam's codegen reflows every transpiled source (`.ts`, `.mts`, `.cts`, `.tsx`,
  `.jsx`), so every V8 position used to be a line in the transpiled output. The
  loader now emits a source map alongside the transpile and keeps it in a
  process-global registry, and every surface that formats a position consults
  it: uncaught-exception and fatal reports, the code frame (read from the source
  file on disk, since V8 holds only the generated text), `assert.ok`
  call-source extraction, and `err.stack` as read from JS. Warm runs keep the
  fidelity -- transpile-cache and precompile-cache hits register their maps too.
  This is on by default with no flag, which is Node's `--enable-source-maps`
  behaviour. **This is a behaviour change**: oam installs its own
  `Error.prepareStackTrace` at startup, so reading that property before
  assigning it yields a function where Node yields `undefined`. Assigning your
  own still wins, exactly as in Node. (#105)
- **A transpile cache, so a warm run of a TypeScript project skips oxc
  entirely.** Entries live under `<cache dir>/transpile`, content-addressed by
  the source text plus the transpile settings -- which now embed the
  `oxc_transformer` and `oxc_codegen` versions read from `Cargo.lock` at build
  time, so an oam upgrade invalidates them. Writes are temp-then-rename under a
  self-hashed header, so a corrupt entry is a miss; every filesystem failure is
  a silent miss, because transpiling again is always correct. In a scrubbed
  environment with no platform cache dir, the fallback claims a per-user subdir
  of the shared temp dir -- `oam-user-<uid>` created `0700` on Unix, an existing
  one accepted only when it is owned by the current uid -- and disables the
  cache when it cannot do that safely, rather than sharing a world-writable
  directory. `OAM_TRANSPILE_CACHE=0|off|false|no` opts out. (#105)
- **`oam cache info` and `oam cache clean`.** The first prints the bytecode
  cache's directory, entry count and total size; the second deletes it, which is
  safe at any time because the next run recompiles and repopulates. Both are
  registered in the bare-script dispatch list, which a unit test now checks
  against clap's own subcommand list in both directions, so a file named `cache`
  in the working directory never shadows them and `oam --allow-env cache info`
  is not rejected with a space-form hint. Housekeeping also runs on its own now:
  at most once a day, a run sweeps the directory on a background thread,
  removing orphaned `.tmp` files and blobs not written in 30 days. The stamp
  that gates the sweep is written before the walk and doubles as a writability
  probe, so a populated but read-only cache root -- a container image baked with
  a warm cache -- is skipped rather than re-walked in every process. (#105)
- **`compilerOptions.jsx` is honored.** `react` compiles to classic
  `jsxFactory`/`jsxFragmentFactory` calls, `react-jsx` to the automatic runtime,
  and `react-jsxdev` to `jsxDEV()` with `__source`/`__self`. `preserve` and
  `react-native` compile as automatic and are documented as doing so, because
  both exist to leave JSX for a later build tool and there is no later tool when
  the file is about to execute. `extends` now also accepts the TypeScript 5.0
  array form, merged left to right with later entries winning, and an
  absolute-path `extends` resolves. A dependency's own `tsconfig.json` under
  `node_modules` is no longer consulted for a referrer inside it -- neither for
  JSX settings nor for `paths` -- matching what Node and tsc do with a published
  package. (#105)
- **Every tsgo run is bounded and cancellable.** `OAM_TSGO_TIMEOUT_MS` (default
  300000) caps a single run; past it the whole process tree is killed -- the npm
  shim makes the real compiler a grandchild -- and the run reports `OAM-TS0006`,
  with a cancelled run reporting `OAM-TS0007`. Cancellation is pid-safe by
  construction: the new `TsgoHandle` owns the un-reaped child -- a zombie on
  Unix, an open handle on Windows, either way the pid stays reserved -- and
  reaps only after the handle has been taken out of the running state, so a
  cancel can never land on a pid the OS has handed to something else. Warn-mode
  `oam run` now kills its one-shot checker at the deadline instead of orphaning
  it, and how long it waits for that checker after the program exits is tunable
  with `OAM_CHECK_WAIT_MS` (default 10000). `OAM_DEBUG=1` prints why a check
  fell back from the daemon to a one-shot run, which the
  never-worse-than-one-shot contract otherwise swallows. tsgo discovery also
  gained a step and is now documented accurately: `OAM_TSGO`, then the nearest
  `node_modules/.bin` walking up from the target -- new; a project-local tsgo
  was previously reachable only through PATH or the env override -- then PATH.
  The docs claimed a bundled tsgo that never existed. `--version` is probed once
  per binary and gated on a major of 7 or above, so an exit-0 impostor named
  `tsgo` is `OAM-TS0002` rather than a clean check. (#105)
- **`oam daemon stop` can kill an unresponsive daemon.** It used to send
  Shutdown and delete the state file, leaving a wedged daemon running. It now
  falls back to killing the recorded pid when Shutdown goes unanswered, and
  verifies the target by exact image name -- `oam` or `oam.exe`, compared
  case-insensitively against the first `tasklist` CSV field or the file name
  from `ps -o comm=` -- so a recycled pid belonging to something like
  `roaming-helper.exe` is never force-killed. The verify-then-kill window cannot
  be closed with shell tools, so the documentation says best-effort. (#105)
- **A `ts-cold-start` benchmark case.** No case touched TypeScript or any cache
  state before -- `cold-start` runs `console.log('ok')` -- so the claim that
  caching helps TypeScript-heavy servers was unmeasured. The new case times
  wall-clock from process spawn to the first stdout line of a generated
  20-module `.ts` graph, one row per cache state, with node as the reference: as
  published, oam's warm row is 24.38 ms against node's 187.09 ms running the
  same fixture with `--experimental-transform-types` (medians over 20, release,
  windows-aarch64, node v22.22.2). Row labels are verified rather than assumed
  -- a no-cache run that leaves a bytecode blob, or a cold run that leaves none,
  fails the case instead of publishing. The new repeatable `--case <name>` flag
  re-measures one case and merges it into the committed files, so a
  re-measurement never re-stamps numbers that did not move. (#105)

### Fixed

- **A package's `exports` conditions were matched in alphabetical order, so the
  wrong build could load.** JSON objects were held in a `BTreeMap`, which sorted
  the keys: any branch containing `default` resolved to it ahead of `import`,
  `require` or `node`, so `{import, require, default}` with `default` declared
  last loaded the default build for both sides, and `{node, default}` -- the
  shape `yaml` and `tslib` use -- loaded the browser build. tsconfig `paths`
  tie-breaking between equal-length prefixes picked the alphabetically first
  pattern where tsc keeps the first declared. Declaration order is now preserved
  workspace-wide, and every producer of such a map was audited for a dependency
  on the old sorting. (#105)
- **`require()` of a CommonJS-routed `.jsx` fed raw JSX to V8.** The transpile
  gate on the `require()` path is now the loader's own source-kind predicate, so
  a `.jsx` routed CommonJS by the package `type` field, or typeless inside
  `node_modules`, transpiles instead of reaching V8 unchanged. A transpile
  failure now throws a V8 `SyntaxError` carrying the diagnostic code and the
  first diagnostic's `file:line:col`, plus a `(+N more)` count for the
  diagnostics that used to be dropped silently; it was previously a plain
  `Error`. `.ts` and `.mts` stay behind `ERR_REQUIRE_ESM` -- a documented
  divergence from Node 22's type stripping, not a change -- and that error's
  message now points at `import` or a `.cjs`/`.cts` module instead of promising
  a roadmap item. (#105)
- **`oam run` failed on file shapes `oam check` accepted.** Probing now follows
  tsc: `./x.js` tries `x.ts` then `x.tsx`, `./x.jsx` tries `x.tsx`, an
  extensionless specifier tries `ts tsx mts js jsx mjs`, and a directory index
  tries `index.ts`, `index.tsx`, `index.js` and `index.jsx` -- a directory whose
  only index was `index.jsx` used to type-check clean and then die with
  `OAM-MOD0001`. `.cts` also keeps oxc's CommonJS source type, so top-level
  `return`, `new.target` and `await` as an identifier parse the way they do in
  `.cjs`. And `require('fs')` resolves as a builtin before tsconfig `paths` are
  consulted, matching the import side, so a catch-all `"*"` pattern no longer
  shadows a builtin. (#105)
- **`oam install --precompile` wrote nothing over an already-installed tree.**
  It only reached the precompile step inside the fetch-and-extract arm, so a
  package whose `package.json` was already on disk hit the warm-path skip first:
  `oam install` followed by `oam install --precompile`, or the flag over an
  npm-installed tree, could never populate the cache. The pass now runs after
  the install loop and the lifecycle scripts, over every resolved lockfile entry
  whose directory is present, and the per-file freshness header keeps a warm
  re-run at one read, one hash and one open per source file. A file that fails
  to compile also no longer aborts its package -- the failures fold into one
  `OAM-PKG0008` warning naming the count and the first few files. (#105)
- **The precompile cache never invalidated on an oam or tsconfig change.** Its
  key was a hash of the source alone, though the comments claimed otherwise, so
  an oam or oxc upgrade, or a changed `jsxImportSource`, kept serving stale
  output. The key is now the transpile fingerprint plus the source, and each
  entry is a single self-describing artifact written temp-then-rename, replacing
  a non-atomic `.js`/`.hash` pair whose halves could disagree. Writer and reader
  now share one extension set, so `.jsx` is finally covered, and one layout
  anchor, so a nested package gets a slot the reader actually finds. (#105)
- **The type-check daemon could serve a clean result for a tree that no longer
  type-checks.** Its cache is now keyed on tsgo's own program file list
  (`--listFilesOnly`, refreshed on every fill) plus a widened walk over every
  tsc-loadable extension, the tsconfig `extends`/`references` chain, and
  `package.json` and the lockfiles on every ancestor. The measured stale-clean
  repros -- editing a `.js` file covered by `checkJs`, editing a `.ts` file
  under `src/target/` -- now agree with a one-shot check in both directions.
  (#105)
- **An orphaned type-check daemon after a version-skew retire.** `retire()`
  fired Shutdown and returned without confirming the old daemon had exited, so
  an old daemon minutes deep in a check processed that Shutdown afterwards and
  its unconditional cleanup deleted the *new* daemon's state file -- orphaning
  it, so the next check cold-spawned a third. `retire()` now polls for the exit
  (bounded at 2s) and falls back to a kill. The new daemon transport keeps the
  accept thread O(1) alongside it: Checks are queued to a check worker, so Ping
  and Shutdown are answered while a minutes-long check runs, and both the client
  and the server build the recorded tsgo lookup from the canonicalized project
  root, which is what the state file is keyed on. (#105)
- **`oam compile` could exit 0 and hand you a binary that died on its first
  run.** A non-JS entry is now refused up front with a bundle-first hint, and a
  broken JS or ESM entry fails the compile with V8's `SyntaxError` -- either way
  no output file is written, including under a foreign `--carrier`, where entry
  validation used to be skipped entirely. **This is a behaviour change**: a
  compile that previously succeeded on an invalid entry now fails. A foreign
  carrier emits a JS-only payload, because bytecode is bound to the compiling
  binary's V8. Alongside it: `process.argv[1]` now equals `__filename` inside a
  compiled binary (built from the module key, so an 8.3 or symlinked `TEMP` path
  agrees), the embedded blob is produced with eager compilation so every inner
  function's bytecode rides along, ESM blobs are written after the graph
  evaluates so they carry what evaluation compiled, and the success notice is no
  longer double-spaced. (#105)
- **The cache directory could land in the working directory.** With
  `LOCALAPPDATA`, the XDG variable and `HOME` all absent -- a scrubbed container
  environment -- the bytecode cache root and the daemon's state root both fell
  back to `"."`; they now fall back to the system temp directory, and an empty
  variable counts as unset rather than as a path. (#105)
- **Loader warnings now reach every command.** A malformed tsconfig or an
  `extends` cycle used to be silent -- swallowed by a parse `ok()?` and by the
  depth limit that gave up quietly -- and a bare-package `extends` printed raw
  `eprintln` prose. All three are now ODIF diagnostics (`OAM-MOD0009` and
  `OAM-MOD0008`, both in `oam explain`), drained in the epilogue of every
  command that constructs a runtime: `oam run`, `oam check`, `oam test`, the
  REPL, `-e`, and the embedded, install and bare-script paths. The drain is also
  registered as an exit hook, so a script calling `process.exit()` still prints
  them. (#105)
- **`dns` NAPTR records came back with their properties in the wrong order.**
  Preserving declaration order let the literal key order reach JS verbatim. The
  old alphabetical sort happened to match Node for MX (`exchange`, `priority`)
  and for SRV (`name`, `port`, `priority`, `weight`) -- those two literals were
  reordered so the flip preserves that output -- but not for NAPTR, whose Node
  order is `flags`, `service`, `regexp`, `replacement`, `order`, `preference`.
  **This is a behaviour change** for anything that reads a NAPTR object
  positionally. SRV's order was verified against a live node v22.22.2; NAPTR's
  comes from `cares_wrap.cc`'s `ParseNaptrReply`. (#105)
- **A file added under an out-of-root include directory could be served a stale
  clean check result.** The daemon fingerprint stamped the parent directories of
  listed files outside the project root with `(mtime, size)`. On Linux,
  directory timestamps come from the kernel's coarse per-jiffy clock and an ext4
  directory's size sits at 4096 regardless of what it holds, so a file created
  in the same tick as that directory's previous modification left the stamp --
  and therefore the fingerprint -- unchanged. Those directories are now stamped
  by an FNV hash over their sorted entry names plus the entry count, so a
  create, delete or rename invalidates regardless of filesystem timestamp
  granularity; per-file edits stay covered by the listed files' own
  `(mtime, size)` stamps. The same coarse clock also flaked the regression test
  on the release Linux leg. (#106)

### Changed

- **Module-graph preparation overlaps with a prefetch worker pool.** Graph
  loading ran the filesystem read, the oxc transpile, the SHA-256 and the V8
  compile strictly serially on the isolate thread. As each module's import
  requests are resolved, not-yet-loaded paths now go to a small pool
  (`min(4, cpus)`, spawned lazily per graph load) that runs the host load and
  the bytecode-cache probe ahead of the loop and parks the results for the loop
  to consume. V8 compile and instantiate stay on the isolate thread; builtins,
  JSON and CommonJS interop still load inline, because they need the isolate.
  Error surfacing is byte-identical to the serial path -- a parked error is
  returned exactly when its path is popped, one for a path never popped is
  dropped, and a worker panic re-raises on the isolate thread at the same point.
  In-flight paths are deduped, so a diamond import loads once. On the new
  `ts-cold-start` case the no-cache and cold rows fell about 22 percent when
  this landed (39.32 to 30.71 ms and 37.39 to 29.24 ms, medians over 20 on
  windows-aarch64). `OAM_GRAPH_PREFETCH=0|off|false|no` restores the serial
  path. (#105)
- **The bytecode-cache key is derived once per compile.** `key_for()` folds the
  V8 version tag, a new oam-side format stamp and -- for the CommonJS wrapper --
  its parameter list, which are shapes V8's own blob sanity check cannot see,
  and both consume sites hand that one key to load and store instead of hashing
  the source twice per miss. The key is not derived at all when the cache is
  disabled. (#105)
- **Superseded bytecode seeds are recorded on disk.** A compiled binary's
  embedded blob is still consulted before disk, since it ships inside the binary
  and is therefore the trusted copy. When V8 rejects it, the consume site now
  writes a `<key>.seedrej` tombstone next to the refreshed blob, so later
  processes prefer the disk copy for that one key instead of re-rejecting and
  re-writing on every run. The tombstone is written only on the rejection path,
  so a compiled binary whose seed is accepted still performs zero cache writes.
  (#105)
- **Loader warnings are ODIF diagnostics, and the human renderer labels
  severity.** A tsconfig problem now surfaces as ODIF JSONL on stderr under
  `--json`, like every other diagnostic, instead of prose from an `eprintln`,
  and as one warning line otherwise; warnings are deduped per path. The renderer
  prints `warning[...]` and `info[...]` instead of labelling every diagnostic
  `error[...]`. (#105)

## [0.13.0] - 2026-08-31

A **`FileHandle`** release, with the N-API audit thread closing behind it.
`fsPromises.open()` now returns all twenty of Node v22's `FileHandle` members --
thirteen of them used to be a `TypeError` -- and wiring up its stream factories
turned up two `fs.createReadStream` divergences reachable from the plain path
API. On the native-addon side: an ABA hole in `napi_ref`, a moved-pointer defect
that a new miri-checked model found on main, the N-API layer becoming a cargo
feature you can compile out, and `--allow-addons` finally enforcing the grant it
had only ever reported.

### Added

- **`fsPromises.open()` returns a complete `FileHandle`.** `appendFile`,
  `chmod`, `chown`, `truncate`, `sync`, `datasync`, `readv`, `writev`,
  `utimes`, `createReadStream`, `createWriteStream` and `readLines` were all
  absent, so calling any of them was a `TypeError`. A closed handle now also
  fails in Node's shape rather than reaching the descriptor: the promise-
  returning methods reject with `EBADF` plus the per-method `syscall`, while
  the three stream factories match Node's other shape there -- a synchronous
  `ERR_OUT_OF_RANGE` on fd -1. (#99)
- **`FileHandle.readableWebStream()`**, the twentieth and last member of Node
  v22's `FileHandle`. It does not take ownership: `autoClose` defaults to
  `false`, so a fully drained stream leaves the descriptor open -- the opposite
  of `createReadStream`. The handle is locked to the stream for life on the
  first call. A BYOB reader is not supported (oam's web-streams layer has no
  byte controller, so a default reader is returned); see
  `docs/node-divergences.md`. (#102)
- A miri-checked model of the N-API pointer disciplines runs as its own gate
  step, so the aliasing claims behind the addon layer are machine-checked
  rather than argued. It found the `load_addon` defect below. (#88)

### Fixed

- **A `FileHandle` described whatever file currently sat at its path, not its
  own descriptor.** `fh.stat()` called the path-based `stat` rather than
  `fstat`, so after the file was renamed or unlinked it reported a different
  file's metadata, or failed outright -- open-then-unlink being an ordinary
  temp-file pattern. It now stats the descriptor. (#99)
- **`fs.createReadStream`'s `start` option never seeked.** It fed the byte
  budget while every read still came from the cursor, so `{start: 6, end: 10}`
  returned the file's first five bytes instead of the requested window. The
  same code also closed the descriptor at EOF under `autoClose: false`, taking
  ownership the caller had explicitly withheld. Both are reachable from the
  plain path API, not just from a `FileHandle`. (#99)
- **A deleted `napi_ref` could silently resolve to a different live reference.**
  Handles were validated by comparing addresses, so once the allocator reused a
  freed entry's memory a stale handle passed the check and returned whichever
  reference now sat there -- 40 times in 5,000 create/delete cycles when
  measured. A handle is now an index plus a generation counter, and a stale,
  forged, or cross-environment handle is refused instead of resolved. (#91)
- **Loading a native addon used a pointer that a move had invalidated.**
  `load_addon` derived the `napi_env` pointer from a `Box` and then moved that
  box into the registry, which invalidates pointers derived from it; the
  pointer is now derived after the move, matching what `napi_create_function`
  already did. (#88)
- **A remote build could pack gigabytes of unrelated content and then fail with
  nothing printed.** The source sync tarred the working tree against a
  hand-maintained list of `--exclude` patterns duplicated across both platform
  legs, four of the five `./`-anchored, so those four matched only the
  top-level copy: agent git worktrees carrying their own `target/` were packed
  whole, one run producing an 11.6 GB tarball from a ~1.6 MB tree and dying 35
  minutes in without an error message, because the linux leg's sync step had no
  error handling. The sync now ships what `git ls-files --cached --others
  --exclude-standard` reports, from one shared definition rather than two
  copies -- 11.6 GB became 1.72 MB and 35+ minutes became 0.94s -- under a
  tarball size ceiling (`OAM_SRC_TARBALL_MAX_MB`, default 200MB) that names the
  biggest paths on a breach, with explicit failure messages on every step of
  both legs. (#104)

### Changed

- **`--allow-addons` is now enforced, not merely reported.** It maps to the
  `ffi` permission, which nothing consumed: the grant was visible to
  `process.permission.has('ffi')` and then ignored, so under `--permission`
  *without* `--allow-addons` an addon still loaded whenever
  `OAM_ENABLE_NATIVE_ADDONS` was set. **This is a behaviour change**: such a
  run is now refused with `ERR_ACCESS_DENIED` (`permission: 'Addon'`). The
  environment variable and the grant are independent and both must pass --
  an env var cannot widen a permission the caller withheld. (#96)
- **The N-API layer can be compiled out.** `oam_engine`'s `napi` feature is on
  by default, so an ordinary build is byte-for-byte unchanged; building without
  it leaves the 132-symbol Node-API surface out of the binary entirely, and
  `require()` of a `.node` file then reports the new `OAM-NATIVE0002` rather
  than advising an environment variable that build cannot honour. (#90)
- The POSIX filesystem and child-process paths use `rustix` and owned file
  descriptors in place of hand-written `libc` calls, and 16 further `unsafe`
  constructs that asserted nothing the compiler was not already proving are
  gone. Behaviour is unchanged; `oam_core`'s audited `unsafe` surface halves.
  (#92, #89)
- **The miri gate now fails closed.** Its teeth loop asserts that the three
  models of shapes that were real bugs are still rejected, but it only tested
  for a non-zero exit -- an ordinary assertion failure or an interpreter crash
  satisfied it just as well, and the output that would have shown the
  difference was discarded. It now requires an undefined-behaviour diagnosis in
  the captured output and prints that output on a miss. The first version of
  that match ran `printf | grep -q` under `pipefail`, which SIGPIPEs on a large
  report -- measured returning 141 at 200KB -- so the match is now a bash
  pattern, which spawns no subprocess. (#94, #95)
- **The N-API-off build is gated, and the gate's own decision logic is
  tested.** The `--no-default-features` configuration #90 introduced had been
  verified by hand once and appeared nowhere in the scripts or tests; it now
  has its own gate step that builds it, clippies it with `-D warnings`, and
  runs the feature-off tests. The miri verdict logic moved into
  `scripts/lib/miri-gate.sh` so `scripts/test-scripts.sh` can drive it with
  captured output even on boxes with no nightly toolchain, and it now
  distinguishes a run in which zero models executed from a clean one. Two
  node-differential conformance cases and e2e coverage for the `napi_ref`
  handle table and the addon gates land with it; the `unsafe` ceiling moves
  `oam_engine` 597 -> 602 for five test-only blocks, and the test addon 68 ->
  70 for its new `readRefInt` export. (#97)

## [0.12.1] - 2026-08-27

An **N-API** release. Everything below is on the native-addon surface, which is off by
default and reachable only with `OAM_ENABLE_NATIVE_ADDONS=1` -- an ordinary run is
untouched. Most of it lands on the reference API (`napi_create_reference` and its
family), which rejected nothing beyond a null pointer before this release.

### Fixed

- **A deleted `napi_ref` was still dereferenced, so an addon read and wrote freed memory
  and was told it had succeeded.** `napi_delete_reference` drops the entry, but
  `napi_get_reference_value`, `napi_reference_ref` and `napi_reference_unref` each cast
  the caller's handle straight back to a reference behind a null check alone -- an
  ordinary addon lifecycle mistake became a use-after-free that returned `napi_ok`. All
  three now look the handle up in the env's own reference table first and answer
  `napi_invalid_arg` (1) when it is not there: already deleted, never created by this
  runtime, or created in a different env, since two addons loaded into one process have
  separate tables. One limit remains, and is written down rather than implied: the lookup
  compares addresses, so a stale handle whose entry has been freed and replaced at the
  same address resolves to a different live reference -- an aliasing bug rather than a
  use-after-free, and closing it needs handles that carry a generation counter. (#86;
  recorded in `docs/node-divergences.md` as divergence 22 in #87)
- **`napi_create_reference` with a null out-pointer left a reference nothing could
  reach.** It pushed the entry first and discovered the null `result` afterwards, so the
  reference sat in the env unreachable by any handle until the env itself dropped. It now
  validates up front and creates nothing, which is what Node does. (#86)
- **`napi_get_last_error_info` always answered "nothing failed".** It handed back a
  permanently zeroed static -- `error_code: 0` (`napi_ok`) and a null message, whatever
  had just gone wrong. That was harmless while nothing returned an interesting failure;
  the handle validation above changed it, so an addon following Node's documented "the
  call failed, ask why" path was told nothing had failed, exactly while debugging
  something that had. `NapiEnv` now carries its own `napi_extended_error_info` slot --
  per-env, as in Node, which is what makes handing back a pointer to it sound, since it
  lives as long as the env the addon is calling through -- and the reference family
  records a status plus a message naming the call and the reason, clearing it on success.
  Only that family records: after a failure anywhere else the slot still holds whatever
  the last recording call left, so treat a message as authoritative only when it names
  the call you just made. Documented as divergence 23. (#87)
- **Two N-API entry points handed out overlapping exclusive borrows of the same V8
  scope.** `napi_define_class` and `napi_define_properties` each derived a
  `&mut PinScope` from the env and then called `napi_create_function`, which derived a
  second one from that same unchanged field; creating it invalidated the first, which
  both callers went on using. Both sit on the ordinary addon registration path, and
  `napi_define_class` repeats it once per method descriptor. `env_scope` now hands out a
  shared `&PinScope` instead: nothing in this layer writes through the scope (V8's
  interior mutation goes through a `Cell` inside the handle scope, which is sanctioned
  through a shared reference), so the two borrows coexist rather than invalidating each
  other. Not one line of control flow changed. (#84)

### Changed

- **`napi_delete_reference` now reports a handle it does not recognise instead of
  succeeding silently.** It was the one function in the reference family that validated
  nothing past a null pointer: it retained the entries that did not match and returned
  `napi_ok` for any non-null handle, so a double-delete or a foreign handle looked
  successful and hid the addon's own lifecycle bug -- while read, ref and unref on that
  very handle correctly answered `napi_invalid_arg`. It now reports whether anything was
  actually removed. **This is a behaviour change**, and a deliberate divergence rather
  than parity: Node treats an invalid `napi_ref` as undefined behaviour. Documented as
  divergence 22. (#87)

## [0.12.0] - 2026-08-23

A **Node-fidelity** release, concentrated on three surfaces that were quietly
answering with the wrong value rather than failing: the errno tables behind
`util.getSystemErrorName` and `os.constants.errno`, which stop being one
transcribed literal shared across platforms and come from the host -- the
compiler on unix, a differentially-pinned table on Windows; `process`'s identity
properties, which gain Node's own descriptors; and the DNS layer, which learns
the distinctions c-ares makes -- a name that does not exist versus a name that
carries no record of the type you asked for. Windows also gets a packaging fix
worth its own line.

### Added

- **`process.versions` now reports `ada`.** It is the one Node dependency name
  oam withheld by mistake rather than by principle: oam parses every URL with
  ada, the same C++ WHATWG parser Node reports under this key. The value is the
  version of the *vendored* C++ ada, read at build time from the pinned
  `ada-url` crate's own `deps/ada.h` -- not the Rust binding crate's version,
  which moves independently and would put a number under a Node-owned name that
  means something else. (#64)
- **`util.getSystemErrorMessage()`**, which was absent entirely, so calling it
  was a `TypeError`. It reads the same per-platform libuv table as
  `getSystemErrorName`. (#64)

### Fixed

- **`oam.exe` no longer needs the VC++ redistributable.** The Windows builds link
  the static CRT, so a fresh machine can run a downloaded binary without first
  installing Microsoft's runtime. (#66)
- **`util.getSystemErrorName()` decoded errno numbers against an invented
  table.** The pair carried a private `-1..-28` sequence that matched no
  platform, so on Windows `getSystemErrorName(-4058)` answered "Unknown system
  error -4058" for a plain `ENOENT`, and on Linux all but one of the codes past
  `ENOENT` were wrong (`EACCES` is -13 there, not -3; only `EBADF` happened to
  land on its real number). The replacement built in #64 was transcribed and
  held Linux values, so on macOS a real `ECONNREFUSED` (-61) decoded to
  `ENODATA`. The tables now come from the host: on unix from `libc` through a
  new native, so the compiler resolves each constant for the target and a name
  the target does not define is a build error rather than a wrong number at
  runtime; on Windows from the fixed MSVC CRT and Winsock set, pinned
  key-for-key against real Node by a conformance case. The libuv table is then
  derived by libuv's own rule rather than transcribed a third time, and the
  Windows table oam stamps onto `err.errno` is filled out to libuv's full
  85-entry set so the two round-trip. (#64, #72, #76)
- **`os.constants.errno` shipped Linux's numbers everywhere, and was incomplete
  on Windows.** One Linux-valued literal served every host, so on macOS
  `EAGAIN` read 11 where the host says 35 and `EADDRINUSE` read 98 where it is
  48. On Windows the table went from 79 to 134 entries: 44 values corrected, the
  58 `WSA*` names it never had added, and the three names Windows does not have
  (`EDQUOT`, `EMULTIHOP`, `ESTALE`) dropped. Two follow-ups finished it: the
  native blob is split so `os.constants.errno` publishes only the key set Node
  publishes on that platform (79 names on POSIX) while the libuv table keeps the
  wider set it needs, and the `WSA*` block is no longer emitted alphabetically
  -- Node orders it ascending by value, which is observable through
  `Object.keys`, `JSON.stringify` and `util.inspect`. (#72, #76, #79)
- **Mutating the map from `util.getSystemErrorMap()` corrupted later lookups.**
  The returned `Map` was fresh, so `set`/`delete`/`clear` on it were contained,
  but the `[code, message]` arrays inside it were the memoized table's own --
  so `map.get(k)[0] = x` rewrote what `getSystemErrorName` and
  `getSystemErrorMessage` returned for the rest of the process. Node builds
  fresh arrays per call; oam now does too. (#75)
- **`util.getSystemErrorName()` rebuilt its whole table on every call, and
  validated nothing.** 200k lookups took 12704ms against Node's 19ms; memoized,
  62ms. Neither it nor `getSystemErrorMessage` checked its argument, returning
  "Unknown system error [object Object]" where Node throws
  `ERR_INVALID_ARG_TYPE` for a non-number and `ERR_OUT_OF_RANGE` for zero, a
  positive, `NaN` or a non-integer. Both now match, including Node's digit
  grouping for large values and its rendering of `-0` as "-0". (#72, #76)
- **A DNS name that exists but carries no record of the requested type looked
  like a name that does not exist.** Every hickory "no records" outcome
  collapsed to `ENOTFOUND`; the mapping is now NXDOMAIN to `ENOTFOUND` and
  NOERROR to `ENODATA`, which is what c-ares -- and therefore Node -- reports,
  with any other response code staying `ESERVFAIL`. A follow-up made the split
  hold on hosts that have a DNS search list: c-ares treats a name carrying at
  least `ndots` dots (1 by default) as already qualified and reports that one
  answer, while hickory walked the search list on any "no records" outcome and
  let the last bogus attempt decide the error -- so a NODATA answer surfaced as
  `ENOTFOUND`. Such a name is now queried absolutely; a name with fewer than
  `ndots` dots still goes through the search list. (#80, #83)
- **Every DNS name came back with a trailing root dot and with IDNA labels
  decoded.** hickory's `Display` does both and Node's does neither, so
  `resolveNs("xn--p1acf")` returned decoded Cyrillic where Node returns
  `ns1.nic.xn--p1acf`. All nine name sites -- CNAME, `MX.exchange`, NS,
  `SRV.name`, `SOA.nsname`, `SOA.hostmaster`, PTR, `NAPTR.replacement` and
  reverse -- now route through one ASCII helper, and the root name renders as
  the empty string rather than `"."`, matching what Node reports for a null MX.
  (#80)
- **`dns.getServers()` returned an empty array.** The nameserver list is now
  captured when the resolver is built, from the same configuration the queries
  actually go to, rather than echoing back whatever a caller had handed
  `setServers`. Duplicate addresses are dropped and order is preserved. (#80)
- **`dns.resolveCaa()` reported the wrong shape.** It emitted
  `{critical, issue: <tag>, value: <value>}`: the tag was written where the
  value belongs, the key was hardcoded to `issue` regardless of the record's
  real tag, and a `value` key Node does not have was added -- so a domain
  publishing an `iodef` record alongside `issue` records reported all of them as
  `issue`. Node's shape is `{critical, <tag>: <value>}`, with the tag itself as
  the key. `critical` is also the wire flags octet rather than a boolean, so a
  record with the RFC 6844 Issuer Critical bit set reads 128. (#81)
- **DNS errors carried no `errno`, `syscall` or `hostname`.** A handler doing
  `err.syscall === "queryA"` never matched, and one logging the decoded errno
  printed "Unknown system error undefined". Failures from `dns.lookup`, the
  `dns.resolve*` family and `dns.reverse` -- callback and promise forms alike --
  are now reshaped into Node's error, message included. `errno` is stamped on
  the `dns.lookup` path only, which is Node's own split: its `resolve*` and
  `reverse` errors come from c-ares and carry no libuv number either. (#72)
- **`child_process.execFile()` called its callback twice on a missing binary**,
  the second time with the numeric libuv errno in `err.code` (-4058 on Windows,
  -2 elsewhere), so `err.code === 'ENOENT'` took the wrong branch. Node guards
  at the callback layer and oam now does too; `err.cmd` is stamped as well.
  (#72)
- **Assigning to `process.argv` or `process.execPath` threw in ESM and silently
  vanished in CJS.** Both were getter-only, which broke the CLI test harnesses
  that rely on the assignment. They keep their lazy read and gain setters.
  `process.argv0` is independent of the `argv` setter, as Node's is -- it is a
  bootstrap snapshot, so retargeting `argv` leaves it reporting the name the
  process was invoked under. (#72, #76, #79)
- The release pipeline reclaims builder disk before a build, and two IAP tunnel
  warnings that fired on every remote build are fixed. `scripts/` is now covered
  by its own gate. (#67)

### Changed

- **`process`'s identity properties are read-only.** `version`, `versions`,
  `arch`, `platform`, `release`, `config`, `pid`, `features` and each member of
  the `versions` and `release` bags were plain writable properties, so a package
  that assigned to `process.platform` corrupted it for everything loaded after
  it; Node defines them with `writable: false`, where such an assignment
  silently no-ops in CJS and throws in ESM. **This is a behaviour change** for
  code that assigned to them, and it is not `Object.freeze`: the objects stay
  extensible and mostly configurable, which is Node's shape. `process.features`
  also picks up Node's key order, which `JSON.stringify(process.features)`
  depends on. (#64, #72)
- **`os.constants` members are read-only and non-configurable**, as Node's are.
  `errno` was the first bag to get this; `signals` and `priority` were left
  writable and configurable by that change and now match too. (#72, #79)
- **`dns.setServers()` now throws instead of quietly doing nothing.** oam's
  resolver is process-global, so recording a caller's list and then querying the
  system servers anyway was the worst outcome available -- a `Resolver` pointed
  at a blackhole address returned real records, and an answer from the wrong
  nameserver is indistinguishable from a correct one. **This is a behaviour
  change**: both `dns.setServers` and `Resolver.prototype.setServers` raise an
  error with `code: 'ENOSYS'`, sending the caller to its own fallback. It is a
  deliberate divergence from Node and is documented as one. (#80)
- `--allow-worker` is documented as no longer implying `--allow-child-process` --
  it stopped implying it in 0.9.1, when child isolates began inheriting the
  parent's grants. (#65)
- The `unsafe` coverage gate is enforced through clippy, and the
  `documented_count` floor it replaced is retired. (#63)

## [0.11.0] - 2026-08-22

A **hardening** release: three memory-safety fixes reachable from ordinary JS or an
ordinary spawn, one Windows handle-scoping fix that matters to anyone launching child
processes concurrently, and the `unsafe` audit gate going from advisory to gating.

### Fixed

- **A Windows child inherited every inheritable handle in the process.** `spawn_extra`
  called `CreateProcessW` with `bInheritHandles=TRUE` and no handle list, so a
  concurrent spawn could leak our pipe ends into an unrelated child — the peer then
  never saw EOF (a hang), and the handle was exposed to a process that had no business
  holding it. The extra-fd spawn now passes an explicit `STARTUPINFOEXW` +
  `PROC_THREAD_ATTRIBUTE_HANDLE_LIST`. If you launch several sidecars at once on
  Windows, this is the fix you want. (#55)
- **`fsReadSync` and `zlibHandleWriteSync` trusted a JS-supplied offset and length.**
  Both are reachable from ordinary user JS through `__oam.node` — no native addon
  required — and an unvalidated value produced an out-of-bounds write or an
  abort-the-process allocation. Both now bounds-check with `checked_add` and clamp the
  allocation. (#52)
- **A closed inherited descriptor could be re-adopted after the kernel reused its
  number.** The adoption path keyed on the raw fd, so once the OS recycled it, a second
  `closeSync(n)` closed a descriptor the runtime had since opened for itself. A closed
  inherited fd now stays closed and reports `EBADF`. (#53)
- **N-API deferred and addon lifetimes.** `napi_resolve_deferred` /
  `napi_reject_deferred` freed the caller-owned deferred on the invalid-argument path,
  so a caller that checked the status and retried hit a use-after-free or double-free;
  and `load_addon` unmapped the library when `register()` failed while the env still
  held code pointers into it. Both are reachable only with
  `OAM_ENABLE_NATIVE_ADDONS=1` — native addons remain off by default. (#54)

### Changed

- **The `unsafe` audit gate now gates.** CI gate 5 was an advisory `grep -c unsafe`;
  it is now `cargo run -p xtask -- unsafe-budget`, a bidirectional ratchet keyed on
  `conformance/unsafe-budget.json` that fails both on new undocumented `unsafe` and on
  a stale budget that no longer matches. `forbid(unsafe_code)` is set on the three
  crates that have none, `undocumented_unsafe_blocks` is denied outside `oam_engine`,
  and `oam_engine`'s own blocks are documented — the coverage floor moved 10 → 575.
  `--regen` prints a diff of what it is about to re-bless rather than overwriting
  silently. No runtime behavior changes. (#56, #58–#62)

## [0.10.2] - 2026-08-16

### Changed

- **`fs.glob` stops honoring a caller's `nocase`, because Node does not.** Node v22
  validates only `cwd` / `exclude` / `withFileTypes` and silently ignores the rest, so
  case folding is a property of the platform, not of the options object. Verified
  against v22.22.2: on win32 `FOO.*` matches `foo.js` even with `nocase: false`, and on
  Linux `nocase: true` still returns only the exact-case match. oam now derives folding
  from the platform (win32 or darwin) and ignores the option. **If you passed
  `nocase: true` on a case-sensitive filesystem and relied on it, that stopped working
  here.** Literal (non-globstar) segments are now emitted pattern-cased rather than
  listing-cased, so `SUB/*.js` yields `SUB\inner.js` on win32.
- The remaining oam-only glob extensions are now written down as **divergence 21** in
  `docs/node-divergences.md`: oam implements `nodir`, `include`, `follow` and the
  oam-only `maxResults`, all of which Node silently ignores — so passing one produces
  glob-package behavior on oam and no behavior on Node. Passing none is identical on
  both. Whether to drop them for strict parity is left open.

## [0.10.1] - 2026-08-16

An **extra-fd `child_process`** release — the descriptor path a CDP browser transport
runs on. Everything here was found by writing the coverage that was missing rather than
by anything failing in the field.

### Fixed

- **A live `kill()` on an extra-fd child was a silent no-op on Unix.** `raw_kill` only
  signaled while the registry still held the `Child` handle, but `raw_wait` takes that
  handle at its first poll — and the wait op starts the moment the child spawns — so
  every real kill arrived after the handle was gone and the child ran on untouched
  (conformance case 68's sigterm leg timed out on macOS; **a CDP browser child could
  not be terminated at all**). Liveness now comes from a `reaped` flag flipped under the
  registry lock when the blocking wait returns: a kill is delivered any time before the
  reap (a zombie discards it harmlessly) and never after (a reaped pid can be recycled
  by the kernel). Windows was never affected — `child_win.rs` copies the handle. (#49)
- **A failed extra-fd spawn emitted `error` and nothing else**, so a caller whose
  completion path is `close` — a CDP driver probing for a browser binary that is not
  installed — stalled forever. The extra-fd path now follows `error` with `close`
  carrying the libuv errno, the same contract the plain path keeps, and both raw
  native backends now include `errno` in the failure body so that argument can be
  node's (Windows additionally routes `GetLastError` through the shared mapping, so
  `ERROR_PATH_NOT_FOUND` reports `ENOENT` instead of `UNKNOWN`). (#51)
- **`kill()` with a numeric signal was handed to the native layer as a stringified
  number** no signal table recognizes, so `kill(9)` silently delivered SIGTERM and an
  invalid number like `kill(987654)` threw nothing. Numbers are now validated against
  `os.constants.signals` and converted to their canonical name — node's rule: a number
  is valid iff it appears in the platform's signal mapping, anything else is
  `ERR_UNKNOWN_SIGNAL`. Note oam carries the POSIX signal table on every platform
  (divergence 14), so a Windows-specific number may now throw where it previously
  "worked" as SIGTERM. (#51)
- `fs.glob`'s `nodir` filter is now applied before segment matching rather than after.
  No change in output; it stops the walk doing work it was about to discard.

### Changed

- The conformance `surface-gaps.json` linux section ratchets down six glob names. (#50)

## [0.10.0] - 2026-08-15

### Fixed

- **A child that trapped your signal and exited cleanly was reported as killed by it.**
  The extra-fd `raw_wait` synthesized its exit report instead of reading the real
  `ExitStatus`, so a child that caught SIGUSR1 and exited 0 came back as
  `{code: null, signal: "SIGUSR1"}` rather than `{code: 0, signal: null}`.
- **`ChildProcess.kill()` now throws `ERR_UNKNOWN_SIGNAL`** for an unrecognized signal
  *name* instead of silently falling back to SIGTERM.
- `fs.glob`'s globstar `exclude` and empty-match semantics were rewritten against
  node's own `lib/internal/fs/glob.js`: a function-valued `exclude` is called with the
  entry's leaf name during globstar iteration, as node does.
- The Windows release build could fail with `LNK1104` when a previous `oam.exe` was
  still mapped; `deps/oam.exe` is now parked alongside `release/oam.exe` before linking.

### Changed

- The `.cts` entry was moved into **[0.6.1]**, where it actually shipped, and the stale
  `OAM-MOD0003` explanation that told users to "write ESM TypeScript instead" was
  corrected — `.cts` runs through CJS interop with TS strip, and `.tsx`/`.jsx` run
  through the JSX automatic runtime.

## [0.9.8] - 2026-08-15

### Fixed

- `child_kill` recorded a kill against a child that had already exited but not yet been
  reaped. `kill(2)` on a zombie returns 0, so the result was reported as
  `{code: null, signal: "SIGTERM"}` instead of the child's real `{code: 0, signal: null}`.

## [0.9.7] - 2026-08-15

### Fixed

- A stolen or already-consumed extra-fd read end broke out of the read loop instead of
  taking the EOF path, so `'end'` never fired and `'close'` arrived without it.

## [0.9.6] - 2026-08-15

### Fixed

- The extra-fd pump let `'close'` beat `'end'` on a fast exit. A child that wrote fd4,
  closed it and exited inside a single 50 ms peek cycle lost its `'end'` entirely
  (conformance case 67: "fd4 saw EOF false").

## [0.9.4] - 2026-08-15

### Added

- `SIGCONT` and `SIGTSTP` are mappable in `process.on(...)` on Unix, built from the
  platform's `libc` numbers. `SIGTSTP` joins the "default terminates" restore-and-re-raise
  set; `SIGCONT` deliberately does not.

## [0.9.2] - 2026-08-15

Two resource caps, because the failure they replace was an ungraceful abort with no
exit path.

### Added

- **`fs.glob`, `fs.globSync`, `fsPromises.glob` and `path.matchesGlob`.** Before this
  release these were missing export *names*, which is link-time death for anything that
  imports them (see [0.9.1]).
- **A default V8 heap cap of 4 GiB**, resolved as: unset or empty → 4 GiB;
  `OAM_MAX_HEAP_MB=0` → no cap; a non-numeric value → no cap (typo-safe); `n > 0` → n MiB.
  There was previously no cap, but V8 aborted near 1.4 GiB with "Ineffective
  mark-compacts near heap limit" and no way to exit cleanly — so this *raises* the
  ceiling and converts the abort into a deterministic
  `error[OAM-RT-OOM]` on **stderr** with exit code **134**, uniform on every platform.
  stdout is deliberately left clean so an MCP sidecar's protocol channel is not
  corrupted on the way out, and the banner distinguishes a cap set by `OAM_MAX_HEAP_MB`
  from the 4 GiB default.
- **A 1,000,000-match cap on glob results**, applied after dedup, overridable with
  `maxResults` (`Infinity` disables). Exceeding it throws `ERR_OUT_OF_RANGE`, and a
  non-number `maxResults` throws `ERR_INVALID_ARG_TYPE` — previously passing `0`
  silently meant a million.

### Fixed

- Concurrent reads on a child's stdout/stderr now take a `busy` flag under one lock. A
  second concurrent read used to see a false EOF, which stalled the pump's `'close'`.
- Native child ops throw a `TypeError` for a non-numeric or NaN handle argument instead
  of coercing it to handle `0` — which was a real child.
- `oam.fork()`'s re-exec regained its `check_child_perm` call. Both halves landed inside
  this release, so no tagged build shipped the gap.

## [0.9.1] - 2026-08-11

A builtin **export-surface** release. `import { statfsSync } from "node:fs"` used to kill
a program on oam before it ran a line — a builtin's ESM named exports are its module
object's own enumerable keys, so a name oam had not implemented failed at *link* time,
taking down bundled CLIs that never called the function. Measuring the whole surface
found 384 such names across 41 builtins; the ones below are closed and the rest are now
tracked by a gate instead of waiting to be discovered by a crash.

### Added

- `fs.statfs`, `fs.statfsSync` and `fsPromises.statfs`, backed by a real syscall
  (`GetDiskFreeSpaceW` on Windows, `statfs(2)` on Linux/macOS, `statvfs` elsewhere), with
  the `StatFs` shape, the `bigint: true` option, and Node's `ENOENT`/`statfs` error shape.
  Values cross the native boundary as decimal strings so bigint mode is exact rather than
  rounded through a double.
- `node:console` now exports its full surface. It was built with
  `Object.create(globalThis.console)`, which left every method on the prototype, so the
  module's only named export was `Console` and `import { log } from "node:console"` was a
  hard failure. The module is now the global console itself, as it is in Node, and gained
  `dirxml`, `profile`, `profileEnd`, `timeStamp`, `createTask` and `context`.
- `fs.Dir` is a real exported class shared by `opendir` and `opendirSync`; each form
  previously returned an ad-hoc object with only half the method set. Closed handles now
  throw `ERR_DIR_CLOSED`, and iterating (or `break`ing out of) a `for await` closes the
  handle, both matching Node.
- `fs.fstat` (the async callback form), `fs.unwatchFile`, `fs._toUnixTimestamp`, and the
  top-level `F_OK`/`R_OK`/`W_OK`/`X_OK` re-exports.
- **fd-based ops**: `fsync`, `fdatasync`, `ftruncate`, `fchmod`, `fchown`, `futimes`, in
  both callback and sync form. On Windows `fchown` is a success-reporting no-op, matching
  libuv, so portable code need not branch. (#43)
- **Path-based ownership and time ops**: `chown`, `lchown`, `utimes`, `lutimes`, `lchmod`
  across `node:fs` and `node:fs/promises`. Node's asymmetries are reproduced rather than
  inferred — `chown` on Windows succeeds for a nonexistent path, the error syscall is the
  singular `utime`/`lutime`, and `lchmod` is bound to `undefined` off macOS in `node:fs`
  while `fs/promises` always exposes it and rejects with `ERR_METHOD_NOT_IMPLEMENTED`. (#44)
- **`fs.readv` / `fs.writev`**, and `fs.openAsBlob`. (#47, #48)

### Security

- **`--permission` is enforced across the whole `fs` surface.** Only 9 of 47 fs ops
  checked it: under `--permission` with no grants, `fs.unlinkSync` deleted the file,
  `fs.promises.rename`/`mkdir`/`chmod` succeeded, and `fs.promises.stat`/`readdir`
  enumerated the filesystem. Every path-based op now checks, with read/write classified
  to match Node's own model (`copyFile` reads the source and writes the destination;
  `rename` writes both; `link` reads the existing name and writes the new one).
  fd-based ops (`read`/`write`/`close`/`fstat`) are intentionally unchecked — the
  descriptor can only have come from `open`, which is checked, so the capability is
  already gated. **One deliberate divergence:** oam also gates `fs.realpath`, which Node
  permits without a read grant; a sandbox should not leak path existence.
- **`child_process` and `worker_threads` no longer escape `--permission`.** Neither
  consulted the permission model: `execSync` ran anything, and a `Worker` (or an
  `oam.fork()` isolate) was constructed with all-granted permissions regardless of the
  parent's flags, so either was a one-line bypass of every fs and net restriction. Spawn
  now checks `child` (including the extra-fd spawn path), starting an isolate checks the
  new `worker` permission, and a child isolate INHERITS the parent's set. Because of that
  inheritance, `--allow-worker` no longer implies `--allow-child-process`; node keeps them
  separate too.
- **`--permission` was silently ignored by `oam repl` and `oam test`.** Both built an
  all-granted runtime, because permissions are fixed at *construction* and
  `flags.install()` cannot retrofit them — so `oam --permission test suspect.test.js`
  ran with full disk, network and spawn access. A source-scanning test now pins one
  allowed all-granted call site and four permissioned entry points. (#42)
- A source-level test now fails the build if any op that touches the filesystem, spawns a
  process, or starts an isolate ships without a permission check or an explicit,
  reasoned exemption. It caught a second spawn entry point while being written.

### Fixed

- Async `fs` rejections carry node's full system-error shape. `OpOutcome::NodeFailed`
  held only `{code, message}`, so every promise-form failure had `syscall`, `errno` and
  `path` undefined while its sync twin set all four — packages that branch on
  `err.syscall === "open"` or read `err.path` (graceful-fs, chokidar, rimraf) saw
  nothing there.
- **An fd now crosses the sync/async boundary.** oam kept two open-file registries — a
  tokio-backed one for async ops and a std-backed one for sync ops — so a descriptor from
  async `open` threw `EBADF` in `readSync`/`fstatSync`/`closeSync`, and the reverse failed
  too. Node has one descriptor space and real code mixes the families freely
  (`fsPromises.open()` then `readSync(fh.fd, ...)`). Unified onto one registry. (#46)
- **Positional `read`/`write` moved the fd cursor.** Node's are `pread(2)`/`pwrite(2)` and
  leave it alone, so `readSync(fd,b,0,3,10)` followed by `readSync(fd,b,0,3,null)` returned
  `"KLM"`/`"NOP"` where node returns `"KLM"`/`"ABC"` — silent wrong bytes, not an error.
  Fixed on the write side too, and fs errors now enumerate as `["errno","code","syscall"]`
  in node's order, which `Object.keys` makes observable. (#45)
- **A failed async read or write destroyed the descriptor.** The error arm never
  reinstated the `File`, so an fd that reported one transient error was dead thereafter —
  code that handled the error and retried on the same descriptor worked on Node and could
  not work here. The async `fs.read` also ignored its `position` argument outright,
  reading a different region silently, and capped at 8 MiB so a 10 MiB `readv` short-read. (#48)
- **Blob internals were own-enumerable**, so `JSON.stringify(blob)` dumped the entire
  payload as `{"_bytes":{"0":104,...}}` — any log line or API response carrying a Blob
  serialized the whole file. Fixed for every Blob, not just `openAsBlob`'s. (#47)
- `'close'` could beat stdout's `'end'` under load. The child's exit now waits on
  `readableFinished()`, but only when something is actually consuming the stream (flowing,
  piped, or a `'readable'` listener), so an ignore-the-output spawn still cannot hang.
- `fs.truncate`/`truncateSync` reported `syscall: "truncate"`; node reports the syscall
  that actually failed, so a missing path is `open` and a failed resize is `ftruncate`.
- `watcher.close()` on a `fs.watchFile` handle stopped *every* watcher on that path when
  the listener was shared or absent; it now removes only its own entry. `fs.watchFile`
  also rejects a missing listener with `ERR_INVALID_ARG_TYPE` instead of returning a
  poller that could never fire.
- `fs.fstat` performed its stat synchronously and merely deferred the callback, blocking
  the loop for the whole call; it now runs on a blocking thread off an owned handle.
- `fs.statfsSync("")` reported `EINVAL` where Node reports `ENOENT`.
- Argument-validation failures out of `fs` raise a real `TypeError`, not a plain `Error`
  carrying an `ERR_*` code.
- A missing builtin export now explains itself: the error names the module, says the gap
  is oam's, and points at the tracked list, instead of only repeating V8's bare
  "does not provide an export named X".

### Changed

- `cargo run -p xtask -- conformance` gains a **builtin export-parity gate**. It runs the
  surface probe under both oam and the installed Node and fails on any missing export not
  recorded in `conformance/surface-gaps.json`, on a recorded name oam has since
  implemented (so the list can only shrink), and on an unrecorded absent module. The
  ratchet is keyed by platform because Node's own surface is; a host with no section is
  measured and reported but not gated. See `docs/node-divergences.md`.
- The macOS release leg now runs conformance. It previously ran fmt/clippy and tests
  only, so the differential corpus never executed on darwin.
- The published downloads page is regenerated and verified as part of the release path.
  Installers are byte-identical across releases, so a page two releases stale used to
  ship silently.
- Status moved from pre-alpha to **beta**, and the npm claim was corrected:
  `@yawlabs/oam` is planned but **not published**. The install script is the only
  supported channel. (Bare `oam` on npm is an unrelated project.)

## [0.9.0] - 2026-08-08

A `child_process` release. The module had no differential coverage against Node
until now, so nearly everything on a failure or option-edge path was untested —
and most of what follows was found by reading it properly for the first time
rather than by anything failing.

**Minor, not patch, because several of these change behavior you may depend on:**
`stdio` is honored at all now (`'inherit'`/`'ignore'` used to behave as
`'pipe'`); `execFile` no longer runs through a shell; `spawnSync` reports
`ENOBUFS` where it used to truncate and report success; `exec`/`execFile` now
enforce `timeout`, so a child that used to run forever gets killed; `fork` and a
misplaced `'ipc'` slot now throw; and `fs.openSync` descriptors start at 64
rather than 3.

### Added

- **oam can now BE the child of an extra-fd spawn**, not only the parent of one.
  A descriptor the parent hands us is adopted into the runtime's registry the
  first time an `fs` call names it, so `readSync(3, …)` / `writeSync(4, …)`
  behave as they do on Node instead of throwing `EBADF`, and `closeSync(4)`
  closes the *parent's* descriptor so the peer sees EOF rather than hanging.
  This was the receive half of the CDP pipe transport (divergence 19).
- **A numbered descriptor in a `stdio` slot is honored.**
  `stdio: ['ignore', logFd, logFd]` — the daemonize-into-a-logfile shape — now
  resolves the fd against the registry and hands the child a dup, so the output
  reaches the file. It used to collapse to `'inherit'`, sending the child's
  output to the parent's console while `child.stdout === null` made the
  redirect look like it had worked (divergence 18).

### Fixed

- **oam's own descriptors could collide with the parent's.** The id counter
  started at 3 — exactly where a launcher's inherited fd 3 lands — so oam's
  first `openSync` could shadow a descriptor the parent had handed it. Runtime
  descriptors now start above the inheritable window, making an unknown low fd
  unambiguously "the parent gave me this".
- **An `'ipc'` slot anywhere but last silently renumbered the child's fds.**
  oam carries the channel on a loopback socket, so the entry is spliced out of
  the array; Node instead makes that very slot the channel. The unsupportable
  positions now throw `ERR_INVALID_ARG_VALUE` naming the fix rather than
  guessing, and `fork()` enforces the same rule as `spawn()` (divergence 20).

- **`spawn()` mutated the caller's options object.** It spliced the `'ipc'`
  entry out of `options.stdio` in place, so reusing one options literal to
  spawn a pool of workers gave the first child a channel and every later one
  none — `child.send` simply undefined, with no error raised anywhere.
- **`kill()` was a silent no-op while the native handle was still resolving** —
  the window an `'ipc'` child has, because its channel must bind before exec.
  It returned `true`, `killed` stayed `false`, and the child kept running. The
  signal is now held and delivered as soon as the handle lands.
- **`exec()` accepted `timeout` and ignored it**, so the standard way to bound a
  shell-out did not bound it: a child that hung hung the caller forever. The
  callback now reports `killed: true` with the signal, as node does.
- **`execSync()`'s thrown error had no `.output`** — the 3-slot
  `[null, stdout, stderr]` array harnesses read to get both streams from one
  throw — and its message appended a newline node only appends when stderr is
  non-empty.
- **`fork()` accepted an explicit `stdio` array with no `'ipc'` entry.** Node
  throws `ERR_CHILD_PROCESS_IPC_REQUIRED`; oam built the channel anyway, which
  let code be written and tested here that is fatal the moment it runs on node.
- **`spawnSync()`'s `timeout` returned `ETIMEDOUT` without killing the child.**
  The child was moved into a worker thread that owned it, so nothing was left to
  kill: `spawnSync` returned while the child ran on holding its port, its lock
  and — now that `stdio: 'inherit'` is honored — the parent's console.
- **`spawnSync()` truncated at `maxBuffer` and reported success.** A caller got
  a short result that looked complete (a half JSON document that still parses)
  while every node-shaped check had nothing to branch on. It now reports
  `ENOBUFS` with a null status, as node does.

- **The MCP sidecar matrix ran AFTER the GitHub release went live.** Its "do not
  ship" branch fired on a build `install.sh` and `oam self-update` could already
  resolve, so the gate was reporting a verdict on something it could no longer
  stop. It now runs before the release is cut.
- **`child_process` ignored the `stdio` option entirely — `'inherit'` and
  `'ignore'` both behaved as `'pipe'`.** A child's output went into pipes the
  parent never forwarded and its stdin was a pipe nobody fed. This broke any
  launcher script that hands its own stdio to a grandchild, which is the shape
  every npm `bin` shim uses: an MCP sidecar started through one booted and then
  sat mute forever, with the launcher still reporting success. `'inherit'` is
  now a real OS-level handle hand-off, so nothing is copied through the parent.
- **`fork()` swallowed a non-silent child's output.** Node inherits stdio unless
  `silent: true`; oam piped it and dropped it, so `console.log` from a forked
  child vanished. An explicit `stdio` option on `fork()` is honored too.
- **A failed `spawn()` reported no `err.code` and used a raw JSON blob as its
  message.** It now produces node's shape — `spawn <cmd> ENOENT` with
  `.code`/`.syscall`/`.path` set — which is what `execa`, `cross-spawn` and
  every `which`-style resolver branch on.
- **A `spawn()` failure with an `'ipc'` slot hung the process forever.** The
  loopback channel kept listening because `'exit'` never fires for a child that
  never started. Relatedly, an `'ipc'` slot combined with numbered fds above 2
  silently produced a child with no IPC channel at all — that combination now
  works, but only with `'ipc'` LAST; anywhere else it throws
  `ERR_INVALID_ARG_VALUE` rather than renumbering the child's fds behind your
  back (new divergence 20).
- **A failed `spawn()` emitted no `'close'`, and a failed `fork()` still
  reported the raw native error blob.** Node follows `'error'` with `'close'`
  for a child that never started, so consumers whose completion path is
  `'close'` stalled instead of taking their error branch. Spawn errors now also
  carry `errno`, matching node.
- **`execFile()` ran its arguments through a shell.** It joined argv into one
  string and handed it to `exec()`, so arguments were re-split on whitespace and
  shell metacharacters inside an argument were executed. Node's `execFile` is
  shell-free by design and passes argv verbatim; oam's now does too.
- **Writing to a failed child's stdin killed the process.** The spawn error was
  routed into the stdin stream's error channel, where nothing listens, so
  `cp.on('error', h); cp.stdin.end(payload)` died on an uncaught error despite
  the caller handling the failure correctly.
- **`exec()`'s `maxBuffer` was enforced on stdout only, and measured
  quadratically.** stderr could grow without limit, and the stdout check
  re-concatenated everything accumulated so far on every chunk — gigabytes of
  copying at the 50MB default. Overflow now reports
  `ERR_CHILD_PROCESS_STDIO_MAXBUFFER`, as node does.
- **Smaller `child_process` parity fixes.** `exec()` no longer forwards `stdio`
  to `spawn` (node's `exec`/`execFile` deliberately own their pipes);
  `spawnSync`'s `input` no longer overrides an explicit `'ignore'`/`'inherit'`
  in slot 0 (node's docs say it does, its implementation does not); non-piped
  slots read back as `null` rather than empty buffers.

## [0.8.3] - 2026-08-07

### Added

- **`--allow-net` and `--allow-env` grants**, with env access actually enforced,
  and **`--carrier` for cross-target `oam compile`** — the compile step can now
  be handed a carrier binary for a target other than the build host.

### Fixed

- **The benchmark harness timed a binary `cargo` could replace mid-run.** `oam`
  is now staged out of `target/` before timing, so a concurrent build cannot
  swap the file underneath a measurement. This invalidated earlier published
  numbers.

## [0.8.2] - 2026-08-06

Release tooling and benchmark measurement only; no runtime behavior change.

### Fixed

- The release flow parks an in-use `oam.exe` by renaming it instead of killing
  whatever process holds it, and lands the version bump on `main` unattended.
- The Windows RSS parser no longer scrambles every reading; benchmarks were
  republished against 0.8.1 with the working parser.

## [0.8.1] - 2026-08-05

### Added

- **Node's own streams.** `require('node:stream')` is now served by a vendored
  copy of Node v22's `internal/streams` sources running over a shim prelude,
  replacing oam's in-house implementation, which was deleted.
- **Host-driven `process.nextTick`** — a FIFO queue with Node-parity exception
  handling, on an explicit V8 microtask policy with engine-owned tick points.
- **Process lifecycle parity**: `beforeExit`, the exit-code matrix, and a
  canonical uncaught-exception ladder.
- **Node eval flags** (`-e` / `-p`), `util.inspect` walker parity, and WHATWG
  `url` host rules.
- **Active-resource introspection** (`process.getActiveResourcesInfo` and
  friends), process warning flags, and `import()` from CommonJS.
- **`.tsx` / `.jsx` support** via the JSX automatic runtime.
- **`async_hooks`** init-observer registry, and `Console` write-callback
  support.
- Node's `assert` message machinery and the `util.inspect` prerequisites it
  needs; `assert.ok` now quotes the failing expression, as Node does.
- Node-shaped fatal reports, plus the `--permission`, `--env-file`, and
  `--input-type` flags, and unref'd ops.
- `child_process`: `stdio: 'ipc'` in `spawn`.
- `worker_threads`: per-worker stdout/stderr capture, `execArgv`, and the `--`
  separator. Workers inherit process flags, and `NODE_OPTIONS` is honored
  behind a strict allowlist.
- `Buffer`: pooled small allocations, and `postMessage` transfer lists.
- `structuredClone` transfer, POSIX identity APIs, and dotenv parity.
- `SECURITY.md`.

### Fixed

- `http`: `req.destroy()` now resets an in-flight response stream. It
  previously hung.
- `child_process`: `child.pid` is available synchronously from `spawn` and
  `exec`, matching Node.
- `process.env`: case-folding, own-property semantics, and inheritance by child
  processes.
- Windows: Node-shape quoting for `exec`, and bare-script invocation.
- `Buffer`: oversized `toString` throws `ERR_STRING_TOO_LONG` instead of
  crashing the process.
- `string_decoder`: rejects invalid UTF-8 lead bytes and lead-illegal second
  bytes.
- A worker that touched `worker_threads` never exited.
- The engine reports the handler's own exception, and no longer stringifies
  rejections eagerly.
- The installer gives an honest error for the unshipped `linux-arm64` target
  rather than failing obscurely.

### Changed

- Node test-suite conformance moved from 384 to 391 of 402 (97.3%); the pass
  floor was raised to match.

## [0.8.0] - 2026-07-22

Release-pipeline hardening. No runtime behavior changed.

### Added

- The install path authenticates with `GH_TOKEN`, so private-repo installs
  work.
- `NOTICE` and third-party attribution ship with the source tree.

### Changed

- Release preflight creates the release tag at `HEAD`, or re-points it if it
  already exists elsewhere, replacing a manual four-command tag dance. The
  already-published check runs before any tag mutation, so a tag whose assets
  are published is never moved.
- The CI gate fails on `THIRD_PARTY_LICENSES` drift.

### Fixed

- The release script verifies the `SHA256SUMS` manifest against the built
  artifacts before uploading anything.
- The attribution gate could never pass as written.
- CI restores conformance artifacts from `HEAD` and reports honestly when it
  discards a regenerated stamp; gate-regenerated conformance stamps are
  auto-restored.
- Three more end-to-end test waits were de-raced.

## [0.7.0] - 2026-07-11

### Added

- **Application compatibility pass**: Fastify boots, `net` reports Node's
  errno values, `ws` tears down correctly, Ed25519 is supported, `pino` writes
  to stdout as expected, and file descriptors are reserved the way Node
  reserves them.
- **Inbound OS signal delivery** — `process.on('SIGTERM' | 'SIGINT' |
  'SIGHUP')`.
- Operational hardening and the TTY raw-mode stack.
- Per-host node-suite pass floors in `xtask`, and a warn-mode `OAM-TS0000`
  diagnostic in the JSON output.

### Changed

- **CI and releases no longer use GitHub Actions.** All workflows were removed
  and replaced by a script suite: `scripts/ci-local.sh` is the gate,
  `scripts/release-local.sh` cuts releases, and cross-platform legs run on
  remote build hosts.

### Fixed

- Loader: module identity is canonicalized so an entry point and a cyclic
  re-import of it resolve to one key rather than loading twice.
- DNS: the resolver forces EDNS0 and falls back to TCP, matching Node.
- `fs`: write streams flush after each chunk, fixing a finish-before-flush
  race.
- The CLI emits an `OAM-TS0005` diagnostic when a warn-mode check misses the
  exit deadline.
- Build hosts install `tsgo` into a user npm prefix; a conformance high-water-mark
  assertion is no longer tied to a specific Node version; a phantom dev
  dependency was dropped.

## [0.6.1] - 2026-07-02

First release published with binaries and a `SHA256SUMS` manifest. Earlier tags
(`v0.2.0` through `v0.6.0`) exist in the repository but were never published as
releases.

### Added

- **Distribution**: the release pipeline and install scripts (unsigned,
  checksummed), `oam self-update` delegating to the canonical installer, and
  GitHub-authenticated installs.
- **Node test-suite conformance harness**: a vendored corpus with an exit-0
  runner, a manifest and scorecard, per-module reporting, and a skip-ratchet.
- **`node:test`** — a subset of Node's built-in test runner.
- **Node compatibility breadth**: the legacy `url.parse` / `resolve` /
  `resolveObject` API, the legacy `constants` module, `global` as a `globalThis`
  alias, the positional `readline.createInterface(stream)` form, classic
  fd-based `fs` calls (both synchronous and callback), `fs.ReadStream` and
  `fs.WriteStream` as real `Readable` / `Writable` subclasses, `zlib` streaming
  class constructors, and Node v22's stream async-iterator helpers.
- **`util.inspect` parity work**: ANSI colors, null-prototype constructor
  labeling, array subclasses, sparse holes and extra properties,
  `ArrayBuffer` / `SharedArrayBuffer` formatting, `numericSeparator`, and
  per-call options in `formatWithOptions`.
- **Resolver**: realpath-based module identity, CommonJS `.` and `..`,
  `require.resolve`, `file://` imports, and npm `package.json` subpath imports
  (`#name`).
- **Extra-fd stdio on Windows and Unix**, which is what lets oam drive Chromium
  over the CDP pipe — browser drivers work cross-platform.
- **HTTP client**: a native undici-API shim that shadows the npm package, and
  `fetch` honoring an undici dispatcher's `connect.lookup` as a real DNS pin.
- **N-API (beta)**: externals, references, wrap/class, bigint, and buffers — 22
  new symbols.
- **Pre-compilation**: a V8 bytecode code-cache for both CommonJS and ES
  modules, bytecode embedded in compiled binaries, a cache opt-out knob, and
  corruption resilience.
- **Installer**: symlink entries, a cross-process lock, and lifecycle scripts
  for trusted packages.
- **Record/replay (beta)**: `performance.now` is recorded, with an end-to-end
  determinism test.
- **`.cts` (TypeScript CommonJS) is executable.** `oam run foo.cts`, `import "./lib.cts"`
  from an ESM parent, and `require("./lib.cts")` from a CJS parent all run through the
  same oxc TS strip as `.ts` (oxc's `SourceType::from_path` resolves `.cts` as both TS
  and CJS). The previous OAM-MOD0003 gate ("write ESM TypeScript (.ts) instead") is
  gone; the OAM-MOD0003 explanation was rewritten to match. `oam test` discovery also
  covers `.cts`. *(Documented late -- this shipped in 0.6.1 but the entry was written
  under Unreleased.)*
- An opt-in `io_uring` filesystem fast path on Linux.
- macOS `os` and `process` natives via `sysinfo`.

### Performance

- Hardware SHA-256 on aarch64.
- The `fork` prewarm pool warms lazily, on first `fork()`.
- `io_uring` read chunks grow from 64 KiB to 4 MiB, fixing large-file reads.

[Unreleased]: https://github.com/YawLabs/oam/compare/v0.19.1...HEAD
[0.19.1]: https://github.com/YawLabs/oam/compare/v0.19.0...v0.19.1
[0.19.0]: https://github.com/YawLabs/oam/compare/v0.18.1...v0.19.0
[0.18.1]: https://github.com/YawLabs/oam/compare/v0.18.0...v0.18.1
[0.18.0]: https://github.com/YawLabs/oam/compare/v0.17.1...v0.18.0
[0.17.1]: https://github.com/YawLabs/oam/compare/v0.17.0...v0.17.1
[0.17.0]: https://github.com/YawLabs/oam/compare/v0.16.4...v0.17.0
[0.16.4]: https://github.com/YawLabs/oam/compare/v0.16.3...v0.16.4
[0.16.3]: https://github.com/YawLabs/oam/compare/v0.16.2...v0.16.3
[0.16.2]: https://github.com/YawLabs/oam/compare/v0.16.1...v0.16.2
[0.16.1]: https://github.com/YawLabs/oam/compare/v0.15.3...v0.16.1
[0.15.3]: https://github.com/YawLabs/oam/compare/v0.15.2...v0.15.3
[0.15.2]: https://github.com/YawLabs/oam/compare/v0.15.1...v0.15.2
[0.15.1]: https://github.com/YawLabs/oam/compare/v0.15.0...v0.15.1
[0.15.0]: https://github.com/YawLabs/oam/compare/v0.14.0...v0.15.0
[0.14.0]: https://github.com/YawLabs/oam/compare/v0.13.2...v0.14.0
[0.13.2]: https://github.com/YawLabs/oam/compare/v0.13.1...v0.13.2
[0.13.1]: https://github.com/YawLabs/oam/compare/v0.13.0...v0.13.1
[0.13.0]: https://github.com/YawLabs/oam/compare/v0.12.1...v0.13.0
[0.12.1]: https://github.com/YawLabs/oam/compare/v0.12.0...v0.12.1
[0.12.0]: https://github.com/YawLabs/oam/compare/v0.11.0...v0.12.0
[0.11.0]: https://github.com/YawLabs/oam/compare/v0.10.2...v0.11.0
[0.10.2]: https://github.com/YawLabs/oam/compare/v0.10.1...v0.10.2
[0.10.1]: https://github.com/YawLabs/oam/compare/v0.10.0...v0.10.1
[0.10.0]: https://github.com/YawLabs/oam/compare/v0.9.8...v0.10.0
[0.9.8]: https://github.com/YawLabs/oam/compare/v0.9.7...v0.9.8
[0.9.7]: https://github.com/YawLabs/oam/compare/v0.9.6...v0.9.7
[0.9.6]: https://github.com/YawLabs/oam/compare/v0.9.4...v0.9.6
[0.9.4]: https://github.com/YawLabs/oam/compare/v0.9.2...v0.9.4
[0.9.2]: https://github.com/YawLabs/oam/compare/v0.9.1...v0.9.2
[0.9.1]: https://github.com/YawLabs/oam/compare/v0.9.0...v0.9.1
[0.9.0]: https://github.com/YawLabs/oam/compare/v0.8.3...v0.9.0
[0.8.3]: https://github.com/YawLabs/oam/compare/v0.8.2...v0.8.3
[0.8.2]: https://github.com/YawLabs/oam/compare/v0.8.1...v0.8.2
[0.8.1]: https://github.com/YawLabs/oam/compare/v0.8.0...v0.8.1
[0.8.0]: https://github.com/YawLabs/oam/compare/v0.7.0...v0.8.0
[0.7.0]: https://github.com/YawLabs/oam/compare/v0.6.1...v0.7.0
[0.6.1]: https://github.com/YawLabs/oam/releases/tag/v0.6.1
